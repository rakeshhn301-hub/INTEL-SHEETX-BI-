/**
 * Typed browser API client for INTEL SHEETX BI.
 * Uses strictly relative '/api/...' URLs so all calls route through the preview proxy.
 */

export interface User {
  id: string;
  email: string;
  name: string;
}

export interface ProjectSummary {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  member_role: 'owner' | 'editor' | 'viewer';
  dataset_count: number;
  dashboard_count: number;
  updated_at: string;
}

export interface FieldMeta {
  id: string;
  name: string;
  physical_type: string;
  semantic_type: string;
  role: 'dimension' | 'measure' | 'identifier' | 'detail' | 'date';
  default_agg: string | null;
  additive: string;
  unit: string | null;
  sensitive: boolean;
  exclude_from_ai: boolean;
  distinct_count: number;
  null_count: number;
  null_rate: number;
  reason: string;
  overridden_by: string | null;
  stats: Record<string, any>;
}

export interface MetricMeta {
  id: string;
  metric_key: string;
  label: string;
  description: string;
  kind: string;
  formula_display: string;
  grain: string;
  null_policy: string;
  format: Record<string, any>;
  version: number;
  is_builtin: boolean;
  available: boolean;
  missing_requirements: string[];
}

export interface FilterClause {
  field: string;
  op: '=' | '!=' | 'in' | 'between' | '>=' | '<=' | 'contains';
  value: any;
}

export interface ChartSpec {
  intent: string;
  chart_type: string;
  dataset_id: string;
  dimensions: Array<{ field: string; grain?: string | null; sort?: { by: string; dir: string } | null }>;
  series_dimension?: string | null;
  measures: Array<{ metric: string }>;
  filters: FilterClause[];
  period?: { kind: string; value?: string | null; from?: string | null; to?: string | null } | null;
  compare?: string;
  limit?: number;
  what_if?: { parameter: string; delta_pct: number } | null;
  title?: string | null;
}

const TOKEN_STORAGE_KEY = 'sheetx_session_token';

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string | null): void {
  try {
    if (token) localStorage.setItem(TOKEN_STORAGE_KEY, token);
    else localStorage.removeItem(TOKEN_STORAGE_KEY);
  } catch {
    // ignore storage errors in restricted environments
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers || {});
  const tok = getStoredToken();
  if (tok && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${tok}`);
  }
  if (!(init.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  if (location.hostname.endsWith('.github.io')) {
    throw new Error('This GitHub Pages site only hosts the interface. Open the deployed full-stack application to sign in, upload data, or run analytics.');
  }
  let res: Response;
  try {
    res = await fetch(path, { ...init, headers, credentials: 'include' });
  } catch {
    throw new Error('Cannot reach the application server. Check your connection and that the backend is running.');
  }
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try {
      const errJson = await res.json();
      const detail = errJson.detail || errJson.message;
      if (Array.isArray(detail)) msg = detail.map((e: any) => `${(e.loc || []).slice(1).join('.')}: ${e.msg}`).join('; ');
      else if (typeof detail === 'string') msg = detail;
    } catch {
      // ignore parse error
    }
    throw new Error(msg);
  }
  return res.json() as Promise<T>;
}

export const api = {
  health: () => request<any>('/api/health'),
  me: () => request<{ user: User }>('/api/auth/me'),
  login: async (email: string, password: string) => {
    const res = await request<{ token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setStoredToken(res.token);
    return res.user;
  },
  register: async (name: string, email: string, password: string) => {
    const res = await request<{ token: string; user: User }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
    setStoredToken(res.token);
    return res.user;
  },
  logout: async () => {
    try {
      await request('/api/auth/logout', { method: 'POST' });
    } finally {
      setStoredToken(null);
    }
  },

  listProjects: () => request<{ projects: ProjectSummary[] }>('/api/projects'),
  createProject: (name: string, description: string) =>
    request<{ project: ProjectSummary }>('/api/projects', {
      method: 'POST',
      body: JSON.stringify({ name, description }),
    }),
  getProject: (projectId: string) => request<any>(`/api/projects/${projectId}`),
  shareProject: (projectId: string, email: string, role: string) =>
    request<any>(`/api/projects/${projectId}/members`, {
      method: 'POST',
      body: JSON.stringify({ email, role }),
    }),

  uploadFile: (projectId: string, file: File, sheetName?: string, datasetId?: string) => {
    const fd = new FormData();
    fd.append('project_id', projectId);
    fd.append('file', file);
    if (sheetName) fd.append('sheet_name', sheetName);
    if (datasetId) fd.append('dataset_id', datasetId);
    return request<any>('/api/upload', { method: 'POST', body: fd });
  },
  ingestFixture: (projectId: string, fixtureName: string, sheetName?: string) =>
    request<any>('/api/upload/fixture', {
      method: 'POST',
      body: JSON.stringify({ project_id: projectId, fixture_name: fixtureName, sheet_name: sheetName }),
    }),

  getDatasetProfile: (datasetId: string) => request<any>(`/api/datasets/${datasetId}/profile`),
  getDatasetPreview: (datasetId: string, offset = 0, limit = 40) =>
    request<any>(`/api/datasets/${datasetId}/preview?offset=${offset}&limit=${limit}`),
  patchFields: (datasetId: string, overrides: Array<Record<string, any>>) =>
    request<any>(`/api/datasets/${datasetId}/fields`, {
      method: 'PATCH',
      body: JSON.stringify({ overrides }),
    }),
  deleteDataset: (datasetId: string, confirmName: string) =>
    request<any>(`/api/datasets/${datasetId}?confirm_name=${encodeURIComponent(confirmName)}`, {
      method: 'DELETE',
    }),

  createCustomMetric: (payload: {
    project_id: string;
    dataset_id: string;
    metric_key: string;
    label: string;
    description: string;
    expression: string;
    unit: string;
  }) => request<any>('/api/metrics', { method: 'POST', body: JSON.stringify(payload) }),

  createRelationship: (payload: {
    project_id: string;
    from_dataset_id: string;
    from_field: string;
    to_dataset_id: string;
    to_field: string;
  }) => request<any>('/api/relationships', { method: 'POST', body: JSON.stringify(payload) }),

  runQuery: (spec: ChartSpec) =>
    request<any>('/api/query', { method: 'POST', body: JSON.stringify(spec) }),

  runCommand: (projectId: string, datasetId: string, text: string, previousSpec?: any) =>
    request<any>('/api/command', {
      method: 'POST',
      body: JSON.stringify({ project_id: projectId, dataset_id: datasetId, text, previous_spec: previousSpec }),
    }),
  getCommandLogs: (projectId: string) =>
    request<{ logs: any[] }>(`/api/command/logs?project_id=${encodeURIComponent(projectId)}`),

  saveChart: (projectId: string, datasetId: string, title: string, spec: ChartSpec) =>
    request<any>('/api/charts', {
      method: 'POST',
      body: JSON.stringify({ project_id: projectId, dataset_id: datasetId, title, spec }),
    }),

  getInsightPlan: (datasetId: string) =>
    request<any>('/api/insight/plan', { method: 'POST', body: JSON.stringify({ dataset_id: datasetId }) }),
  runInsights: (datasetId: string) =>
    request<any>('/api/insight/run', { method: 'POST', body: JSON.stringify({ dataset_id: datasetId }) }),

  generateDashboard: (projectId: string, datasetId: string) =>
    request<any>('/api/dashboards/generate', {
      method: 'POST',
      body: JSON.stringify({ project_id: projectId, dataset_id: datasetId }),
    }),
  getDashboard: (dashboardId: string, activeFilters?: FilterClause[]) => {
    const qs = activeFilters && activeFilters.length > 0
      ? `?filters_json=${encodeURIComponent(JSON.stringify(activeFilters))}`
      : '';
    return request<any>(`/api/dashboards/${dashboardId}${qs}`);
  },
  updateDashboard: (dashboardId: string, definition: any, title?: string, note?: string) =>
    request<any>(`/api/dashboards/${dashboardId}`, {
      method: 'PATCH',
      body: JSON.stringify({ definition, title, note: note || 'Edited layout' }),
    }),

  downloadExport: async (datasetId: string, format: 'csv' | 'xlsx' | 'report_html', spec: ChartSpec) => {
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const tok = getStoredToken();
    if (tok) headers.set('Authorization', `Bearer ${tok}`);
    const res = await fetch('/api/export', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ dataset_id: datasetId, format, spec }),
    });
    if (!res.ok) throw new Error(`Export failed (${res.status})`);
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const ext = format === 'report_html' ? 'html' : format;
    a.href = url;
    a.download = `intel_sheetx_export.${ext}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  },

  createSchedule: (payload: any) =>
    request<any>('/api/schedules', { method: 'POST', body: JSON.stringify(payload) }),
  runSchedule: (scheduleId: string, periodKey = new Date().toISOString().slice(0, 10)) =>
    request<any>(`/api/schedules/${scheduleId}/run?period_key=${encodeURIComponent(periodKey)}`, { method: 'POST' }),
  listJobs: (projectId: string) => request<any>(`/api/projects/${projectId}/jobs`),

  listAgentTools: () => request<{ tools: any[] }>('/api/agent/tools'),
  runAgent: (projectId: string, datasetId: string, goal: string) =>
    request<any>('/api/agent/run', {
      method: 'POST',
      body: JSON.stringify({ project_id: projectId, dataset_id: datasetId, goal }),
    }),
  getAgentAudit: (runId: string) => request<any>(`/api/agent/runs/${runId}`),
};
