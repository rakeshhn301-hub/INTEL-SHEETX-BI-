import React, { useEffect, useRef, useState } from 'react';
import * as echarts from 'echarts';
import { Code2, Table as TableIcon, BarChart3, Download, ShieldCheck, Info } from 'lucide-react';
import { api, ChartSpec } from '../api/client';

interface ChartCanvasProps {
  render: any;
  query: any;
  spec?: ChartSpec;
  height?: number;
  compact?: boolean;
  onMarkClick?: (dimensionField: string, categoryValue: string) => void;
}

export const ChartCanvas: React.FC<ChartCanvasProps> = ({
  render,
  query,
  spec,
  height = 340,
  compact = false,
  onMarkClick,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const chartInstanceRef = useRef<echarts.ECharts | null>(null);
  const [viewMode, setViewMode] = useState<'chart' | 'table'>('chart');
  const [showProvenance, setShowProvenance] = useState(false);

  // Enforce non-negotiable Rule #1 & R-1: require real query result with query_id
  if (!render || !query || !query.query_id) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50/70 p-8 text-center">
        <BarChart3 className="h-8 w-8 text-slate-400 mb-2" />
        <p className="text-sm font-medium text-slate-700">No executed query result yet</p>
        <p className="text-xs text-slate-500 mt-1">
          Charts render strictly from verified DuckDB queries against your uploaded dataset.
        </p>
      </div>
    );
  }

  useEffect(() => {
    setViewMode(render.chart_type === 'table' ? 'table' : 'chart');
  }, [render.chart_type, query.query_id]);

  useEffect(() => {
    if (viewMode !== 'chart' || !render.echarts_option || !containerRef.current || render.empty) {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.dispose();
        chartInstanceRef.current = null;
      }
      return;
    }

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const inst = echarts.init(containerRef.current, undefined, { renderer: 'canvas' });
    chartInstanceRef.current = inst;

    const opt = {
      ...render.echarts_option,
      animation: !prefersReducedMotion,
    };
    inst.setOption(opt, true);

    inst.off('click');
    if (onMarkClick && render.dimension_field) {
      inst.on('click', (params: any) => {
        const clickedLabel = params?.name;
        if (clickedLabel && !String(clickedLabel).startsWith('Other (')) {
          onMarkClick(render.dimension_field, String(clickedLabel));
        }
      });
    }

    const handleResize = () => inst.resize();
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      inst.dispose();
      chartInstanceRef.current = null;
    };
  }, [render, query.query_id, viewMode, onMarkClick]);

  const rows: Record<string, any>[] = query.rows || [];
  const cols: string[] = query.columns || [];

  return (
    <div
      className="rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden flex flex-col"
      role="region"
      aria-label={render.title || 'Analytical Chart'}
    >
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-2 border-b border-slate-100 px-4 py-3 bg-slate-50/50">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-slate-900 truncate">{render.title}</h3>
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-medium text-emerald-700 border border-emerald-200">
              <ShieldCheck className="h-3 w-3" /> {query.query_id}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5 truncate">
            {render.subtitle} · v{query.dataset_version} · {query.duration_ms}ms
          </p>
        </div>

        <div className="flex items-center gap-1.5">
          {render.chart_type !== 'kpi' && (
            <button
              type="button"
              onClick={() => setViewMode(viewMode === 'chart' ? 'table' : 'chart')}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50"
              title="Toggle accessible Data Table view"
            >
              {viewMode === 'chart' ? (
                <>
                  <TableIcon className="h-3.5 w-3.5" /> Table
                </>
              ) : (
                <>
                  <BarChart3 className="h-3.5 w-3.5" /> Chart
                </>
              )}
            </button>
          )}
          <button
            type="button"
            onClick={() => setShowProvenance(!showProvenance)}
            className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-xs font-medium ${
              showProvenance
                ? 'border-blue-600 bg-blue-50 text-blue-700'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
            }`}
            title="Inspect compiled SQL, parameters, and metric formula"
          >
            <Code2 className="h-3.5 w-3.5" /> SQL
          </button>
          {!compact && spec && (
            <button
              type="button"
              onClick={() => api.downloadExport(query.dataset_id, 'csv', spec)}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50"
              title="Export exact filtered result as CSV"
            >
              <Download className="h-3.5 w-3.5" /> CSV
            </button>
          )}
        </div>
      </div>

      {/* Screen-reader accessible summary */}
      <p className="sr-only">{render.text_summary}</p>

      {/* Body */}
      <div className="p-4 flex-1">
        {render.empty ? (
          <div className="py-12 text-center">
            <p className="text-sm font-medium text-slate-700">{render.empty_message}</p>
          </div>
        ) : render.chart_type === 'kpi' && viewMode === 'chart' ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {(render.kpi_cards || []).map((card: any) => (
              <div
                key={card.metric_key}
                className="rounded-xl border border-slate-200/90 bg-gradient-to-b from-white to-slate-50/70 p-3.5"
              >
                <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  {card.label}
                </div>
                <div className="mt-1.5 text-2xl font-bold tracking-tight text-slate-900">
                  {card.formatted_value}
                </div>
                <div className="mt-1.5 text-[11px] font-mono text-slate-500 truncate" title={card.formula}>
                  {card.formula}
                </div>
              </div>
            ))}
          </div>
        ) : viewMode === 'table' || render.chart_type === 'table' ? (
          <div className="max-h-80 overflow-auto rounded-lg border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200 text-xs">
              <thead className="bg-slate-50 sticky top-0">
                <tr>
                  {cols.map((c) => (
                    <th key={c} className="px-3 py-2 text-left font-semibold text-slate-700">
                      {c}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {rows.map((r, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    {cols.map((c) => (
                      <td key={c} className="px-3 py-1.5 text-slate-800 font-mono whitespace-nowrap">
                        {r[c] === null || r[c] === undefined
                          ? 'NULL'
                          : typeof r[c] === 'number'
                          ? Number(r[c]).toLocaleString(undefined, { maximumFractionDigits: 4 })
                          : String(r[c])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div
            ref={containerRef}
            style={{ height: `${height}px`, width: '100%' }}
            className="cursor-pointer"
          />
        )}

        {/* Recommender Reason & Guardrail Notes */}
        {(render.reason || (render.guardrail_notes && render.guardrail_notes.length > 0)) && (
          <div className="mt-3 space-y-1 border-t border-slate-100 pt-2.5 text-xs text-slate-600">
            {render.reason && (
              <div className="flex items-start gap-1.5">
                <Info className="h-3.5 w-3.5 text-blue-600 shrink-0 mt-0.5" />
                <span>{render.reason}</span>
              </div>
            )}
            {(render.guardrail_notes || []).map((note: string, i: number) => (
              <div key={i} className="flex items-start gap-1.5 text-amber-800 bg-amber-50/80 border border-amber-200/70 rounded-md px-2.5 py-1">
                <span className="font-semibold">Guardrail:</span>
                <span>{note}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Expandable Provenance & Parameterized SQL Drawer */}
      {showProvenance && (
        <div className="border-t border-slate-200 bg-slate-900 text-slate-100 p-3.5 text-xs font-mono space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2 text-slate-400">
            <span>Query ID: {query.query_id} · SQL Hash: {query.sql_hash}</span>
            <span>Rows returned: {query.row_count} (of {query.total_groups_before_cap} groups)</span>
          </div>
          <div className="rounded bg-slate-950 p-2.5 text-emerald-300 overflow-x-auto whitespace-pre-wrap">
            {query.sql}
          </div>
          <div className="text-slate-300">
            Bound Params: <span className="text-amber-300">{JSON.stringify(query.params)}</span>
          </div>
          {query.metrics_used && query.metrics_used.length > 0 && (
            <div className="text-slate-300">
              Formulas:{' '}
              {query.metrics_used.map((m: any) => `${m.label} := ${m.formula}`).join(' | ')}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
