import React, { useEffect, useRef, useState } from 'react';
import {
  Terminal,
  Sparkles,
  Sliders,
  Plus,
  X,
  RotateCcw,
  Bookmark,
  Download,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Search,
} from 'lucide-react';
import { api, ChartSpec, FieldMeta, FilterClause, MetricMeta } from '../api/client';
import { ChartCanvas } from './ChartCanvas';

interface CommandAndBuilderStudioProps {
  projectId: string;
  datasetId: string;
  profileData: any;
  initialCommand?: string | null;
  onConsumeInitialCommand?: () => void;
  onRefreshDatasetProfile: () => Promise<void>;
}

const SLASH_SHORTCUTS = [
  { cmd: '/bar ', desc: 'Sorted horizontal comparison' },
  { cmd: '/line ', desc: 'Monthly chronological trend' },
  { cmd: '/donut ', desc: 'Share of total (<=5 slices)' },
  { cmd: '/scatter ', desc: 'Two-measure association' },
  { cmd: '/histogram ', desc: 'Server-binned distribution' },
  { cmd: '/bullet ', desc: 'Actual vs Target variance' },
  { cmd: '/kpi ', desc: 'Headline metric strip' },
  { cmd: '/pareto ', desc: 'Cumulative vital-few curve' },
];

const BENCHMARK_PROMPTS = [
  'compare sales by division',
  'profit trend by month',
  'top 10 products by margin',
  'revenue share by region',
  'does discount affect profit',
  'sales vs target by month',
  'why is west margin down',
  'forecast sales next quarter',
  'what is our churn',
];

const VALID_CHARTS = [
  'bar_h',
  'bar',
  'line',
  'area',
  'donut',
  'pct_bar',
  'stacked_bar',
  'scatter',
  'histogram',
  'bullet',
  'pareto',
  'kpi',
  'table',
];

export const CommandAndBuilderStudio: React.FC<CommandAndBuilderStudioProps> = ({
  projectId,
  datasetId,
  profileData,
  initialCommand,
  onConsumeInitialCommand,
  onRefreshDatasetProfile,
}) => {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [commandText, setCommandText] = useState('compare sales by division');
  const [fieldSearch, setFieldSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Command / Query execution state
  const [outcome, setOutcome] = useState<'answered' | 'clarified' | 'refused' | null>(null);
  const [clarification, setClarification] = useState<any | null>(null);
  const [refusal, setRefusal] = useState<any | null>(null);
  const [currentSpec, setCurrentSpec] = useState<ChartSpec | null>(null);
  const [queryResult, setQueryResult] = useState<any | null>(null);
  const [renderBundle, setRenderBundle] = useState<any | null>(null);
  const [explanation, setExplanation] = useState<any | null>(null);
  const [forecastInfo, setForecastInfo] = useState<any | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  // Custom Derived Metric Modal
  const [showMetricModal, setShowMetricModal] = useState(false);
  const [newMetricKey, setNewMetricKey] = useState('net_margin_per_unit');
  const [newMetricLabel, setNewMetricLabel] = useState('Profit per Unit');
  const [newMetricExpr, setNewMetricExpr] = useState('round(sum(profit) / nullif(sum(units), 0), 2)');
  const [newMetricUnit, setNewMetricUnit] = useState('currency');

  const fields: FieldMeta[] = profileData?.fields || [];
  const metrics: MetricMeta[] = profileData?.metrics || [];
  const availableMetrics = metrics.filter((m) => m.available);
  const groupableDims = fields.filter((f) => f.role === 'dimension' || f.role === 'date' || f.role === 'identifier');

  // Global keyboard shortcut '/' or Cmd+K focuses command bar
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // Run initial default query when dataset loads so user sees live verified data immediately
  useEffect(() => {
    if (initialCommand) {
      setCommandText(initialCommand);
      executeCommand(initialCommand);
      onConsumeInitialCommand?.();
    } else if (datasetId && availableMetrics.length > 0) {
      const defaultDim = fields.find((f) => f.role === 'dimension');
      const cmd = defaultDim
        ? `compare ${availableMetrics[0].label.toLowerCase()} by ${defaultDim.name.toLowerCase()}`
        : 'how are we doing this quarter';
      setCommandText(cmd);
      executeCommand(cmd);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [datasetId]);

  const executeCommand = async (textToRun: string) => {
    if (!textToRun.trim()) return;
    setLoading(true);
    setError(null);
    setSavedNotice(null);
    try {
      const res = await api.runCommand(projectId, datasetId, textToRun, currentSpec || undefined);
      setOutcome(res.outcome);
      if (res.outcome === 'clarified') {
        setClarification(res);
        setRefusal(null);
      } else if (res.outcome === 'refused') {
        setRefusal(res);
        setClarification(null);
      } else {
        setClarification(null);
        setRefusal(null);
        setCurrentSpec(res.spec);
        setQueryResult(res.query);
        setRenderBundle(res.render);
        setExplanation(res.explanation);
        setForecastInfo(res.forecast || null);
      }
    } catch (err: any) {
      setError(err.message || 'Command execution failed');
    } finally {
      setLoading(false);
    }
  };

  const executeDirectSpec = async (nextSpec: ChartSpec) => {
    setLoading(true);
    setError(null);
    setSavedNotice(null);
    try {
      const res = await api.runQuery(nextSpec);
      setOutcome('answered');
      setClarification(null);
      setRefusal(null);
      setCurrentSpec(res.spec);
      setQueryResult(res.query);
      setRenderBundle(res.render);
      setForecastInfo(null);
    } catch (err: any) {
      setError(err.message || 'Query failed');
    } finally {
      setLoading(false);
    }
  };

  const handleMarkCrossFilter = (dimField: string, catVal: string) => {
    if (!currentSpec) return;
    const exists = (currentSpec.filters || []).some((f) => f.field === dimField && f.value === catVal);
    const nextFilters: FilterClause[] = exists
      ? currentSpec.filters
      : [...(currentSpec.filters || []), { field: dimField, op: '=', value: catVal }];
    executeDirectSpec({ ...currentSpec, filters: nextFilters });
  };

  const removeFilter = (idx: number) => {
    if (!currentSpec) return;
    const next = currentSpec.filters.filter((_, i) => i !== idx);
    executeDirectSpec({ ...currentSpec, filters: next });
  };

  const resetAllFilters = () => {
    if (!currentSpec) return;
    executeDirectSpec({ ...currentSpec, filters: [], period: null, what_if: null });
  };

  const handleSaveChart = async () => {
    if (!currentSpec || !renderBundle) return;
    try {
      await api.saveChart(projectId, datasetId, renderBundle.title || 'Saved Chart', currentSpec);
      setSavedNotice('Saved chart definition to project library.');
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleCreateCustomMetric = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api.createCustomMetric({
        project_id: projectId,
        dataset_id: datasetId,
        metric_key: newMetricKey,
        label: newMetricLabel,
        description: `AST-validated custom metric: ${newMetricExpr}`,
        expression: newMetricExpr,
        unit: newMetricUnit,
      });
      setShowMetricModal(false);
      await onRefreshDatasetProfile();
      setSavedNotice(`Created & versioned custom metric '${newMetricLabel}'.`);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const filteredFields = fields.filter((f) =>
    f.name.toLowerCase().includes(fieldSearch.toLowerCase())
  );
  const filteredMetrics = metrics.filter(
    (m) =>
      m.label.toLowerCase().includes(fieldSearch.toLowerCase()) ||
      m.metric_key.toLowerCase().includes(fieldSearch.toLowerCase())
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Left Power BI / Tableau-style Searchable Field & Metric Pane */}
      <aside className="lg:col-span-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm flex flex-col max-h-[840px]">
        <div className="flex items-center justify-between mb-2.5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
            Semantic Fields & 15 Metrics
          </h3>
          <button
            type="button"
            onClick={() => setShowMetricModal(true)}
            className="inline-flex items-center gap-1 rounded-md bg-blue-50 hover:bg-blue-100 px-2 py-1 text-[11px] font-semibold text-blue-700"
            title="Compile safe AST derived metric (Chapter 28.5)"
          >
            <Plus className="h-3 w-3" /> Metric
          </button>
        </div>

        <div className="relative mb-3">
          <Search className="h-3.5 w-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          <input
            type="text"
            value={fieldSearch}
            onChange={(e) => setFieldSearch(e.target.value)}
            placeholder="Search dimensions & metrics..."
            className="w-full rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-2.5 py-1.5 text-xs"
          />
        </div>

        <div className="overflow-y-auto space-y-4 pr-1 text-xs flex-1">
          {/* Governed Metrics */}
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 mb-1.5">
              Governed Metrics ({filteredMetrics.filter((m) => m.available).length} active)
            </div>
            <div className="space-y-1">
              {filteredMetrics.map((m) => (
                <button
                  key={m.metric_key}
                  type="button"
                  disabled={!m.available}
                  onClick={() => {
                    if (!currentSpec) return;
                    executeDirectSpec({
                      ...currentSpec,
                      measures: [{ metric: m.metric_key }],
                      title: null,
                    });
                  }}
                  className={`w-full text-left rounded-lg border px-2.5 py-1.5 transition ${
                    !m.available
                      ? 'border-slate-100 bg-slate-50 text-slate-400 cursor-not-allowed'
                      : currentSpec?.measures?.[0]?.metric === m.metric_key
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-semibold'
                      : 'border-slate-200/80 hover:border-emerald-400 hover:bg-emerald-50/40 text-slate-800'
                  }`}
                  title={
                    m.available
                      ? `${m.formula_display} (v${m.version})`
                      : `Unavailable: missing ${m.missing_requirements.join(', ')}`
                  }
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="truncate">{m.label}</span>
                    <span className="text-[10px] font-mono text-slate-500 uppercase">{m.kind}</span>
                  </div>
                  <div className="text-[10px] font-mono text-slate-500 truncate mt-0.5">
                    {m.formula_display}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Dataset Fields */}
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-blue-700 mb-1.5">
              Dataset Columns ({filteredFields.length})
            </div>
            <div className="space-y-1">
              {filteredFields.map((f) => {
                const isGroupable = f.role === 'dimension' || f.role === 'date' || f.role === 'identifier';
                return (
                  <button
                    key={f.id}
                    type="button"
                    disabled={!isGroupable}
                    onClick={() => {
                      if (!currentSpec || !isGroupable) return;
                      executeDirectSpec({
                        ...currentSpec,
                        intent: f.role === 'date' ? 'A2_trend' : 'A1_compare',
                        chart_type: f.role === 'date' ? 'line' : 'bar_h',
                        dimensions: [
                          {
                            field: f.name,
                            grain: f.role === 'date' ? 'month' : null,
                            sort: { by: f.role === 'date' ? 'dimension' : 'measure', dir: f.role === 'date' ? 'asc' : 'desc' },
                          },
                        ],
                        title: null,
                      });
                    }}
                    className={`w-full flex items-center justify-between rounded-lg border px-2.5 py-1.5 text-left transition ${
                      currentSpec?.dimensions?.[0]?.field === f.name
                        ? 'border-blue-600 bg-blue-50 text-blue-900 font-semibold'
                        : isGroupable
                        ? 'border-slate-200/80 hover:border-blue-400 text-slate-800'
                        : 'border-slate-100 bg-slate-50/70 text-slate-500'
                    }`}
                    title={f.reason}
                  >
                    <span className="truncate">{f.name}</span>
                    <span
                      className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${
                        f.role === 'dimension'
                          ? 'bg-blue-100 text-blue-800'
                          : f.role === 'date'
                          ? 'bg-amber-100 text-amber-800'
                          : f.role === 'measure'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-purple-100 text-purple-800'
                      }`}
                    >
                      {f.role}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </aside>

      {/* Main Command Bar, Shelves & Interactive Canvas */}
      <div className="lg:col-span-9 space-y-4">
        {/* Signature One-Sentence Command Bar */}
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              executeCommand(commandText);
            }}
            className="flex flex-col sm:flex-row gap-2"
          >
            <div className="relative flex-1">
              <Terminal className="h-4 w-4 text-blue-600 absolute left-3.5 top-3" />
              <input
                ref={inputRef}
                type="text"
                aria-label="Natural-language command bar"
                value={commandText}
                onChange={(e) => setCommandText(e.target.value)}
                placeholder="Type one command, e.g. '/bar sales by division', 'profit trend by month', 'why is west margin down' (⌘K)"
                className="w-full rounded-xl border border-slate-300 bg-slate-50/60 focus:bg-white pl-10 pr-4 py-2.5 text-sm text-slate-900 font-medium focus:border-blue-600"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition"
            >
              <Sparkles className="h-4 w-4" />
              {loading ? 'Compiling...' : 'Run Command'}
            </button>
          </form>

          {/* Slash Command Hints & Benchmark Chips */}
          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-500 mr-1">Slash:</span>
            {SLASH_SHORTCUTS.map((s) => (
              <button
                key={s.cmd}
                type="button"
                onClick={() => {
                  const stripped = commandText.replace(/^\/[a-z_]+\s*/i, '');
                  setCommandText(`${s.cmd}${stripped}`);
                  inputRef.current?.focus();
                }}
                className="rounded-md border border-slate-200 bg-slate-50 hover:bg-blue-50 hover:border-blue-300 px-2 py-0.5 text-[11px] font-mono text-slate-700"
                title={s.desc}
              >
                {s.cmd.trim()}
              </button>
            ))}
          </div>

          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-500 mr-1">Try Benchmark:</span>
            {BENCHMARK_PROMPTS.map((bp) => (
              <button
                key={bp}
                type="button"
                onClick={() => {
                  setCommandText(bp);
                  executeCommand(bp);
                }}
                className="rounded-full border border-slate-200 bg-white hover:border-blue-500 hover:text-blue-700 px-2.5 py-0.5 text-[11px] text-slate-600 transition"
              >
                {bp}
              </button>
            ))}
          </div>
        </div>

        {/* Clarification Prompt Card (when slot candidates tie within 0.10 margin) */}
        {outcome === 'clarified' && clarification && (
          <div className="rounded-2xl border-2 border-amber-400 bg-amber-50/70 p-5 space-y-3">
            <div className="flex items-center gap-2 text-sm font-bold text-amber-900">
              <HelpCircle className="h-5 w-5 text-amber-600" />
              Clarification Needed (Refusing to Guess Between Close Fields)
            </div>
            <p className="text-xs text-amber-900">{clarification.question}</p>
            <div className="flex flex-wrap gap-2">
              {(clarification.options || []).map((opt: any) => (
                <button
                  key={opt.metric_key}
                  type="button"
                  onClick={() => {
                    const fallbackDim = groupableDims[0]?.name || '';
                    executeDirectSpec({
                      intent: 'A1_compare',
                      chart_type: 'bar_h',
                      dataset_id: datasetId,
                      dimensions: fallbackDim ? [{ field: fallbackDim }] : [],
                      measures: [{ metric: opt.metric_key }],
                      filters: [],
                      limit: 12,
                    });
                  }}
                  className="rounded-xl border border-amber-400 bg-white hover:bg-amber-100 px-3.5 py-2 text-left shadow-sm"
                >
                  <div className="text-xs font-bold text-slate-900">{opt.label}</div>
                  <div className="text-[11px] font-mono text-slate-600">{opt.description}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Graceful Refusal Card + Closest Valid Alternatives */}
        {outcome === 'refused' && refusal && (
          <div className="rounded-2xl border-2 border-rose-300 bg-rose-50/70 p-5 space-y-3">
            <div className="flex items-center gap-2 text-sm font-bold text-rose-900">
              <AlertCircle className="h-5 w-5 text-rose-600" />
              Honest Refusal — Dataset Cannot Support That Question
            </div>
            <p className="text-xs text-rose-900">{refusal.reason}</p>
            {refusal.alternatives && refusal.alternatives.length > 0 && (
              <div>
                <div className="text-[11px] font-bold uppercase tracking-wider text-rose-800 mb-2">
                  Closest Valid Alternatives Supported by This Schema:
                </div>
                <div className="flex flex-wrap gap-2">
                  {refusal.alternatives.map((alt: any, idx: number) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setCommandText(alt.command);
                        executeCommand(alt.command);
                      }}
                      className="rounded-xl border border-rose-300 bg-white hover:bg-rose-100 px-3.5 py-2 text-xs font-semibold text-slate-900 shadow-sm"
                    >
                      → {alt.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {error && (
          <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-800">
            {error}
          </div>
        )}

        {savedNotice && (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-600" /> {savedNotice}
          </div>
        )}

        {/* Manual Visual Shelves + What-If Parameter Bar (Mode 1 + Chart Builder) */}
        {currentSpec && (
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                <Sliders className="h-4 w-4 text-blue-600" /> Visual Shelves & Deterministic What-If
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveChart}
                  className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700"
                >
                  <Bookmark className="h-3.5 w-3.5 text-blue-600" /> Save Chart
                </button>
                <button
                  type="button"
                  onClick={() => api.downloadExport(datasetId, 'xlsx', currentSpec)}
                  className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700"
                >
                  <Download className="h-3.5 w-3.5 text-teal-600" /> Export XLSX
                </button>
                <button
                  type="button"
                  onClick={() => api.downloadExport(datasetId, 'report_html', currentSpec)}
                  className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700"
                >
                  <Download className="h-3.5 w-3.5 text-purple-600" /> Audit Report
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs">
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">Dimension (X/Y)</label>
                <select
                  value={currentSpec.dimensions?.[0]?.field || ''}
                  onChange={(e) => {
                    const val = e.target.value;
                    const f = fields.find((x) => x.name === val);
                    executeDirectSpec({
                      ...currentSpec,
                      dimensions: val
                        ? [{ field: val, grain: f?.role === 'date' ? 'month' : null }]
                        : [],
                      chart_type: !val ? 'kpi' : f?.role === 'date' ? 'line' : currentSpec.chart_type === 'kpi' ? 'bar_h' : currentSpec.chart_type,
                      title: null,
                    });
                  }}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-medium"
                >
                  <option value="">(None — KPI Summary)</option>
                  {groupableDims.map((d) => (
                    <option key={d.id} value={d.name}>
                      {d.name} ({d.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">Primary Metric</label>
                <select
                  value={currentSpec.measures?.[0]?.metric || ''}
                  onChange={(e) =>
                    executeDirectSpec({
                      ...currentSpec,
                      measures: [{ metric: e.target.value }],
                      title: null,
                    })
                  }
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-medium"
                >
                  {availableMetrics.map((m) => (
                    <option key={m.metric_key} value={m.metric_key}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">Series Split</label>
                <select
                  value={currentSpec.series_dimension || ''}
                  onChange={(e) =>
                    executeDirectSpec({
                      ...currentSpec,
                      series_dimension: e.target.value || null,
                      title: null,
                    })
                  }
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-medium"
                >
                  <option value="">(Single Series)</option>
                  {fields
                    .filter((f) => f.role === 'dimension' && f.distinct_count <= 12)
                    .map((d) => (
                      <option key={d.id} value={d.name}>
                        {d.name}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">Visual Type</label>
                <select
                  value={renderBundle?.chart_type || currentSpec.chart_type}
                  onChange={(e) =>
                    executeDirectSpec({
                      ...currentSpec,
                      chart_type: e.target.value,
                    })
                  }
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-medium"
                >
                  {VALID_CHARTS.map((ct) => (
                    <option key={ct} value={ct}>
                      {ct}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-500 mb-1">
                  What-If Price ({currentSpec.what_if?.delta_pct || 0}%)
                </label>
                <input
                  type="range"
                  min={-20}
                  max={20}
                  step={5}
                  value={currentSpec.what_if?.delta_pct || 0}
                  onChange={(e) => {
                    const pct = Number(e.target.value);
                    executeDirectSpec({
                      ...currentSpec,
                      what_if: pct === 0 ? null : { parameter: 'price_pct', delta_pct: pct },
                    });
                  }}
                  className="w-full accent-blue-600 mt-1.5"
                  title="Deterministic sensitivity projection (Chapter 12.6)"
                />
              </div>
            </div>

            {/* Active Filter Chip Bar + Single Reset Control (Rule 4.3 & Table 7.2) */}
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
              <span className="text-[11px] font-semibold text-slate-500">
                Active Scope Filters (click any chart bar to cross-filter):
              </span>
              {(currentSpec.filters || []).length === 0 && !currentSpec.period && !currentSpec.what_if ? (
                <span className="text-slate-400 italic">None — showing full dataset version scope</span>
              ) : (
                <>
                  {(currentSpec.filters || []).map((f, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1 rounded-full bg-blue-50 border border-blue-200 px-2.5 py-0.5 text-blue-800 font-medium"
                    >
                      {f.field} {f.op} {Array.isArray(f.value) ? f.value.join(', ') : String(f.value)}
                      <button type="button" onClick={() => removeFilter(idx)} aria-label="Remove filter">
                        <X className="h-3 w-3 hover:text-rose-600" />
                      </button>
                    </span>
                  ))}
                  {currentSpec.period && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 border border-amber-200 px-2.5 py-0.5 text-amber-800 font-medium">
                      Period: {currentSpec.period.value || `${currentSpec.period.from}..${currentSpec.period.to || 'now'}`}
                    </span>
                  )}
                  {currentSpec.what_if && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-purple-50 border border-purple-200 px-2.5 py-0.5 text-purple-800 font-medium">
                      What-If Projection: {currentSpec.what_if.delta_pct > 0 ? '+' : ''}
                      {currentSpec.what_if.delta_pct}%
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={resetAllFilters}
                    className="inline-flex items-center gap-1 rounded-full bg-slate-900 text-white px-2.5 py-0.5 text-[11px] font-semibold hover:bg-slate-700"
                  >
                    <RotateCcw className="h-3 w-3" /> Reset All
                  </button>
                </>
              )}
            </div>
          </div>
        )}

        {/* Interactive Chart Canvas */}
        {renderBundle && queryResult && (
          <ChartCanvas
            render={renderBundle}
            query={queryResult}
            spec={currentSpec || undefined}
            height={360}
            onMarkClick={handleMarkCrossFilter}
          />
        )}

        {/* Grounded Provenance Explanation Card */}
        {explanation && outcome === 'answered' && (
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                Grounded Explanation (Provenance-Bound to EvidenceBundle)
              </div>
              <span className="rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 text-[11px] font-medium text-emerald-800">
                Numeric Provenance Verified: {explanation.verified ? 'PASS (100%)' : 'Regenerated'} · {explanation.source}
              </span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed">{explanation.narrative}</p>

            {forecastInfo && forecastInfo.supported && (
              <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50/70 p-3 text-xs text-amber-900">
                <div className="font-bold">
                  Estimate Only — {forecastInfo.method} (Holdout Backtest MAPE: {forecastInfo.backtest_mape_pct}%, MAE: {forecastInfo.backtest_mae})
                </div>
                <div className="mt-1 flex flex-wrap gap-3 font-mono text-[11px]">
                  {forecastInfo.points.map((pt: any) => (
                    <span key={pt.period}>
                      {pt.period}: <strong>{pt.forecast.toLocaleString()}</strong> [{pt.lower.toLocaleString()} .. {pt.upper.toLocaleString()}]
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Safe Custom Derived Metric Modal */}
      {showMetricModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-slate-900">
                Create / Version Derived Metric (Safe AST Grammar)
              </h3>
              <button type="button" onClick={() => setShowMetricModal(false)}>
                <X className="h-4 w-4 text-slate-500" />
              </button>
            </div>
            <p className="text-xs text-slate-600 mb-4">
              Uses the Chapter 28.5 AST compiler (`sum`, `count_distinct`, `min`, `max`, `round`, `nullif`, `abs`). Raw SQL, subqueries, and summing identifiers are blocked at compile time.
            </p>
            <form onSubmit={handleCreateCustomMetric} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Metric Key</label>
                  <input
                    type="text"
                    required
                    value={newMetricKey}
                    onChange={(e) => setNewMetricKey(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-1.5 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Display Label</label>
                  <input
                    type="text"
                    required
                    value={newMetricLabel}
                    onChange={(e) => setNewMetricLabel(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-1.5"
                  />
                </div>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Formula Expression</label>
                <input
                  type="text"
                  required
                  value={newMetricExpr}
                  onChange={(e) => setNewMetricExpr(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-1.5 font-mono"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Format Unit</label>
                <select
                  value={newMetricUnit}
                  onChange={(e) => setNewMetricUnit(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-1.5"
                >
                  <option value="currency">Currency (INR)</option>
                  <option value="percent">Percentage (%)</option>
                  <option value="number">Number</option>
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowMetricModal(false)}
                  className="rounded-lg border border-slate-300 px-4 py-1.5 font-semibold text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-blue-600 hover:bg-blue-500 px-4 py-1.5 font-semibold text-white"
                >
                  Compile & Save Metric
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
