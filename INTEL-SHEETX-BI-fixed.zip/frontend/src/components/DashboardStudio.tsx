import React, { useEffect, useState } from 'react';
import {
  LayoutGrid,
  Sparkles,
  RotateCcw,
  Undo2,
  Redo2,
  Save,
  ArrowUp,
  ArrowDown,
  Trash2,
  X,
  Edit3,
} from 'lucide-react';
import { api, FilterClause, MetricMeta } from '../api/client';
import { ChartCanvas } from './ChartCanvas';

interface DashboardStudioProps {
  projectId: string;
  datasetId: string;
  profileData: any;
  dashboards: any[];
  onRefreshProject: () => Promise<void>;
}

export const DashboardStudio: React.FC<DashboardStudioProps> = ({
  projectId,
  datasetId,
  profileData,
  dashboards,
  onRefreshProject,
}) => {
  const [activeDashboardId, setActiveDashboardId] = useState<string | null>(
    dashboards.find((d) => d.dataset_id === datasetId)?.id || null
  );
  const [dashboardPayload, setDashboardPayload] = useState<any | null>(null);
  const [activeFilters, setActiveFilters] = useState<FilterClause[]>([]);
  const [editMode, setEditMode] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const [future, setFuture] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const availableMetrics: MetricMeta[] = (profileData?.metrics || []).filter(
    (m: MetricMeta) => m.available
  );

  useEffect(() => {
    const forDs = dashboards.filter((d) => d.dataset_id === datasetId);
    if (forDs.length > 0 && (!activeDashboardId || !forDs.some((d) => d.id === activeDashboardId))) {
      setActiveDashboardId(forDs[0].id);
    }
  }, [dashboards, datasetId, activeDashboardId]);

  useEffect(() => {
    if (activeDashboardId) {
      loadDashboard(activeDashboardId, activeFilters);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeDashboardId, activeFilters]);

  const loadDashboard = async (id: string, filters: FilterClause[]) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getDashboard(id, filters);
      setDashboardPayload(res);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateAutoDashboard = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.generateDashboard(projectId, datasetId);
      await onRefreshProject();
      setActiveDashboardId(res.id);
      setDashboardPayload(res);
      setActiveFilters([]);
      setHistory([]);
      setFuture([]);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTileCrossFilter = (dimField: string, categoryVal: string) => {
    setActiveFilters((prev) => {
      const exists = prev.some((f) => f.field === dimField && f.value === categoryVal);
      if (exists) {
        return prev.filter((f) => !(f.field === dimField && f.value === categoryVal));
      }
      return [...prev, { field: dimField, op: '=', value: categoryVal }];
    });
  };

  const mutateDefinition = (mutator: (def: any) => any) => {
    if (!dashboardPayload?.definition) return;
    const currentDef = JSON.parse(JSON.stringify(dashboardPayload.definition));
    setHistory((h) => [...h, currentDef]);
    setFuture([]);
    const nextDef = mutator(JSON.parse(JSON.stringify(currentDef)));
    setDashboardPayload({ ...dashboardPayload, definition: nextDef });
  };

  const handleUndo = () => {
    if (history.length === 0 || !dashboardPayload) return;
    const prev = history[history.length - 1];
    setFuture((f) => [dashboardPayload.definition, ...f]);
    setHistory((h) => h.slice(0, -1));
    setDashboardPayload({ ...dashboardPayload, definition: prev });
  };

  const handleRedo = () => {
    if (future.length === 0 || !dashboardPayload) return;
    const next = future[0];
    setHistory((h) => [...h, dashboardPayload.definition]);
    setFuture((f) => f.slice(1));
    setDashboardPayload({ ...dashboardPayload, definition: next });
  };

  const handleSaveVersion = async () => {
    if (!activeDashboardId || !dashboardPayload?.definition) return;
    setSaving(true);
    setError(null);
    try {
      const res = await api.updateDashboard(
        activeDashboardId,
        dashboardPayload.definition,
        dashboardPayload.definition.title,
        'Interactive layout & metric edit'
      );
      setDashboardPayload(res);
      await onRefreshProject();
      setHistory([]);
      setFuture([]);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const tiles: any[] = dashboardPayload?.definition?.tiles || [];
  const hydratedMap = new Map<string, any>(
    (dashboardPayload?.hydrated_tiles || []).map((rt: any) => [rt.id, rt])
  );

  return (
    <div className="space-y-5">
      {/* Top Toolbar */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <LayoutGrid className="h-5 w-5 text-blue-600" />
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Mode 3: Auto-Dashboard & 12-Column Interactive Canvas
            </h2>
            <p className="text-xs text-slate-500">
              Max 6 tiles per view (Rule 7.3) · Click any bar/slice to cross-filter every tile · Versioned layout history
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {dashboards.filter((d) => d.dataset_id === datasetId).length > 0 && (
            <select
              value={activeDashboardId || ''}
              onChange={(e) => setActiveDashboardId(e.target.value)}
              className="rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-800"
            >
              {dashboards
                .filter((d) => d.dataset_id === datasetId)
                .map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.title} (v{d.current_version})
                  </option>
                ))}
            </select>
          )}

          <button
            type="button"
            disabled={loading}
            onClick={handleGenerateAutoDashboard}
            className="inline-flex items-center gap-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 px-4 py-2 text-xs font-semibold text-white shadow-sm"
          >
            <Sparkles className="h-4 w-4" />
            {loading ? 'Generating...' : 'Generate 6-Tile Dashboard'}
          </button>

          {dashboardPayload && (
            <>
              <button
                type="button"
                onClick={() => setEditMode(!editMode)}
                className={`inline-flex items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-semibold ${
                  editMode
                    ? 'border-amber-500 bg-amber-50 text-amber-900'
                    : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Edit3 className="h-3.5 w-3.5" />
                {editMode ? 'Editing Layout' : 'Edit Tiles'}
              </button>

              {editMode && (
                <>
                  <button
                    type="button"
                    disabled={history.length === 0}
                    onClick={handleUndo}
                    className="rounded-lg border border-slate-200 p-2 text-slate-700 disabled:opacity-40"
                    title="Undo layout edit"
                  >
                    <Undo2 className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    disabled={future.length === 0}
                    onClick={handleRedo}
                    className="rounded-lg border border-slate-200 p-2 text-slate-700 disabled:opacity-40"
                    title="Redo layout edit"
                  >
                    <Redo2 className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    disabled={saving}
                    onClick={handleSaveVersion}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-3.5 py-2 text-xs font-semibold text-white"
                  >
                    <Save className="h-3.5 w-3.5" />
                    {saving ? 'Saving...' : 'Save New Version'}
                  </button>
                </>
              )}
            </>
          )}
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-800">
          {error}
        </div>
      )}

      {/* Global Cross-Filter Bar */}
      {dashboardPayload && (
        <div className="rounded-xl border border-slate-200 bg-white px-4 py-3 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-bold text-slate-700">
              {dashboardPayload.title} (v{dashboardPayload.current_version}) · Active Cross-Filters:
            </span>
            {activeFilters.length === 0 ? (
              <span className="text-slate-500">
                All segments included — click any bar or slice below to cross-filter the entire dashboard
              </span>
            ) : (
              activeFilters.map((f, idx) => (
                <span
                  key={idx}
                  className="inline-flex items-center gap-1.5 rounded-full bg-blue-600 text-white px-3 py-0.5 font-semibold"
                >
                  {f.field} = {String(f.value)}
                  <button
                    type="button"
                    onClick={() => setActiveFilters((prev) => prev.filter((_, i) => i !== idx))}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))
            )}
          </div>
          {activeFilters.length > 0 && (
            <button
              type="button"
              onClick={() => setActiveFilters([])}
              className="inline-flex items-center gap-1 rounded-lg bg-slate-900 hover:bg-slate-700 text-white px-3 py-1 font-semibold"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Reset All Filters
            </button>
          )}
        </div>
      )}

      {/* 12-Column Responsive Tile Grid */}
      {dashboardPayload && tiles.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {tiles.map((tile, idx) => {
            const rt = hydratedMap.get(tile.id);
            const w = tile.col_span || 6;
            const colSpan =
              w === 12
                ? 'lg:col-span-12'
                : w === 8
                ? 'lg:col-span-8'
                : w === 4
                ? 'lg:col-span-4'
                : 'lg:col-span-6';

            return (
              <div key={tile.id} className={`${colSpan} flex flex-col gap-1.5`}>
                {editMode && (
                  <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-1.5 text-xs">
                    <span className="font-bold text-amber-900">Tile #{idx + 1}</span>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <select
                        aria-label="Tile column span"
                        value={w}
                        onChange={(e) => {
                          const nextW = Number(e.target.value);
                          mutateDefinition((def) => {
                            def.tiles[idx].col_span = nextW;
                            return def;
                          });
                        }}
                        className="rounded border border-amber-300 bg-white px-1.5 py-0.5 text-[11px]"
                      >
                        <option value={4}>4 cols (1/3)</option>
                        <option value={6}>6 cols (1/2)</option>
                        <option value={8}>8 cols (2/3)</option>
                        <option value={12}>12 cols (Full)</option>
                      </select>

                      <select
                        aria-label="Tile chart type"
                        value={tile.spec?.chart_type || 'bar_h'}
                        onChange={(e) => {
                          const ct = e.target.value;
                          mutateDefinition((def) => {
                            def.tiles[idx].spec.chart_type = ct;
                            return def;
                          });
                        }}
                        className="rounded border border-amber-300 bg-white px-1.5 py-0.5 text-[11px]"
                      >
                        {['kpi', 'bar_h', 'bar', 'line', 'donut', 'pct_bar', 'table'].map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>

                      <select
                        aria-label="Tile primary metric"
                        value={tile.spec?.measures?.[0]?.metric || ''}
                        onChange={(e) => {
                          const mk = e.target.value;
                          mutateDefinition((def) => {
                            def.tiles[idx].spec.measures = [{ metric: mk }];
                            def.tiles[idx].spec.title = null;
                            return def;
                          });
                        }}
                        className="rounded border border-amber-300 bg-white px-1.5 py-0.5 text-[11px]"
                      >
                        {availableMetrics.map((m) => (
                          <option key={m.metric_key} value={m.metric_key}>
                            {m.label}
                          </option>
                        ))}
                      </select>

                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() =>
                          mutateDefinition((def) => {
                            const tmp = def.tiles[idx - 1];
                            def.tiles[idx - 1] = def.tiles[idx];
                            def.tiles[idx] = tmp;
                            return def;
                          })
                        }
                        className="rounded border border-amber-300 bg-white p-1 disabled:opacity-40"
                        title="Move tile earlier"
                      >
                        <ArrowUp className="h-3 w-3" />
                      </button>

                      <button
                        type="button"
                        disabled={idx === tiles.length - 1}
                        onClick={() =>
                          mutateDefinition((def) => {
                            const tmp = def.tiles[idx + 1];
                            def.tiles[idx + 1] = def.tiles[idx];
                            def.tiles[idx] = tmp;
                            return def;
                          })
                        }
                        className="rounded border border-amber-300 bg-white p-1 disabled:opacity-40"
                        title="Move tile later"
                      >
                        <ArrowDown className="h-3 w-3" />
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          mutateDefinition((def) => {
                            def.tiles.splice(idx, 1);
                            return def;
                          })
                        }
                        className="rounded border border-rose-300 bg-rose-50 text-rose-700 p-1"
                        title="Remove tile"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                )}

                {rt && history.length === 0 ? (
                  <ChartCanvas
                    render={rt.render}
                    query={rt.query}
                    spec={rt.spec}
                    height={w === 12 ? 220 : 280}
                    compact
                    onMarkClick={handleTileCrossFilter}
                  />
                ) : (
                  <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-6 text-xs text-amber-900">
                    <div className="font-bold">{tile.title || tile.spec?.chart_type}</div>
                    <p className="mt-1">
                      Modified layout ({w} cols · {tile.spec?.chart_type} · {tile.spec?.measures?.[0]?.metric}). Click{' '}
                      <strong>Save New Version</strong> above to re-compile and render all tiles.
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="rounded-2xl border-2 border-dashed border-slate-300 bg-white p-12 text-center">
          <LayoutGrid className="h-10 w-10 text-blue-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-900">No dashboard generated for this dataset yet</h3>
          <p className="text-xs text-slate-600 max-w-md mx-auto mt-1 mb-4">
            Click <strong>Generate 6-Tile Dashboard</strong> to automatically compose a 12-column executive layout (Headline KPI Strip, Monthly Trend, Ranked Breakdown, Composition Share, Variance/Risk, and Detail Table) directly from your semantic model.
          </p>
          <button
            type="button"
            onClick={handleGenerateAutoDashboard}
            className="inline-flex items-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-500 px-5 py-2.5 text-xs font-semibold text-white shadow-sm"
          >
            <Sparkles className="h-4 w-4" /> Generate 6-Tile Dashboard Now
          </button>
        </div>
      )}
    </div>
  );
};
