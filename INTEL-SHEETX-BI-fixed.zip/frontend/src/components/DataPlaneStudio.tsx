import React, { useEffect, useState } from 'react';
import {
  Upload,
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  Trash2,
  Eye,
  Database,
  RefreshCw,
} from 'lucide-react';
import { api, FieldMeta, MetricMeta } from '../api/client';

interface DataPlaneStudioProps {
  projectId: string;
  datasets: any[];
  activeDatasetId: string | null;
  profileData: any | null;
  onDatasetCreatedOrUpdated: (datasetId?: string) => Promise<void>;
  onSelectDataset: (datasetId: string) => void;
}

export const DataPlaneStudio: React.FC<DataPlaneStudioProps> = ({
  projectId,
  datasets,
  activeDatasetId,
  profileData,
  onDatasetCreatedOrUpdated,
  onSelectDataset,
}) => {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pendingXlsxFile, setPendingXlsxFile] = useState<File | null>(null);
  const [pendingFixtureName, setPendingFixtureName] = useState<string | null>(null);
  const [xlsxSheets, setXlsxSheets] = useState<any[]>([]);
  const [preview, setPreview] = useState<any | null>(null);
  const [subTab, setSubTab] = useState<'profile' | 'preview' | 'quality' | 'governance'>('profile');
  const [deleteConfirmText, setDeleteConfirmText] = useState('');

  useEffect(() => {
    if (activeDatasetId && subTab === 'preview') {
      api.getDatasetPreview(activeDatasetId, 0, 40).then(setPreview).catch(() => {});
    }
  }, [activeDatasetId, subTab, profileData?.version]);

  const handleFileChange = async (file: File | undefined) => {
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const res = await api.uploadFile(projectId, file);
      if (res.requires_sheet_selection) {
        setPendingXlsxFile(file);
        setPendingFixtureName(null);
        setXlsxSheets(res.sheets || []);
      } else {
        await onDatasetCreatedOrUpdated(res.dataset_id);
      }
    } catch (err: any) {
      setError(err.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleIngestFixture = async (fixtureName: string, sheetName?: string) => {
    setUploading(true);
    setError(null);
    try {
      const res = await api.ingestFixture(projectId, fixtureName, sheetName);
      if (res.requires_sheet_selection) {
        setPendingFixtureName(fixtureName);
        setPendingXlsxFile(null);
        setXlsxSheets(res.sheets || []);
      } else {
        setXlsxSheets([]);
        setPendingFixtureName(null);
        await onDatasetCreatedOrUpdated(res.dataset_id);
      }
    } catch (err: any) {
      setError(err.message || 'Fixture ingestion failed');
    } finally {
      setUploading(false);
    }
  };

  const handlePickSheet = async (sheetName: string) => {
    if (pendingFixtureName) {
      await handleIngestFixture(pendingFixtureName, sheetName);
      return;
    }
    if (!pendingXlsxFile) return;
    setUploading(true);
    setError(null);
    try {
      const res = await api.uploadFile(projectId, pendingXlsxFile, sheetName);
      setXlsxSheets([]);
      setPendingXlsxFile(null);
      await onDatasetCreatedOrUpdated(res.dataset_id);
    } catch (err: any) {
      setError(err.message || 'Sheet parse failed');
    } finally {
      setUploading(false);
    }
  };

  const handleRoleOverride = async (fieldName: string, newRole: string) => {
    if (!activeDatasetId) return;
    try {
      await api.patchFields(activeDatasetId, [{ name: fieldName, role: newRole }]);
      await onDatasetCreatedOrUpdated(activeDatasetId);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleToggleAiExclude = async (field: FieldMeta) => {
    if (!activeDatasetId) return;
    try {
      await api.patchFields(activeDatasetId, [
        { name: field.name, exclude_from_ai: !field.exclude_from_ai },
      ]);
      await onDatasetCreatedOrUpdated(activeDatasetId);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteDataset = async () => {
    if (!activeDatasetId || !profileData?.dataset) return;
    try {
      await api.deleteDataset(activeDatasetId, deleteConfirmText);
      setDeleteConfirmText('');
      await onDatasetCreatedOrUpdated(undefined);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const fields: FieldMeta[] = profileData?.fields || [];
  const warnings: any[] = profileData?.profile?.quality_warnings || [];
  const metrics: MetricMeta[] = profileData?.metrics || [];

  return (
    <div className="space-y-6">
      {/* Upload & Verified Fixture Bar */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Database className="h-5 w-5 text-blue-600" /> Data Plane: Upload, Parse & Semantic Profiling
            </h2>
            <p className="text-xs text-slate-600 max-w-2xl">
              Upload your own CSV or multi-sheet Excel (.xlsx) workbook. Every file is content-signature validated, snapped immutably by SHA-256 hash, materialised to columnar Parquet via DuckDB, and profiled across 11 column statistics.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-500 px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition">
              <Upload className="h-4 w-4" />
              <span>{uploading ? 'Parsing to Parquet...' : 'Upload CSV / XLSX'}</span>
              <input
                type="file"
                accept=".csv,.tsv,.xlsx"
                className="sr-only"
                disabled={uploading}
                onChange={(e) => handleFileChange(e.target.files?.[0])}
              />
            </label>

            <button
              type="button"
              disabled={uploading}
              onClick={() => handleIngestFixture('enterprise_india_sales_2026.csv')}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-slate-50 hover:bg-slate-100 px-3.5 py-2.5 text-xs font-semibold text-slate-800 transition"
              title="Runs real CSV file through /api/upload/fixture -> DuckDB -> Parquet"
            >
              <FileSpreadsheet className="h-4 w-4 text-teal-600" />
              Ingest Enterprise FY26 CSV (640 rows)
            </button>

            <button
              type="button"
              disabled={uploading}
              onClick={() => handleIngestFixture('sales_multi.xlsx')}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 px-3.5 py-2.5 text-xs font-medium text-slate-700 transition"
              title="Test multi-sheet XLSX sheet selection modal"
            >
              Multi-Sheet XLSX
            </button>
          </div>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-800 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600" />
            <span>{error}</span>
          </div>
        )}

        {/* Multi-sheet XLSX Picker Modal Inline */}
        {xlsxSheets.length > 0 && (
          <div className="mt-4 rounded-xl border-2 border-blue-500 bg-blue-50/60 p-4">
            <h3 className="text-sm font-bold text-slate-900">
              Multi-sheet XLSX detected — select the worksheet to parse into Parquet:
            </h3>
            <div className="mt-3 grid sm:grid-cols-3 gap-3">
              {xlsxSheets.map((s) => (
                <button
                  key={s.name}
                  type="button"
                  onClick={() => handlePickSheet(s.name)}
                  className="text-left rounded-xl border border-blue-200 bg-white hover:border-blue-600 p-3.5 shadow-sm transition"
                >
                  <div className="font-semibold text-sm text-blue-700">{s.name}</div>
                  <div className="text-xs text-slate-500 mt-1">
                    ~{s.sample_row_count} sample rows · Columns: {s.headers.slice(0, 4).join(', ')}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Dataset Switcher Pills */}
        {datasets.length > 0 && (
          <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-slate-500 mr-1">Project Datasets:</span>
            {datasets.map((ds) => (
              <button
                key={ds.id}
                type="button"
                onClick={() => onSelectDataset(ds.id)}
                className={`inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium border transition ${
                  ds.id === activeDatasetId
                    ? 'border-blue-600 bg-blue-50 text-blue-800 font-semibold'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span>{ds.name}</span>
                <span className="rounded bg-slate-200/70 px-1.5 py-0.5 text-[10px] text-slate-700">
                  v{ds.current_version} · {Number(ds.row_count).toLocaleString()}r × {ds.column_count}c
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Active Dataset Profile & Governance */}
      {profileData ? (
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          {/* Grain & Parse Summary Strip */}
          <div className="bg-slate-900 text-white px-6 py-4 flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-blue-400">
                  Declared Grain & Scope
                </span>
                <span className="rounded-full bg-slate-800 px-2.5 py-0.5 text-[11px] font-mono text-emerald-300">
                  v{profileData.version} · {profileData.parse_report?.encoding} · Parquet
                </span>
              </div>
              <p className="text-sm font-medium text-slate-100 mt-1">
                {profileData.profile?.grain_statement}
              </p>
            </div>
            <div className="flex items-center gap-6 text-xs">
              <div>
                <div className="text-slate-400">Exact Rows</div>
                <div className="text-base font-bold">{Number(profileData.profile?.row_count || 0).toLocaleString()}</div>
              </div>
              <div>
                <div className="text-slate-400">Columns</div>
                <div className="text-base font-bold">{profileData.profile?.column_count}</div>
              </div>
              <div>
                <div className="text-slate-400">Active Metrics</div>
                <div className="text-base font-bold text-emerald-400">
                  {metrics.filter((m) => m.available).length} / {metrics.length}
                </div>
              </div>
              <div>
                <div className="text-slate-400">Quality Flags</div>
                <div className="text-base font-bold text-amber-400">{warnings.length}</div>
              </div>
            </div>
          </div>

          {/* Sub-navigation */}
          <div className="border-b border-slate-200 px-6 flex gap-6 bg-slate-50/70 text-xs font-semibold">
            {[
              { id: 'profile', label: `Semantic Field Profile (${fields.length})` },
              { id: 'quality', label: `Quality & Grain Warnings (${warnings.length})` },
              { id: 'preview', label: 'Parquet Row Preview' },
              { id: 'governance', label: 'Retention & Tombstone Delete' },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setSubTab(t.id as any)}
                className={`py-3 border-b-2 transition ${
                  subTab === t.id
                    ? 'border-blue-600 text-blue-700'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="p-6">
            {subTab === 'profile' && (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200 text-xs">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-3 py-2.5 text-left font-semibold text-slate-700">Column</th>
                      <th className="px-3 py-2.5 text-left font-semibold text-slate-700">Physical</th>
                      <th className="px-3 py-2.5 text-left font-semibold text-slate-700">Role (One-Click Override)</th>
                      <th className="px-3 py-2.5 text-left font-semibold text-slate-700">Semantic</th>
                      <th className="px-3 py-2.5 text-right font-semibold text-slate-700">Distinct</th>
                      <th className="px-3 py-2.5 text-right font-semibold text-slate-700">Null %</th>
                      <th className="px-3 py-2.5 text-left font-semibold text-slate-700">Min → Max</th>
                      <th className="px-3 py-2.5 text-center font-semibold text-slate-700">AI Context</th>
                      <th className="px-3 py-2.5 text-left font-semibold text-slate-700">Classification Reason</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {fields.map((f) => (
                      <tr key={f.id} className="hover:bg-slate-50/80">
                        <td className="px-3 py-2.5 font-semibold text-slate-900 whitespace-nowrap">
                          {f.name}
                          {f.overridden_by && (
                            <span className="ml-1.5 rounded bg-purple-100 px-1.5 py-0.5 text-[10px] font-medium text-purple-800">
                              Overridden
                            </span>
                          )}
                        </td>
                        <td className="px-3 py-2.5 font-mono text-slate-500">{f.physical_type}</td>
                        <td className="px-3 py-2.5">
                          <select
                            aria-label={`Role override for ${f.name}`}
                            value={f.role}
                            onChange={(e) => handleRoleOverride(f.name, e.target.value)}
                            className={`rounded-md border px-2 py-1 text-xs font-semibold ${
                              f.role === 'measure'
                                ? 'border-emerald-300 bg-emerald-50 text-emerald-800'
                                : f.role === 'dimension'
                                ? 'border-blue-300 bg-blue-50 text-blue-800'
                                : f.role === 'date'
                                ? 'border-amber-300 bg-amber-50 text-amber-800'
                                : f.role === 'identifier'
                                ? 'border-purple-300 bg-purple-50 text-purple-800'
                                : 'border-slate-300 bg-slate-50 text-slate-700'
                            }`}
                          >
                            <option value="dimension">dimension</option>
                            <option value="measure">measure</option>
                            <option value="identifier">identifier (no SUM)</option>
                            <option value="date">date</option>
                            <option value="detail">detail</option>
                          </select>
                        </td>
                        <td className="px-3 py-2.5 text-slate-700">
                          {f.semantic_type}
                          {f.additive === 'non_additive' && (
                            <span className="ml-1 text-[10px] text-rose-700 font-semibold">(non-additive)</span>
                          )}
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono">{f.distinct_count.toLocaleString()}</td>
                        <td className="px-3 py-2.5 text-right font-mono">
                          <span className={f.null_rate > 0 ? 'text-amber-700 font-semibold' : 'text-slate-500'}>
                            {(f.null_rate * 100).toFixed(1)}%
                          </span>
                        </td>
                        <td className="px-3 py-2.5 font-mono text-slate-600 whitespace-nowrap">
                          {f.stats?.min !== null && f.stats?.min !== undefined
                            ? `${f.stats.min} → ${f.stats.max}`
                            : '—'}
                        </td>
                        <td className="px-3 py-2.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleToggleAiExclude(f)}
                            className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold border ${
                              f.exclude_from_ai
                                ? 'border-rose-300 bg-rose-50 text-rose-700'
                                : 'border-emerald-300 bg-emerald-50 text-emerald-700'
                            }`}
                            title="Chapter 33.3 PII & AI Context Minimisation Toggle"
                          >
                            {f.exclude_from_ai ? 'Excluded (PII)' : 'Permitted'}
                          </button>
                        </td>
                        <td className="px-3 py-2.5 text-slate-600 max-w-md">{f.reason}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {subTab === 'quality' && (
              <div className="space-y-3">
                {warnings.length === 0 ? (
                  <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-xs text-emerald-800">
                    <CheckCircle2 className="h-4 w-4 shrink-0" />
                    <span>Zero missing values, duplicate rows, or date parse failures detected across this dataset version.</span>
                  </div>
                ) : (
                  warnings.map((w, i) => (
                    <div
                      key={i}
                      className={`rounded-xl border p-4 flex items-start gap-3 text-xs ${
                        w.severity === 'high'
                          ? 'border-rose-200 bg-rose-50 text-rose-900'
                          : 'border-amber-200 bg-amber-50 text-amber-900'
                      }`}
                    >
                      <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold uppercase tracking-wider text-[10px]">
                          {w.severity} severity · {w.kind} · Column: {w.column}
                        </div>
                        <p className="mt-1">{w.message}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {subTab === 'preview' && (
              <div>
                <div className="flex items-center justify-between mb-3 text-xs text-slate-600">
                  <span className="flex items-center gap-1.5">
                    <Eye className="h-4 w-4 text-blue-600" /> Paginated directly from versioned DuckDB Parquet snapshot
                  </span>
                  <button
                    type="button"
                    onClick={() => activeDatasetId && api.getDatasetPreview(activeDatasetId, 0, 40).then(setPreview)}
                    className="inline-flex items-center gap-1 text-blue-600 font-semibold hover:underline"
                  >
                    <RefreshCw className="h-3.5 w-3.5" /> Refresh Preview
                  </button>
                </div>
                {preview ? (
                  <div className="max-h-96 overflow-auto rounded-xl border border-slate-200">
                    <table className="min-w-full divide-y divide-slate-200 text-xs">
                      <thead className="bg-slate-50 sticky top-0">
                        <tr>
                          {preview.columns.map((c: string) => (
                            <th key={c} className="px-3 py-2 text-left font-semibold text-slate-700 whitespace-nowrap">
                              {c}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 bg-white">
                        {preview.rows.map((r: any, idx: number) => (
                          <tr key={idx} className="hover:bg-slate-50">
                            {preview.columns.map((c: string) => (
                              <td key={c} className="px-3 py-1.5 font-mono text-slate-700 whitespace-nowrap">
                                {r[c] === null || r[c] === undefined ? 'NULL' : String(r[c])}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500">Loading Parquet rows...</p>
                )}
              </div>
            )}

            {subTab === 'governance' && (
              <div className="max-w-xl rounded-xl border border-rose-200 bg-rose-50/50 p-5 space-y-3">
                <div className="flex items-center gap-2 text-sm font-bold text-rose-900">
                  <ShieldAlert className="h-4 w-4 text-rose-600" /> Permanent Artifact Deletion & Audit Tombstone (Chapter 33.4)
                </div>
                <p className="text-xs text-rose-800 leading-relaxed">
                  Deleting a dataset permanently removes its Parquet versions, unreferenced raw upload snapshot, derived profiles, dashboards, and in-memory query cache entries, leaving only an audited tombstone row.
                </p>
                <div className="pt-1">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Type exact dataset name <code className="bg-white px-1.5 py-0.5 rounded border">{profileData.dataset?.name}</code> to confirm:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={deleteConfirmText}
                      onChange={(e) => setDeleteConfirmText(e.target.value)}
                      placeholder={profileData.dataset?.name}
                      className="flex-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs"
                    />
                    <button
                      type="button"
                      disabled={deleteConfirmText !== profileData.dataset?.name}
                      onClick={handleDeleteDataset}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 disabled:opacity-40 px-4 py-1.5 text-xs font-semibold text-white"
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Delete Dataset
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="rounded-2xl border-2 border-dashed border-slate-300 bg-white p-12 text-center">
          <FileSpreadsheet className="h-10 w-10 text-blue-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-900">Your project has no datasets yet</h3>
          <p className="text-xs text-slate-600 max-w-md mx-auto mt-1">
            Per Non-Negotiable Rule #1, INTEL SHEETX BI never displays fake or pre-baked sample charts. Upload your own CSV/XLSX above, or click <strong>Ingest Enterprise FY26 CSV</strong> to parse a real 640-row dataset through DuckDB into Parquet now.
          </p>
        </div>
      )}
    </div>
  );
};
