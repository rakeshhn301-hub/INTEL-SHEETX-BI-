import React, { useState } from 'react';
import { Database, ShieldCheck, Terminal, BarChart3, Sparkles } from 'lucide-react';
import { api, User } from '../api/client';

interface AuthScreenProps {
  onAuthenticated: (user: User) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onAuthenticated }) => {
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [name, setName] = useState('Aarav Sharma');
  const [email, setEmail] = useState('analyst@intelsheetx.ai');
  const [password, setPassword] = useState('SheetX2026!');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const user =
        mode === 'register'
          ? await api.register(name, email, password)
          : await api.login(email, password);
      onAuthenticated(user);
    } catch (err: any) {
      // If demo default email is already registered, seamlessly offer or try login
      if (mode === 'register' && String(err.message).includes('already exists')) {
        try {
          const u = await api.login(email, password);
          onAuthenticated(u);
          return;
        } catch {
          setMode('login');
        }
      }
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col lg:flex-row">
      {/* Left Brand & Handbook Guarantees */}
      <div className="lg:w-7/12 p-8 lg:p-16 flex flex-col justify-between bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 border-b lg:border-b-0 lg:border-r border-slate-800">
        <div>
          <div className="inline-flex items-center gap-2.5 rounded-full border border-blue-500/30 bg-blue-500/10 px-3.5 py-1 text-xs font-semibold text-blue-300">
            <Sparkles className="h-3.5 w-3.5" /> INTEL SHEETX BI · 2026 Production Build
          </div>
          <h1 className="mt-6 text-3xl sm:text-5xl font-bold tracking-tight text-white leading-tight">
            From raw rows to verified decisions — in one command.
          </h1>
          <p className="mt-4 text-base text-slate-300 max-w-xl leading-relaxed">
            Upload CSV or multi-sheet XLSX files. INTEL SHEETX BI profiles your grain, governs 15 reusable metrics, compiles plain-English commands into parameterized DuckDB SQL over Parquet, and verifies every AI figure against executed query evidence.
          </p>

          <div className="mt-10 grid sm:grid-cols-2 gap-4 max-w-2xl">
            <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-blue-400">
                <Terminal className="h-4 w-4" /> Deterministic Command Compiler
              </div>
              <p className="mt-1.5 text-xs text-slate-400">
                10 intent archetypes (<code className="text-slate-200">/bar</code>, <code className="text-slate-200">/line</code>, <code className="text-slate-200">/scatter</code>, NL) compiled into bound SQL — never LLM-hallucinated code.
              </p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-teal-400">
                <Database className="h-4 w-4" /> DuckDB + Parquet Data Plane
              </div>
              <p className="mt-1.5 text-xs text-slate-400">
                Server-side columnar aggregation, SUM/SUM ratio enforcement, identifier sum blocking, and join fan-out gates.
              </p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-amber-400">
                <BarChart3 className="h-4 w-4" /> 6-Tile Auto-Dashboard & Planner
              </div>
              <p className="mt-1.5 text-xs text-slate-400">
                One-click 12-column executive dashboards with live cross-filtering, undo/redo history, and filtered exports.
              </p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-emerald-400">
                <ShieldCheck className="h-4 w-4" /> Provenance-Bound Agent
              </div>
              <p className="mt-1.5 text-xs text-slate-400">
                Multi-step 12-tool investigation where every numeric token is checked against executed EvidenceBundles.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-slate-800/80 text-xs text-slate-500 flex flex-wrap justify-between gap-2">
          <span>Every answer is a real query — rendered, explained, traceable.</span>
          <span>Multi-tenant RBAC · HTTP 404 Object Isolation</span>
        </div>
      </div>

      {/* Right Sign-in / Register Form */}
      <div className="lg:w-5/12 p-8 lg:p-16 flex items-center justify-center bg-slate-950">
        <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-900 p-8 shadow-2xl">
          <div className="flex rounded-lg bg-slate-950 p-1 border border-slate-800 mb-6">
            <button
              type="button"
              onClick={() => setMode('register')}
              className={`flex-1 rounded-md py-2 text-xs font-semibold transition ${
                mode === 'register' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Create Workspace
            </button>
            <button
              type="button"
              onClick={() => setMode('login')}
              className={`flex-1 rounded-md py-2 text-xs font-semibold transition ${
                mode === 'login' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Sign In
            </button>
          </div>

          <h2 className="text-xl font-bold text-white">
            {mode === 'register' ? 'Start your BI workspace' : 'Sign in to your workspace'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Pre-filled credentials let you enter in one click, or register a second account to test 404 tenant isolation.
          </p>

          {error && (
            <div className="mt-4 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3.5 py-2.5 text-xs text-rose-200">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-5 space-y-4">
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1" htmlFor="auth-name">
                  Full Name
                </label>
                <input
                  id="auth-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white focus:border-blue-500"
                />
              </div>
            )}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1" htmlFor="auth-email">
                Work Email
              </label>
              <input
                id="auth-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1" htmlFor="auth-password">
                Password
              </label>
              <input
                id="auth-password"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white focus:border-blue-500"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-600/20 transition"
            >
              {loading ? 'Authenticating...' : mode === 'register' ? 'Create Account & Launch Studio' : 'Sign In'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
