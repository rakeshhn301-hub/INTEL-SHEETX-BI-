import React, { useEffect, useState } from 'react';
import {
  Database,
  Terminal,
  Compass,
  LayoutGrid,
  Bot,
  FolderPlus,
  LogOut,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { api, ProjectSummary, User } from './api/client';
import { AuthScreen } from './components/AuthScreen';
import { DataPlaneStudio } from './components/DataPlaneStudio';
import { CommandAndBuilderStudio } from './components/CommandAndBuilderStudio';
import { DashboardStudio } from './components/DashboardStudio';
import { PlannerAndAgentStudio } from './components/PlannerAndAgentStudio';

type StudioTab = 'data' | 'command' | 'planner' | 'dashboard' | 'agent';

export const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [booting, setBooting] = useState(true);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [projectDetail, setProjectDetail] = useState<any | null>(null);
  const [activeDatasetId, setActiveDatasetId] = useState<string | null>(null);
  const [profileData, setProfileData] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState<StudioTab>('data');
  const [queuedCommand, setQueuedCommand] = useState<string | null>(null);
  const [showNewProjModal, setShowNewProjModal] = useState(false);
  const [newProjName, setNewProjName] = useState('');

  useEffect(() => {
    api
      .me()
      .then((r) => setUser(r.user))
      .catch(() => setUser(null))
      .finally(() => setBooting(false));
  }, []);

  useEffect(() => {
    if (user) {
      refreshProjects();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  useEffect(() => {
    if (activeProjectId) {
      refreshProjectDetail(activeProjectId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeProjectId]);

  useEffect(() => {
    if (activeDatasetId) {
      refreshDatasetProfile(activeDatasetId);
    } else {
      setProfileData(null);
    }
  }, [activeDatasetId]);

  const refreshProjects = async () => {
    const res = await api.listProjects();
    let list = res.projects || [];
    if (list.length === 0) {
      const created = await api.createProject(
        'Commercial Analytics',
        'Default governed BI workspace project'
      );
      list = [created.project];
    }
    setProjects(list);
    if (list.length > 0 && (!activeProjectId || !list.some((p) => p.id === activeProjectId))) {
      setActiveProjectId(list[0].id);
    }
  };

  const refreshProjectDetail = async (projectId: string, preferredDatasetId?: string) => {
    const det = await api.getProject(projectId);
    setProjectDetail(det);
    const dsList = det.datasets || [];
    if (preferredDatasetId && dsList.some((d: any) => d.id === preferredDatasetId)) {
      setActiveDatasetId(preferredDatasetId);
      await refreshDatasetProfile(preferredDatasetId);
    } else if (dsList.length > 0) {
      const keep = dsList.some((d: any) => d.id === activeDatasetId)
        ? activeDatasetId!
        : dsList[0].id;
      setActiveDatasetId(keep);
      await refreshDatasetProfile(keep);
    } else {
      setActiveDatasetId(null);
      setProfileData(null);
      setActiveTab('data');
    }
  };

  const refreshDatasetProfile = async (datasetId: string) => {
    const prof = await api.getDatasetProfile(datasetId);
    setProfileData(prof);
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjName.trim()) return;
    const res = await api.createProject(newProjName.trim(), 'Analytical workspace project');
    setNewProjName('');
    setShowNewProjModal(false);
    await refreshProjects();
    setActiveProjectId(res.project.id);
    setActiveTab('data');
  };

  if (booting) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center text-sm font-medium">
        Initialising INTEL SHEETX BI...
      </div>
    );
  }

  if (!user) {
    return <AuthScreen onAuthenticated={setUser} />;
  }

  const datasets = projectDetail?.datasets || [];
  const dashboards = projectDetail?.dashboards || [];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Top Executive Navigation Shell */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="max-w-[1480px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-sm">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-extrabold tracking-tight text-slate-900">
                  INTEL SHEETX BI
                </span>
                <span className="hidden sm:inline-flex items-center gap-1 rounded-full bg-emerald-50 border border-emerald-200 px-2 py-0.5 text-[10px] font-bold text-emerald-800">
                  <CheckCircle2 className="h-3 w-3" /> DuckDB + Parquet
                </span>
              </div>
              <div className="text-[11px] text-slate-500 hidden sm:block">
                Governed Metrics · Command Compiler · Provenance-Verified AI
              </div>
            </div>

            <div className="h-6 w-px bg-slate-200 mx-1 hidden md:block" />

            {/* Project Selector */}
            <div className="flex items-center gap-1.5">
              <select
                aria-label="Active Project"
                value={activeProjectId || ''}
                onChange={(e) => setActiveProjectId(e.target.value)}
                className="rounded-lg border border-slate-300 bg-slate-50 px-2.5 py-1.5 text-xs font-semibold text-slate-800"
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.member_role})
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => setShowNewProjModal(true)}
                className="rounded-lg border border-slate-200 hover:bg-slate-100 p-1.5 text-slate-600"
                title="Create new project"
              >
                <FolderPlus className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Active Dataset Pill & User Controls */}
          <div className="flex items-center gap-3">
            {datasets.length > 0 && (
              <div className="hidden xl:flex items-center gap-1.5 text-xs">
                <span className="text-slate-400 font-medium">Dataset:</span>
                <select
                  aria-label="Active Dataset"
                  value={activeDatasetId || ''}
                  onChange={(e) => setActiveDatasetId(e.target.value)}
                  className="rounded-lg border border-blue-200 bg-blue-50/70 px-2.5 py-1 font-semibold text-blue-900"
                >
                  {datasets.map((ds: any) => (
                    <option key={ds.id} value={ds.id}>
                      {ds.name} (v{ds.current_version} · {Number(ds.row_count).toLocaleString()} rows)
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="text-right hidden sm:block">
              <div className="text-xs font-semibold text-slate-800">{user.name}</div>
              <div className="text-[11px] text-slate-500">{user.email}</div>
            </div>
            <button
              type="button"
              onClick={async () => {
                await api.logout();
                setUser(null);
              }}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-700"
              title="Sign out"
            >
              <LogOut className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* 4-Mode Navigation Tabs */}
        <div className="max-w-[1480px] mx-auto px-4 sm:px-6 flex overflow-x-auto gap-1 border-t border-slate-100 bg-slate-50/60">
          {[
            { id: 'data', label: 'Data Plane & Semantic Model', icon: Database, needsDs: false },
            { id: 'command', label: 'Mode 1: Command & Chart Builder', icon: Terminal, needsDs: true },
            { id: 'planner', label: 'Mode 2: Analysis Brief & Insights', icon: Compass, needsDs: true },
            { id: 'dashboard', label: 'Mode 3: 6-Tile Auto-Dashboard', icon: LayoutGrid, needsDs: true },
            { id: 'agent', label: 'Mode 4: 12-Tool Agent & Digests', icon: Bot, needsDs: true },
          ].map((tab) => {
            const Icon = tab.icon;
            const disabled = tab.needsDs && !activeDatasetId;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                disabled={disabled}
                onClick={() => setActiveTab(tab.id as StudioTab)}
                className={`inline-flex items-center gap-2 whitespace-nowrap px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
                  active
                    ? 'border-blue-600 text-blue-700 bg-white'
                    : disabled
                    ? 'border-transparent text-slate-400 cursor-not-allowed'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Workspace View */}
      <main className="max-w-[1480px] w-full mx-auto px-4 sm:px-6 py-6 flex-1">
        {activeProjectId && activeTab === 'data' && (
          <DataPlaneStudio
            projectId={activeProjectId}
            datasets={datasets}
            activeDatasetId={activeDatasetId}
            profileData={profileData}
            onDatasetCreatedOrUpdated={async (dsId) => {
              await refreshProjects();
              await refreshProjectDetail(activeProjectId, dsId);
              if (dsId) setActiveTab('command');
            }}
            onSelectDataset={(id) => setActiveDatasetId(id)}
          />
        )}

        {activeProjectId && activeDatasetId && profileData && activeTab === 'command' && (
          <CommandAndBuilderStudio
            projectId={activeProjectId}
            datasetId={activeDatasetId}
            profileData={profileData}
            initialCommand={queuedCommand}
            onConsumeInitialCommand={() => setQueuedCommand(null)}
            onRefreshDatasetProfile={() => refreshDatasetProfile(activeDatasetId)}
          />
        )}

        {activeProjectId && activeDatasetId && profileData && activeTab === 'planner' && (
          <PlannerAndAgentStudio
            mode="planner"
            projectId={activeProjectId}
            datasetId={activeDatasetId}
            profileData={profileData}
            onJumpToCommand={(cmd) => {
              setQueuedCommand(cmd);
              setActiveTab('command');
            }}
          />
        )}

        {activeProjectId && activeDatasetId && profileData && activeTab === 'dashboard' && (
          <DashboardStudio
            projectId={activeProjectId}
            datasetId={activeDatasetId}
            profileData={profileData}
            dashboards={dashboards}
            onRefreshProject={() => refreshProjectDetail(activeProjectId, activeDatasetId)}
          />
        )}

        {activeProjectId && activeDatasetId && profileData && activeTab === 'agent' && (
          <PlannerAndAgentStudio
            mode="agent"
            projectId={activeProjectId}
            datasetId={activeDatasetId}
            profileData={profileData}
            onJumpToCommand={(cmd) => {
              setQueuedCommand(cmd);
              setActiveTab('command');
            }}
          />
        )}
      </main>

      {/* New Project Modal */}
      {showNewProjModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-3">Create Analytical Project</h3>
            <form onSubmit={handleCreateProject} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Project Name</label>
                <input
                  type="text"
                  required
                  value={newProjName}
                  onChange={(e) => setNewProjName(e.target.value)}
                  placeholder="e.g. FY26 Commercial Operations"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewProjModal(false)}
                  className="rounded-lg border border-slate-300 px-4 py-1.5 font-semibold text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-blue-600 hover:bg-blue-500 px-4 py-1.5 font-semibold text-white"
                >
                  Create Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
