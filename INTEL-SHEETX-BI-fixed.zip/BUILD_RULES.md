# INTEL SHEETX BI — Non-Negotiable Build Rules (Chapter 35)

1. **No hardcoded, sample or placeholder data anywhere in a production code path.** No static chart images. No chart renders before a real query returns from DuckDB.
2. **The language model never computes numbers and never writes SQL, chart code, or arbitrary code.** It produces a validated JSON specification from a closed vocabulary (`A1_compare`..`A10_explain`, `UNSUPPORTED`). Deterministic code compiles and executes.
3. **All aggregation happens server-side in the DuckDB query engine over versioned Parquet files.** Raw dataset rows are never sent to the browser to compute totals client-side.
4. **Every metric is a named, documented, versioned object** with a formula, grain, null policy, and numeric tests verified against independently computed expected values.
5. **Ratio metrics are computed strictly as `SUM(numerator) / NULLIF(SUM(denominator), 0)` over the selected scope.** Never average a row-level ratio.
6. **Identifiers are never summed.** Detected at profiling time (`role = identifier`) and enforced in both the UI and the query compiler.
7. **Every API route authorises the specific object through workspace/project membership, returning HTTP 404** (never 403) for out-of-scope objects so existence is not leaked.
8. **Secrets stay server-side.** Never expose API keys or session secrets in client bundles or logs.
9. **Honest UI states.** Empty, loading, clarification, refusal-with-alternative, and error states are explicitly rendered.
10. **Provenance binding.** Every figure in an AI explanation, insight card, or agent run must appear in its executed `EvidenceBundle` within tolerance and trace to a stored `query_id`.
