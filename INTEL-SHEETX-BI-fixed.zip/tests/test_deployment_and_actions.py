import uuid
from fastapi.testclient import TestClient
from backend.app.main import app


def client():
    c = TestClient(app)
    email = f"regression-{uuid.uuid4().hex}@test.local"
    r = c.post('/api/auth/register', json={'name': 'Regression', 'email': email, 'password': 'StrongPassword123!'})
    assert r.status_code == 200, r.text
    return c, email


def test_auth_cookie_login_validation_and_logout():
    c, email = client()
    assert c.get('/api/auth/me').status_code == 200
    assert c.post('/api/auth/register', json={'name': 'Duplicate', 'email': email, 'password': 'StrongPassword123!'}).status_code == 409
    assert c.post('/api/auth/login', json={'email': email, 'password': 'wrong'}).status_code == 401
    assert c.post('/api/auth/register', json={'name': 'Bad', 'email': 'bad', 'password': 'x'}).status_code == 422
    assert c.post('/api/auth/logout').status_code == 200
    assert c.get('/api/auth/me').status_code == 401
    assert c.post('/api/auth/login', json={'email': email, 'password': 'StrongPassword123!'}).status_code == 200
    assert c.get('/api/auth/me').json()['user']['email'] == email


def test_production_frontend_and_unknown_api_routes():
    from backend.app.main import _WEB_ROOT
    c = TestClient(app)
    if (_WEB_ROOT / 'index.html').exists():
        r = c.get('/')
        assert r.status_code == 200 and 'INTEL SHEETX BI' in r.text
        import re
        assets = re.findall(r'(?:src|href)="(/assets/[^"]+)"', r.text)
        assert assets
        for asset in assets:
            assert c.get(asset).status_code == 200
    else:
        assert c.get('/').status_code == 503
    assert c.get('/api/not-an-endpoint').status_code == 404
    assert c.post('/api/auth/login', json={'email': 'missing@test.local', 'password': 'wrong'}).status_code == 401


def test_saved_chart_dashboard_edit_exports_and_sharing():
    c, _ = client()
    p = c.post('/api/projects', json={'name': 'Action audit'}).json()['project']['id']
    upload = c.post('/api/upload/fixture', json={'project_id': p, 'fixture_name': 'sales_small.csv'})
    assert upload.status_code == 200, upload.text
    ds = upload.json()['dataset_id']
    r = c.post('/api/command', json={'project_id': p, 'dataset_id': ds, 'text': '/bar sales by division'})
    assert r.status_code == 200, r.text
    spec = r.json()['spec']
    saved = c.post('/api/charts', json={'project_id': p, 'dataset_id': ds, 'title': 'Audit chart', 'spec': spec})
    assert saved.status_code == 200 and saved.json()['chart_id']
    metric = c.post('/api/metrics', json={'project_id': p, 'dataset_id': ds, 'metric_key': 'audit_sales', 'label': 'Audit Sales', 'expression': 'SUM(sales)'})
    assert metric.status_code == 200, metric.text
    for fmt in ('csv', 'xlsx', 'report_html'):
        export = c.post('/api/export', json={'dataset_id': ds, 'format': fmt, 'spec': spec})
        assert export.status_code == 200 and len(export.content) > 50, export.text[:200]
    dash = c.post('/api/dashboards/generate', json={'project_id': p, 'dataset_id': ds})
    assert dash.status_code == 200, dash.text
    d = dash.json()
    patch = c.patch('/api/dashboards/' + d['id'], json={'definition': d['definition'], 'title': 'Edited dashboard'})
    assert patch.status_code == 200, patch.text
    assert c.get('/api/dashboards/' + d['id']).json()['title'] == 'Edited dashboard'
    other, email = client()
    assert c.post(f'/api/projects/{p}/members', json={'email': email, 'role': 'viewer'}).status_code == 200
    assert other.get(f'/api/projects/{p}').status_code == 200
    assert other.delete(f'/api/datasets/{ds}').status_code == 404
    assert c.get(f'/api/command/logs?project_id={p}').status_code == 200
    assert c.get(f'/api/projects/{p}/jobs').status_code == 200
