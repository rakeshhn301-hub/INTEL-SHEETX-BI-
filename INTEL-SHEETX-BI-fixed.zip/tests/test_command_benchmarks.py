import io
import os
from fastapi.testclient import TestClient
from backend.app.main import app

FIXTURES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "fixtures"))


def _setup_enterprise_dataset():
    client = TestClient(app)
    r = client.post("/api/auth/register", json={"email": "bench@sheetx.test", "name": "Bench", "password": "StrongPassword123!"})
    if r.status_code == 409:
        r = client.post("/api/auth/login", json={"email": "bench@sheetx.test", "password": "StrongPassword123!"})
    client.headers.update({"Authorization": f"Bearer {r.json()['token']}"})
    prj = client.post("/api/projects", json={"name": "20 Command Benchmarks"}).json()["project"]
    with open(os.path.join(FIXTURES_DIR, "enterprise_india_sales_2026.csv"), "rb") as f:
        ds = client.post("/api/upload", data={"project_id": prj["id"]}, files={"file": ("enterprise_india_sales_2026.csv", f, "text/csv")}).json()
    return client, prj["id"], ds["dataset_id"]


def test_all_20_handbook_benchmark_sentences():
    client, pid, ds_id = _setup_enterprise_dataset()

    def ask(text: str, prev=None):
        resp = client.post("/api/command", json={"project_id": pid, "dataset_id": ds_id, "text": text, "previous_spec": prev})
        assert resp.status_code == 200, resp.text
        return resp.json()

    # 1. compare sales by division -> A1, bar_h, sorted desc
    r1 = ask("compare sales by division")
    assert r1["outcome"] == "answered"
    assert r1["spec"]["intent"] == "A1_compare"
    assert r1["render"]["chart_type"] == "bar_h"
    assert r1["spec"]["dimensions"][0]["field"] == "division"

    # 2. profit trend by month -> A2, line, monthly
    r2 = ask("profit trend by month")
    assert r2["outcome"] == "answered"
    assert r2["spec"]["intent"] == "A2_trend"
    assert r2["render"]["chart_type"] == "line"
    assert r2["spec"]["dimensions"][0]["grain"] == "month"

    # 3. top 10 products by margin -> A4, bar_h, limit 10, hidden-count note
    r3 = ask("top 10 products by margin")
    assert r3["outcome"] == "answered"
    assert r3["spec"]["intent"] == "A4_rank"
    assert r3["spec"]["limit"] == 10
    assert r3["spec"]["measures"][0]["metric"] == "profit_margin"
    assert any("top 10" in n.lower() for n in r3["render"]["guardrail_notes"])

    # 4. revenue share by region -> A3, donut (5 regions <= 5)
    r4 = ask("revenue share by region")
    assert r4["outcome"] == "answered"
    assert r4["spec"]["intent"] == "A3_composition"
    assert r4["render"]["chart_type"] in ("donut", "pct_bar")

    # 5. does discount affect profit -> A5, scatter, no causal wording
    r5 = ask("does discount affect profit")
    assert r5["outcome"] == "answered"
    assert r5["spec"]["intent"] == "A5_relationship"
    assert r5["render"]["chart_type"] == "scatter"
    assert any("causa" in n.lower() for n in r5["render"]["guardrail_notes"])

    # 6. spread of order values -> A6, histogram
    r6 = ask("spread of sales")
    assert r6["outcome"] == "answered"
    assert r6["spec"]["intent"] == "A6_distribution"
    assert r6["render"]["chart_type"] == "histogram"

    # 7. sales vs target by month -> A7, bullet
    r7 = ask("sales vs target by month")
    assert r7["outcome"] == "answered"
    assert r7["spec"]["intent"] == "A7_target"
    assert r7["render"]["chart_type"] == "bullet"

    # 8. where did margin drop -> A8, line
    r8 = ask("where did margin drop")
    assert r8["outcome"] == "answered"
    assert r8["spec"]["intent"] == "A8_anomaly"
    assert r8["render"]["chart_type"] == "line"

    # 9. how are we doing this quarter -> A9, kpi
    r9 = ask("how are we doing this quarter")
    assert r9["outcome"] == "answered"
    assert r9["spec"]["intent"] == "A9_summary"
    assert r9["render"]["chart_type"] == "kpi"

    # 10. why is west margin down -> A10, driver breakdown
    r10 = ask("why is west margin down")
    assert r10["outcome"] == "answered"
    assert r10["spec"]["intent"] == "A10_explain"
    assert any(f["value"] == "West" for f in r10["spec"]["filters"])

    # 11. sales by division, north only -> A1 + filter North
    r11 = ask("sales by division, north only")
    assert r11["outcome"] == "answered"
    assert any(f["value"] == "North" for f in r11["spec"]["filters"])

    # 12. monthly sales since january -> A2 + absolute period
    r12 = ask("monthly sales since january")
    assert r12["outcome"] == "answered"
    assert r12["spec"]["intent"] == "A2_trend"
    assert r12["spec"]["period"]["kind"] == "absolute"

    # 13. which customers buy most -> A4 + identifier guardrail note
    r13 = ask("which customers buy most")
    assert r13["outcome"] == "answered"
    assert r13["spec"]["intent"] == "A4_rank"
    assert any("identifier guardrail" in n.lower() for n in r13["render"]["guardrail_notes"])

    # 14. compare this year with last year -> A2 + prior_year compare
    r14 = ask("compare this year with last year")
    assert r14["outcome"] == "answered"
    assert r14["spec"]["compare"] == "prior_year"

    # 15. average order value by region -> A1 + avg_order_value ratio metric
    r15 = ask("average order value by region")
    assert r15["outcome"] == "answered"
    assert r15["spec"]["measures"][0]["metric"] == "avg_order_value"

    # 16. show me everything -> A9 default summary (never raw dump)
    r16 = ask("show me everything")
    assert r16["outcome"] == "answered"
    assert r16["spec"]["intent"] == "A9_summary"
    assert r16["render"]["chart_type"] == "kpi"

    # 17. same but as a line chart -> context override to line
    r17 = ask("same but as a line chart", prev=r1["spec"])
    assert r17["outcome"] == "answered"
    assert r17["render"]["chart_type"] == "line"

    # 18. revenue by month and division -> A2 + series split
    r18 = ask("revenue by month and division")
    assert r18["outcome"] == "answered"
    assert r18["spec"]["intent"] == "A2_trend"
    assert r18["spec"]["series_dimension"] == "division"

    # 19. what is our churn -> UNSUPPORTED refusal + alternatives
    r19 = ask("what is our churn")
    assert r19["outcome"] == "refused"
    assert "churn" in r19["reason"].lower()
    assert len(r19["alternatives"]) >= 1

    # 20. forecast next quarter -> A2 + forecast estimate with interval
    r20 = ask("forecast sales next quarter")
    assert r20["outcome"] == "answered"
    assert r20["forecast"]["supported"] is True
    assert len(r20["forecast"]["points"]) == 3


def test_ambiguity_clarification_and_missing_date_refusal():
    client, pid, _ = _setup_enterprise_dataset()

    # Upload a CSV with two ambiguous revenue columns ('gross_revenue' and 'net_revenue') and NO date column
    amb_csv = "region,gross_revenue,net_revenue\nNorth,1000,850\nSouth,1400,1200\nWest,900,720\n"
    up = client.post(
        "/api/upload",
        data={"project_id": pid},
        files={"file": ("ambiguous.csv", io.BytesIO(amb_csv.encode("utf-8")), "text/csv")},
    )
    assert up.status_code == 200
    amb_ds = up.json()["dataset_id"]

    # Ambiguous request -> must ask clarification rather than guessing!
    c1 = client.post("/api/command", json={"project_id": pid, "dataset_id": amb_ds, "text": "revenue by region"}).json()
    assert c1["outcome"] == "clarified"
    assert len(c1["options"]) >= 2

    # Missing date column -> trend refused with alternatives!
    c2 = client.post("/api/command", json={"project_id": pid, "dataset_id": amb_ds, "text": "gross_revenue trend by month"}).json()
    assert c2["outcome"] == "refused"
    assert "no date column" in c2["reason"].lower()
    assert len(c2["alternatives"]) >= 1
