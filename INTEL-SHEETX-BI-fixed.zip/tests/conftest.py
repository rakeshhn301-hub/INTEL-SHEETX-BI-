"""Isolate every test module from real application users and storage."""
import os
import tempfile
import shutil
import pytest

_TEST_ROOT = tempfile.mkdtemp(prefix="sheetx_suite_")
os.environ["DATABASE_PATH"] = os.path.join(_TEST_ROOT, "metadata.db")
os.environ["STORAGE_DIR"] = os.path.join(_TEST_ROOT, "storage")
os.environ["PARQUET_DIR"] = os.path.join(_TEST_ROOT, "parquet")

@pytest.fixture(scope="session", autouse=True)
def database():
    from backend.app.db import init_db
    init_db()
    yield
    shutil.rmtree(_TEST_ROOT, ignore_errors=True)
