import io
import os
from fastapi.testclient import TestClient
from backend.app.main import app

FIXTURES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "fixtures"))


def _user_client(email: str):
    c = TestClient(app)
    r = c.post("/api/auth/register", json={"email": email, "name": email.split("@")[0], "password": "StrongPassword123!"})
    if r.status_code == 409:
        r = c.post("/api/auth/login", json={"email": email, "password": "StrongPassword123!"})
    c.headers.update({"Authorization": f"Bearer {r.json()['token']}"})
    return c


def test_two_account_404_isolation_xlsx_dashboards_exports_and_deletion():
    alice = _user_client("alice@tenant1.test")
    bob = _user_client("bob@tenant2.test")

    # Alice creates project & uploads multi-sheet XLSX
    prj = alice.post("/api/projects", json={"name": "Alice Confidential Finance"}).json()["project"]

    # Reject PNG binary masquerading as CSV
    bad_bin = alice.post(
        "/api/upload",
        data={"project_id": prj["id"]},
        files={"file": ("fake.csv", io.BytesIO(b"\x89PNG\r\n\x1a\n\x00\x00binary"), "text/csv")},
    )
    assert bad_bin.status_code == 400

    # Upload multi-sheet XLSX without sheet_name -> must require explicit sheet selection!
    with open(os.path.join(FIXTURES_DIR, "sales_multi.xlsx"), "rb") as f:
        xlsx_step1 = alice.post("/api/upload", data={"project_id": prj["id"]}, files={"file": ("sales_multi.xlsx", f, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")})
    assert xlsx_step1.status_code == 200
    assert xlsx_step1.json()["requires_sheet_selection"] is True
    sheet_names = [s["name"] for s in xlsx_step1.json()["sheets"]]
    assert "Orders_2026" in sheet_names

    # Select 'Orders_2026' sheet -> parses exact 60 rows!
    with open(os.path.join(FIXTURES_DIR, "sales_multi.xlsx"), "rb") as f:
        xlsx_step2 = alice.post(
            "/api/upload",
            data={"project_id": prj["id"], "sheet_name": "Orders_2026"},
            files={"file": ("sales_multi.xlsx", f, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
        )
    assert xlsx_step2.status_code == 200
    ds_id = xlsx_step2.json()["dataset_id"]
    assert xlsx_step2.json()["row_count"] == 60

    # Role override persists across reload
    ov = alice.patch(f"/api/datasets/{ds_id}/fields", json={"overrides": [{"name": "region", "role": "dimension"}]})
    assert ov.status_code == 200
    reloaded = alice.get(f"/api/datasets/{ds_id}/profile").json()
    reg_f = next(f for f in reloaded["fields"] if f["name"] == "region")
    assert reg_f["overridden_by"] is not None

    # Generate 6-tile dashboard & verify save/reload
    dash = alice.post("/api/dashboards/generate", json={"project_id": prj["id"], "dataset_id": ds_id})
    assert dash.status_code == 200
    dash_id = dash.json()["id"]
    assert len(dash.json()["hydrated_tiles"]) >= 5

    # Cross-tenant isolation check: Bob MUST receive 404 (never 200 or 403) on EVERY Alice resource!
    assert bob.get(f"/api/projects/{prj['id']}").status_code == 404
    assert bob.get(f"/api/datasets/{ds_id}/profile").status_code == 404
    assert bob.get(f"/api/dashboards/{dash_id}").status_code == 404
    assert bob.post("/api/query", json={"intent": "A9_summary", "chart_type": "kpi", "dataset_id": ds_id, "measures": [{"metric": "total_sales"}]}).status_code == 404

    # Export fidelity: filtered CSV row count == query row count
    exp_spec = {
        "intent": "A1_compare",
        "chart_type": "bar_h",
        "dataset_id": ds_id,
        "dimensions": [{"field": "division"}],
        "measures": [{"metric": "total_sales"}],
        "filters": [{"field": "region", "op": "=", "value": "North"}],
    }
    q_check = alice.post("/api/query", json=exp_spec).json()["query"]
    exp_resp = alice.post("/api/export", json={"dataset_id": ds_id, "format": "csv", "spec": exp_spec})
    assert exp_resp.status_code == 200
    assert int(exp_resp.headers["X-Export-Row-Count"]) == q_check["row_count"]
    assert "region = North" in exp_resp.text

    # Idempotent Digest Schedule: fires once for 2026-W43, replays idempotently on repeat
    sch = alice.post("/api/schedules", json={
        "project_id": prj["id"],
        "dataset_id": ds_id,
        "kind": "digest",
        "name": "Monday Executive Digest",
        "cadence": "weekly",
        "channel": "email",
        "recipient": "cfo@tenant1.test",
    }).json()
    j1 = alice.post(f"/api/schedules/{sch['schedule_id']}/run?period_key=2026-W43").json()
    j2 = alice.post(f"/api/schedules/{sch['schedule_id']}/run?period_key=2026-W43").json()
    assert j1["idempotent_replay"] is False
    assert j2["idempotent_replay"] is True
    assert j1["job_run_id"] == j2["job_run_id"]
    assert len(j1["digest"]["items"]) <= 3

    # Full Deletion & Tombstone: removes Parquet from disk and returns 404 afterwards
    del_res = alice.delete(f"/api/datasets/{ds_id}")
    assert del_res.status_code == 200
    assert del_res.json()["removed_files_count"] >= 1
    assert alice.get(f"/api/datasets/{ds_id}/profile").status_code == 404
