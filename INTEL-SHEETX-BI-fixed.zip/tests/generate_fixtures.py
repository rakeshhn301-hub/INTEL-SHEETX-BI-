"""
Generates the complete INTEL SHEETX BI test fixture pack (Chapter 34.2 & Appendix B)
and computes expected metric answers using pure Python loops (zero DuckDB/SQL usage)
so numeric tests verify the query compiler independently.
"""
import csv
import json
import math
import os
import random
from collections import defaultdict
from openpyxl import Workbook

BASE_DIR = os.path.join(os.path.dirname(__file__), "fixtures")
EXPECTED_DIR = os.path.join(BASE_DIR, "expected")
os.makedirs(EXPECTED_DIR, exist_ok=True)


def generate_sales_small():
    """
    120 rows, 4 divisions (North, South, West, East), exact totals matching Appendix B:
    - total_sales = 37500.00
    - total_profit = 6750.00
    - profit_margin = 0.18 (while naive row-average margin is != 0.18, approx 0.285)
    - units_sold = 4960
    - distinct order_number = 90 (across 120 order lines)
    - distinct customer_id = 45
    """
    rows = []
    # Group A: 90 small orders with high row margin (sales=100, profit=32 -> 32% row margin)
    # 90 * 100 = 9,000 sales; 90 * 32 = 2,880 profit
    # Group B: 30 large orders with lower row margin (sales=950, profit=129 -> 13.58% row margin)
    # 30 * 950 = 28,500 sales; 30 * 129 = 3,870 profit
    # Total sales = 9,000 + 28,500 = 37,500.00!
    # Total profit = 2,880 + 3,870 = 6,750.00!
    # True SUM(profit)/SUM(sales) = 6750 / 37500 = 0.180000!
    # Naive AVG(profit/sales) = (90*0.32 + 30*(129/950)) / 120 = 0.273947 != 0.18!
    divisions = ["North", "South", "West", "East"]
    regions = ["North", "South", "West", "East"]
    products = [
        "Edge Gateway", "Cloud Analytics", "Core Sensor", "Smart Meter",
        "Fabric Switch", "Data Vault", "Vision Node", "Telemetry Hub",
        "Compute Blade", "Sync Router", "Power Relay", "Secure Enclave",
    ]
    months = [
        ("2025-01-15", "2025-01-18"),
        ("2025-02-15", "2025-02-17"),
        ("2025-03-15", "2025-03-20"),
        ("2026-01-15", "2026-01-17"),
        ("2026-02-15", "2026-02-19"),
        ("2026-03-15", "2026-03-16"),
    ]

    for i in range(120):
        is_large = i >= 90
        sales = 950.00 if is_large else 100.00
        profit = 129.00 if is_large else 32.00
        discount_amt = 50.00 if is_large else 5.00
        gross_sales = sales + discount_amt
        variable_cost = sales - profit - (20.00 if is_large else 8.00)
        units = 80 if is_large else 28  # 30*80 + 90*28 = 2400 + 2520 = 4920; adjust first 10 by +4 -> 4960
        if i < 10:
            units += 4
        returned_units = 2 if (i % 10 == 0) else 0
        div = divisions[i % 4]
        reg = regions[i % 4]
        prod = products[i % len(products)]
        order_date, due_date = months[i % len(months)]
        order_no = f"ORD-{1001 + (i % 90):04d}"  # 90 distinct orders across 120 lines
        cust_id = f"CUST-{1 + (i % 45):04d}"     # 45 distinct customers
        postal = f"0{(i % 9) + 1}10{i % 10}"     # leading zero preserved!
        target_sales = 980.00 if is_large else 95.00
        on_hand = 50 + (i % 20)
        unit_cost = 12.50
        on_time = 1 if (i % 5 != 0) else 0

        rows.append({
            "order_number": order_no,
            "order_date": order_date,
            "due_date": due_date,
            "customer_id": cust_id,
            "postal_code": postal,
            "division": div,
            "region": reg,
            "product": prod,
            "units": units,
            "returned_units": returned_units,
            "gross_sales": f"{gross_sales:.2f}",
            "discount_amount": f"{discount_amt:.2f}",
            "sales": f"{sales:.2f}",
            "variable_cost": f"{variable_cost:.2f}",
            "profit": f"{profit:.2f}",
            "row_margin_pct": f"{(profit / sales):.6f}",
            "target_sales": f"{target_sales:.2f}",
            "on_hand": on_hand,
            "unit_cost": f"{unit_cost:.2f}",
            "on_time_flag": on_time,
        })

    path = os.path.join(BASE_DIR, "sales_small.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    # Independent pure-Python verification & expected outputs
    tot_sales = sum(float(r["sales"]) for r in rows)
    tot_profit = sum(float(r["profit"]) for r in rows)
    tot_units = sum(int(r["units"]) for r in rows)
    tot_ret = sum(int(r["returned_units"]) for r in rows)
    tot_disc = sum(float(r["discount_amount"]) for r in rows)
    tot_gross = sum(float(r["gross_sales"]) for r in rows)
    tot_var = sum(float(r["variable_cost"]) for r in rows)
    distinct_orders = len(set(r["order_number"] for r in rows))
    distinct_custs = len(set(r["customer_id"] for r in rows))
    on_time_pct = sum(int(r["on_time_flag"]) for r in rows) / len(rows)
    latest_date = max(r["order_date"] for r in rows)
    inv_val_latest = sum(int(r["on_hand"]) * float(r["unit_cost"]) for r in rows if r["order_date"] == latest_date)
    sales_2026 = sum(float(r["sales"]) for r in rows if r["order_date"].startswith("2026"))
    sales_2025 = sum(float(r["sales"]) for r in rows if r["order_date"].startswith("2025"))

    by_div = defaultdict(float)
    for r in rows:
        by_div[r["division"]] += float(r["sales"])

    north_rows = [r for r in rows if r["region"] == "North"]
    north_sales = sum(float(r["sales"]) for r in north_rows)
    north_orders = len(set(r["order_number"] for r in north_rows))

    expected = {
        "_comment": "Computed via pure Python loops in generate_fixtures.py (zero SQL/DuckDB used).",
        "row_count": len(rows),
        "column_count": len(rows[0]),
        "metrics": {
            "total_sales": round(tot_sales, 2),
            "total_profit": round(tot_profit, 2),
            "profit_margin": round(tot_profit / tot_sales, 6),
            "naive_avg_row_margin_wrong": round(sum(float(r["row_margin_pct"]) for r in rows) / len(rows), 6),
            "order_count": distinct_orders,
            "customer_count": distinct_custs,
            "avg_order_value": round(tot_sales / distinct_orders, 6),
            "units_sold": tot_units,
            "discount_rate": round(tot_disc / tot_gross, 6),
            "sales_per_customer": round(tot_sales / distinct_custs, 6),
            "return_rate": round(tot_ret / tot_units, 6),
            "on_time_delivery_pct": round(on_time_pct, 6),
            "contribution_margin": round((tot_sales - tot_var) / tot_sales, 6),
            "inventory_value_latest_snapshot": round(inv_val_latest, 2),
            "yoy_2026_vs_2025": round((sales_2026 - sales_2025) / sales_2025, 6),
        },
        "by_division": {k: round(v, 2) for k, v in by_div.items()},
        "filtered_north": {
            "total_sales": round(north_sales, 2),
            "order_count": north_orders,
            "row_count": len(north_rows),
        },
    }
    with open(os.path.join(EXPECTED_DIR, "sales_small_expected.json"), "w", encoding="utf-8") as f:
        json.dump(expected, f, indent=2)
    return rows


def generate_edge_fixtures(base_rows):
    # 1. sales_nulls.csv: null cost in 10% of rows (12 rows), null date in 2 rows
    null_rows = []
    for i, r in enumerate(base_rows[:50]):
        nr = dict(r)
        if i < 5:
            nr["variable_cost"] = ""
        if i in (0, 1):
            nr["order_date"] = "N/A"
        null_rows.append(nr)
    with open(os.path.join(BASE_DIR, "sales_nulls.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(null_rows[0].keys()))
        w.writeheader()
        w.writerows(null_rows)

    # 2. sales_dupes.csv: exact duplicate rows + fan-out dimension CSV
    dupe_rows = list(base_rows[:30]) + list(base_rows[:5])  # 35 rows, 5 exact dupes
    with open(os.path.join(BASE_DIR, "sales_dupes.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(dupe_rows[0].keys()))
        w.writeheader()
        w.writerows(dupe_rows)

    dim_fanout = [
        {"customer_id": "CUST-0001", "tier": "Enterprise"},
        {"customer_id": "CUST-0001", "tier": "SMB"},  # duplicate key on 'one' side -> must fail fan-out gate!
        {"customer_id": "CUST-0002", "tier": "Enterprise"},
    ]
    with open(os.path.join(BASE_DIR, "dim_customers_fanout.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["customer_id", "tier"])
        w.writeheader()
        w.writerows(dim_fanout)

    # 3. sales_dates_mixed.csv: ISO, DD/MM/YYYY, Month DD YYYY + 2 invalid
    mixed = [
        {"order_id": f"M-{i}", "order_date": d, "division": "North" if i % 2 == 0 else "South", "sales": 100 + i * 10}
        for i, d in enumerate([
            "2026-01-10", "2026-01-25", "2026-02-14", "2026-03-05",
            "2026-04-12", "2026-05-19", "2026-06-01", "2026-07-15",
            "2026-08-20", "2026-09-10", "not-a-date", "2026-10-01"
        ])
    ]
    with open(os.path.join(BASE_DIR, "sales_dates_mixed.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(mixed[0].keys()))
        w.writeheader()
        w.writerows(mixed)

    # 4. sales_ids.csv: numeric customer_id & leading-zero postal_code + PII email notes
    ids_rows = []
    for i in range(40):
        ids_rows.append({
            "customer_id": 100001 + i,  # high-cardinality numeric -> must classify as IDENTIFIER, never summable!
            "postal_code": f"0{1100 + i}",
            "division": ["North", "South", "West"][i % 3],
            "sales": 250.0 + (i * 5),
            "customer_email": f"buyer{i}@example.org",
        })
    with open(os.path.join(BASE_DIR, "sales_ids.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(ids_rows[0].keys()))
        w.writeheader()
        w.writerows(ids_rows)

    # 5. sales_negative.csv: zero sales (zero denominator) & negative profit
    neg_rows = [
        {"order_number": "N-1", "division": "West", "sales": 0.0, "profit": -45.0, "units": -2},
        {"order_number": "N-2", "division": "West", "sales": 0.0, "profit": 0.0, "units": 0},
        {"order_number": "N-3", "division": "North", "sales": 500.0, "profit": 100.0, "units": 10},
        {"order_number": "N-4", "division": "South", "sales": 300.0, "profit": -60.0, "units": 6},
    ]
    with open(os.path.join(BASE_DIR, "sales_negative.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(neg_rows[0].keys()))
        w.writeheader()
        w.writerows(neg_rows)

    # 6. sales_multi.xlsx: 3-sheet workbook
    wb = Workbook()
    ws1 = wb.active
    ws1.title = "Readme_Cover"
    ws1.append(["Export Notice", "Pick Orders_2026 sheet to analyse"])
    ws2 = wb.create_sheet("Orders_2026")
    headers = ["order_number", "order_date", "division", "region", "product", "sales", "profit", "units"]
    ws2.append(headers)
    for r in base_rows[:60]:
        ws2.append([
            r["order_number"], r["order_date"], r["division"], r["region"],
            r["product"], float(r["sales"]), float(r["profit"]), int(r["units"])
        ])
    ws3 = wb.create_sheet("Regional_Targets")
    ws3.append(["region", "annual_target"])
    for reg, tgt in [("North", 12000), ("South", 10000), ("West", 11000), ("East", 9500)]:
        ws3.append([reg, tgt])
    wb.save(os.path.join(BASE_DIR, "sales_multi.xlsx"))


def generate_enterprise_dataset():
    """
    Generates a rich 640-row FY25-FY26 dataset (`enterprise_india_sales_2026.csv`)
    that reflects real multi-division enterprise operations with:
    - 6 divisions, 5 regions, 18 products, 18 months (Jan 2025 - Sep 2026)
    - Intentional Q3 2026 West division margin compression caused by elevated discounts
      on 2 product families, plus 2.1% missing cost values for realistic data-quality flagging.
    """
    rng = random.Random(20261025)
    divisions = ["Cloud Infrastructure", "Enterprise Software", "Industrial IoT", "Edge Hardware", "Cybersecurity", "Data Services"]
    regions = ["West", "South", "North", "East", "Central"]
    channels = ["Direct Enterprise", "Partner Network", "Digital Self-Serve"]
    products_by_div = {
        "Cloud Infrastructure": ["Compute Cluster Pro", "Object Store Grid", "Hybrid Mesh VPN"],
        "Enterprise Software": ["SheetX Core Suite", "Workflow Studio", "ERP Sync Bridge"],
        "Industrial IoT": ["Smart Factory Gateway", "Thermal Telemetry Sensor", "PLC Edge Node"],
        "Edge Hardware": ["Rugged Compute Box", "Vision AI Camera", "Rack Telemetry Unit"],
        "Cybersecurity": ["ZeroTrust Sentinel", "Endpoint Shield", "IAM Vault"],
        "Data Services": ["Lakehouse Connector", "Streaming Pipeline", "Catalog Governance"],
    }
    months = [
        "2025-01", "2025-02", "2025-03", "2025-04", "2025-05", "2025-06",
        "2025-07", "2025-08", "2025-09", "2025-10", "2025-11", "2025-12",
        "2026-01", "2026-02", "2026-03", "2026-04", "2026-05", "2026-06",
        "2026-07", "2026-08", "2026-09",
    ]
    rows = []
    for idx in range(640):
        ym = months[idx % len(months)]
        day = rng.randint(1, 27)
        order_date = f"{ym}-{day:02d}"
        due_date = f"{ym}-{min(28, day + 3):02d}"
        div = divisions[idx % len(divisions)]
        reg = regions[(idx * 3 + rng.randint(0, 2)) % len(regions)]
        chan = channels[idx % len(channels)]
        prod = products_by_div[div][(idx // len(divisions)) % 3]
        order_no = f"INV-{202500 + (idx % 480):06d}"
        cust_id = f"CID-{1001 + (idx % 165):04d}"
        postal = f"{['400001','560001','110001','700001','462001'][regions.index(reg)]}"

        units = rng.randint(5, 65)
        unit_price = rng.choice([1200, 1850, 2400, 3200, 4500, 6800])
        gross_sales = round(units * unit_price, 2)

        # West Q3 2026 discount surge -> margin drop (mirrors handbook Ch. 21-23 & 31)
        is_west_q3_26 = (reg == "West" and ym in ("2026-07", "2026-08", "2026-09"))
        disc_pct = rng.uniform(0.18, 0.28) if is_west_q3_26 else rng.uniform(0.04, 0.11)
        discount_amount = round(gross_sales * disc_pct, 2)
        sales = round(gross_sales - discount_amount, 2)

        base_cost_ratio = rng.uniform(0.76, 0.88) if is_west_q3_26 else rng.uniform(0.62, 0.75)
        variable_cost = round(gross_sales * base_cost_ratio, 2)
        profit = round(sales - variable_cost, 2)
        target_sales = round(sales * rng.uniform(0.92, 1.12), 2)
        returned_units = rng.randint(1, 4) if rng.random() < 0.08 else 0
        on_time_flag = 0 if rng.random() < 0.09 else 1
        on_hand = rng.randint(20, 220)
        unit_cost = round(unit_price * 0.58, 2)

        # 2.1% missing variable_cost for realistic quality caveat
        var_cost_str = "" if (idx % 47 == 0) else f"{variable_cost:.2f}"

        rows.append({
            "order_number": order_no,
            "order_date": order_date,
            "due_date": due_date,
            "customer_id": cust_id,
            "postal_code": postal,
            "division": div,
            "region": reg,
            "channel": chan,
            "product": prod,
            "units": units,
            "returned_units": returned_units,
            "gross_sales": f"{gross_sales:.2f}",
            "discount_amount": f"{discount_amount:.2f}",
            "sales": f"{sales:.2f}",
            "variable_cost": var_cost_str,
            "profit": f"{profit:.2f}",
            "target_sales": f"{target_sales:.2f}",
            "on_hand": on_hand,
            "unit_cost": f"{unit_cost:.2f}",
            "on_time_flag": on_time_flag,
        })

    path = os.path.join(BASE_DIR, "enterprise_india_sales_2026.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


if __name__ == "__main__":
    small = generate_sales_small()
    generate_edge_fixtures(small)
    generate_enterprise_dataset()
    print("Generated all fixtures successfully in", BASE_DIR)
