import json
import os
import tempfile
import pytest
from fastapi.testclient import TestClient

from backend.app.main import app  # noqa: E402
from backend.app.db import init_db  # noqa: E402

init_db()
FIXTURES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "fixtures"))


def _auth_client(email: str, name: str = "Analyst"):
    client = TestClient(app)
    r = client.post("/api/auth/register", json={"email": email, "name": name, "password": "StrongPassword123!"})
    if r.status_code == 409:
        r = client.post("/api/auth/login", json={"email": email, "password": "StrongPassword123!"})
    assert r.status_code == 200, r.text
    tok = r.json()["token"]
    client.headers.update({"Authorization": f"Bearer {tok}"})
    return client


def test_15_metrics_exact_arithmetic_and_guards():
    client = _auth_client("numeric@sheetx.test")
    prj = client.post("/api/projects", json={"name": "Numeric Verification"}).json()["project"]

    with open(os.path.join(FIXTURES_DIR, "expected", "sales_small_expected.json"), "r") as f:
        expected = json.load(f)

    with open(os.path.join(FIXTURES_DIR, "sales_small.csv"), "rb") as f:
        up = client.post("/api/upload", data={"project_id": prj["id"]}, files={"file": ("sales_small.csv", f, "text/csv")})
    assert up.status_code == 200, up.text
    ds_id = up.json()["dataset_id"]
    assert up.json()["row_count"] == expected["row_count"] == 120
    assert up.json()["column_count"] == expected["column_count"] == 20

    # Query all core metrics at dataset summary scope
    metric_keys = [
        "total_sales", "total_profit", "profit_margin", "order_count", "customer_count",
        "avg_order_value", "units_sold", "discount_rate", "sales_per_customer",
        "return_rate", "on_time_delivery_pct", "contribution_margin", "inventory_value", "yoy_growth",
    ]
    q = client.post("/api/query", json={
        "intent": "A9_summary",
        "chart_type": "kpi",
        "dataset_id": ds_id,
        "dimensions": [],
        "measures": [{"metric": mk} for mk in metric_keys],
    })
    assert q.status_code == 200, q.text
    row = q.json()["query"]["rows"][0]
    exp_m = expected["metrics"]

    assert row["total_sales"] == pytest.approx(exp_m["total_sales"], abs=1e-6)
    assert row["total_profit"] == pytest.approx(exp_m["total_profit"], abs=1e-6)
    # Crucial ratio rule: profit_margin MUST equal 0.18 (SUM/SUM), NEVER 0.273947 (AVG of row margins)!
    assert row["profit_margin"] == pytest.approx(0.18, abs=1e-9)
    assert abs(row["profit_margin"] - exp_m["naive_avg_row_margin_wrong"]) > 0.08
    assert row["order_count"] == exp_m["order_count"] == 90
    assert row["customer_count"] == exp_m["customer_count"] == 45
    assert row["avg_order_value"] == pytest.approx(exp_m["avg_order_value"], abs=1e-5)
    assert row["units_sold"] == exp_m["units_sold"] == 4960
    assert row["discount_rate"] == pytest.approx(exp_m["discount_rate"], abs=1e-5)
    assert row["sales_per_customer"] == pytest.approx(exp_m["sales_per_customer"], abs=1e-5)
    assert row["return_rate"] == pytest.approx(exp_m["return_rate"], abs=1e-5)
    assert row["on_time_delivery_pct"] == pytest.approx(exp_m["on_time_delivery_pct"], abs=1e-6)
    assert row["contribution_margin"] == pytest.approx(exp_m["contribution_margin"], abs=1e-6)
    assert row["inventory_value"] == pytest.approx(exp_m["inventory_value_latest_snapshot"], abs=1e-6)
    assert row["yoy_growth"] == pytest.approx(exp_m["yoy_2026_vs_2025"], abs=1e-6)

    # Filter test: Region = North
    qf = client.post("/api/query", json={
        "intent": "A9_summary",
        "chart_type": "kpi",
        "dataset_id": ds_id,
        "measures": [{"metric": "total_sales"}, {"metric": "order_count"}],
        "filters": [{"field": "region", "op": "=", "value": "North"}],
    })
    assert qf.status_code == 200
    rf = qf.json()["query"]["rows"][0]
    assert rf["total_sales"] == pytest.approx(expected["filtered_north"]["total_sales"], abs=1e-6)
    assert rf["order_count"] == expected["filtered_north"]["order_count"]

    # Grouping by division
    qg = client.post("/api/query", json={
        "intent": "A1_compare",
        "chart_type": "bar_h",
        "dataset_id": ds_id,
        "dimensions": [{"field": "division"}],
        "measures": [{"metric": "total_sales"}],
    })
    assert qg.status_code == 200
    by_div_actual = {r["division"]: r["total_sales"] for r in qg.json()["query"]["rows"]}
    assert by_div_actual == expected["by_division"]


def test_zero_denominator_identifier_ban_and_fanout_gate():
    client = _auth_client("guards@sheetx.test")
    prj = client.post("/api/projects", json={"name": "Guards Suite"}).json()["project"]

    # 1. Zero denominator -> NULL (None in JSON), NEVER fabricated 0
    with open(os.path.join(FIXTURES_DIR, "sales_negative.csv"), "rb") as f:
        ds_neg = client.post("/api/upload", data={"project_id": prj["id"]}, files={"file": ("sales_negative.csv", f, "text/csv")}).json()["dataset_id"]

    qz = client.post("/api/query", json={
        "intent": "A1_compare",
        "chart_type": "bar_h",
        "dataset_id": ds_neg,
        "dimensions": [{"field": "division"}],
        "measures": [{"metric": "profit_margin"}],
    })
    assert qz.status_code == 200
    rows_by_div = {r["division"]: r["profit_margin"] for r in qz.json()["query"]["rows"]}
    assert rows_by_div["West"] is None  # sales=0 in West -> profit_margin MUST be NULL!
    assert rows_by_div["North"] == pytest.approx(0.20, abs=1e-6)
    assert rows_by_div["South"] == pytest.approx(-0.20, abs=1e-6)

    # 2. Numeric IDs & leading-zero postal codes + PII flag + identifier sum ban
    with open(os.path.join(FIXTURES_DIR, "sales_ids.csv"), "rb") as f:
        ds_ids = client.post("/api/upload", data={"project_id": prj["id"]}, files={"file": ("sales_ids.csv", f, "text/csv")}).json()["dataset_id"]

    prof = client.get(f"/api/datasets/{ds_ids}/profile").json()
    f_by_name = {f["name"]: f for f in prof["fields"]}
    assert f_by_name["customer_id"]["role"] == "identifier"
    assert f_by_name["postal_code"]["role"] == "identifier"
    assert f_by_name["customer_email"]["sensitive"] is True
    assert f_by_name["customer_email"]["exclude_from_ai"] is True

    # Leading zero preserved on postal_code!
    prev = client.get(f"/api/datasets/{ds_ids}/preview").json()
    assert prev["rows"][0]["postal_code"] == "01100"

    # Attempting to sum customer_id must fail with 400
    bad_sum = client.post("/api/query", json={
        "intent": "A9_summary",
        "chart_type": "kpi",
        "dataset_id": ds_ids,
        "measures": [{"metric": "customer_id"}],
    })
    assert bad_sum.status_code == 400
    assert "identifier" in bad_sum.json()["detail"].lower()

    # 3. Join Fan-Out Gate: duplicate key on 'one' side must fail with 400!
    with open(os.path.join(FIXTURES_DIR, "sales_small.csv"), "rb") as f:
        ds_fact = client.post("/api/upload", data={"project_id": prj["id"]}, files={"file": ("sales_small.csv", f, "text/csv")}).json()["dataset_id"]
    with open(os.path.join(FIXTURES_DIR, "dim_customers_fanout.csv"), "rb") as f:
        ds_dim = client.post("/api/upload", data={"project_id": prj["id"]}, files={"file": ("dim_customers_fanout.csv", f, "text/csv")}).json()["dataset_id"]

    fan = client.post("/api/relationships", json={
        "project_id": prj["id"],
        "from_dataset_id": ds_fact,
        "from_field": "customer_id",
        "to_dataset_id": ds_dim,
        "to_field": "customer_id",
    })
    assert fan.status_code == 400
    assert "fan-out" in fan.json()["detail"].lower()
