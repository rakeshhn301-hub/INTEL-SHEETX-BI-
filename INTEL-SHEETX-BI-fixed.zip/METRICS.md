# INTEL SHEETX BI — Governed Metric Catalog (`METRICS.md`)

Per **Chapters 9 and 28.4** of *INTEL SHEETX BI: The Complete Build Handbook*, every metric is evaluated over versioned Parquet snapshots via parameterized DuckDB SQL. Ratio metrics **always** compile as aggregated numerator over `NULLIF(SUM(denominator), 0)` — never `AVG(row_ratio)`.

## 15 Built-In Governed Metrics

| # | Metric Key | Display Label | Kind | Compiled DuckDB Pattern | Zero-Denominator / Null Policy |
|---|---|---|---|---|---|
| 1 | `total_sales` | Total Sales | `additive` | `SUM("sales")` | `SUM` ignores `NULL`; empty group returns `NULL` |
| 2 | `total_profit` | Total Profit | `additive` | `SUM("profit")` | `SUM` ignores `NULL` |
| 3 | `profit_margin` | Profit Margin | `ratio` | `SUM("profit") / NULLIF(SUM("sales"), 0)` | Returns `NULL` when `SUM(sales) = 0` |
| 4 | `order_count` | Order Count | `distinct` | `COUNT(DISTINCT "order_id")` (or `COUNT(*)` fallback) | `COUNT(DISTINCT)` ignores `NULL` |
| 5 | `customer_count` | Customer Count | `distinct` | `COUNT(DISTINCT "customer_id")` | `COUNT(DISTINCT)` ignores `NULL` |
| 6 | `avg_order_value` | Average Order Value | `ratio` | `SUM("sales") / NULLIF(COUNT(DISTINCT "order_id"), 0)` | Returns `NULL` when order count is `0` |
| 7 | `units_sold` | Units Sold | `additive` | `SUM("units")` | `SUM` ignores `NULL` |
| 8 | `discount_rate` | Effective Discount Rate | `ratio` | `SUM("discount_amount") / NULLIF(SUM("list_sales"), 0)` | Weighted by list sales; `NULL` when denominator is `0` |
| 9 | `sales_per_customer` | Sales per Customer | `ratio` | `SUM("sales") / NULLIF(COUNT(DISTINCT "customer_id"), 0)` | Returns `NULL` when customer count is `0` |
| 10 | `yoy_growth` | Period Growth | `time_intel` | `(curr - prev) / NULLIF(ABS(prev), 0)` via `LAG()` CTE | Returns `NULL` when prior period is missing or `0` |
| 11 | `return_rate` | Return Rate | `ratio` | `SUM("returned_units") / NULLIF(SUM("units"), 0)` | Returns `NULL` when `SUM(units) = 0` |
| 12 | `on_time_delivery_pct` | On-Time Delivery % | `ratio` | `SUM(CASE WHEN on_time=1 THEN 1 ELSE 0 END)::DOUBLE / NULLIF(COUNT(*), 0)` | Returns `NULL` on empty partition |
| 13 | `contribution_margin` | Contribution Margin | `ratio` | `(SUM("sales") - SUM("variable_cost")) / NULLIF(SUM("sales"), 0)` | Returns `NULL` when `SUM(sales) = 0` |
| 14 | `inventory_value` | Closing Inventory Value | `semi_additive` | `ARG_MAX(closing_inv, date)` summed across entities | Sums across products/locations; takes latest date |
| 15 | `target_attainment` | Target Attainment | `ratio` | `SUM("sales") / NULLIF(SUM("target"), 0)` | Returns `NULL` when `SUM(target) = 0` |

## Safe Custom Derived Metric Grammar (Chapter 28.5)

Users can author versioned custom metrics via `/api/metrics` using the restricted AST expression compiler (`backend/app/model/metrics.py`):
- **Permitted operators**: `+`, `-`, `*`, `/`
- **Permitted functions**: `sum(col)`, `count_distinct(col)`, `min(col)`, `max(col)`, `abs(x)`, `round(x, d)`, `nullif(a, b)`, `coalesce(a, b)`
- **Safety enforcement**: Raw SQL keywords, subqueries, attribute access, and summing `identifier` columns are rejected at compile time. Every division denominator `b` is automatically wrapped in `NULLIF((b), 0)`.
