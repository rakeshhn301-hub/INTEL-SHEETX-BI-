# INTEL SHEETX BI

> **From raw rows to verified decisions — in one command.**

INTEL SHEETX BI is an end-to-end governed Business Intelligence and AI-assisted analytics platform built to the complete specifications of *INTEL SHEETX BI: The Complete Build Handbook*.

## Architectural Highlights

1. **Columnar Data Plane (DuckDB + Parquet + openpyxl)**
   - Drag-and-drop CSV/TSV and multi-sheet `.xlsx` ingestion (with explicit worksheet picker).
   - Magic-byte signature validation, SHA-256 deduplicated raw snapshot storage, and versioned Parquet materialisation.
   - 11-statistic semantic profiler (`role`, `semantic_type`, `null_rate`, `distinct_count`, `quantiles`, PII flags, grain detection, and quality warnings) with persistent 1-click user role overrides.

2. **Semantic Metric Layer & Safe AST Compiler**
   - 15 governed built-in metrics (`METRICS.md`) where ratios always compile as `SUM(num) / NULLIF(SUM(den), 0)` and `identifier` fields are blocked from `SUM`/`AVG`.
   - Many-to-one relationship verifier that rejects duplicate `'one'`-side keys before join fan-out can occur.
   - Restricted Python AST expression compiler for custom derived metrics.

3. **Deterministic Command Compiler & Chart Recommender**
   - Normalises `/` slash commands (`/bar`, `/line`, `/donut`, `/scatter`, `/histogram`, `/bullet`, `/kpi`, `/pareto`, `/table`) and natural-language queries across all **10 Intent Archetypes (`A1`–`A10`)** + Forecasting & What-If projections.
   - Ambiguity resolver asks a clarifying question when candidate fields tie within `0.10`, and returns honest refusals with closest valid alternatives when required columns are absent.
   - Weighted chart recommender (`0.45*intent + 0.25*cardinality + 0.20*readability + 0.10*card_fit`) + single Apache ECharts builder enforcing all 9 visual guardrails (`Top-N + Other`, `<=5` donut cap, zero-baseline bars, colour-blind safe Okabe-Ito palette, accessible `sr-only` summaries, and data table toggle).

4. **Four Integrated Analytical Modes**
   - **Mode 1 — Command & Visual Shelf Builder**: Natural-language command bar, searchable field/metric pane, interactive shelves, What-If sensitivity slider, click-to-cross-filter, and SQL/provenance drawer.
   - **Mode 2 — Schema-Aware Analysis Brief & Insights**: `What This Data Is`, ranked `What It Can Answer`, honest `What It Cannot Answer`, and deterministic statistical insight cards with expandable `"How this was calculated"` drawers.
   - **Mode 3 — 6-Tile 12-Column Auto-Dashboard**: One-click executive dashboard composer, global cross-filtering with single-click Reset, Undo/Redo layout & metric editor, and versioned persistence.
   - **Mode 4 — 12-Tool Agentic Investigator & Scheduled Digests**: Multi-step root-cause agent with query/time budgets, prompt-injection refusal, confirmation gates, numeric provenance verifier (`verify_narrative_numbers`), idempotent Pulse digests, and multi-user RBAC (`404` tenant isolation).

## Running Automated Verification (`pytest`)

```bash
cd /home/user/intel-sheetx-bi
python3 tests/generate_fixtures.py
PYTHONPATH=/home/user/intel-sheetx-bi pytest -v tests/
```

## Documentation Deliverables

- [`HANDBOOK_AND_COMMAND_ANALYSIS.md`](../HANDBOOK_AND_COMMAND_ANALYSIS.md) — Study of all 133 handbook pages & command compiler design
- [`BUILD_RULES.md`](./BUILD_RULES.md) — Non-negotiable engineering rules (Chapter 35)
- [`METRICS.md`](./METRICS.md) — 15 governed metric formulas & AST custom metric spec
- [`RUNBOOK.md`](./RUNBOOK.md) — Startup, health checks, and incident playbooks
- [`LIMITATIONS.md`](./LIMITATIONS.md) — Honest scope boundaries
