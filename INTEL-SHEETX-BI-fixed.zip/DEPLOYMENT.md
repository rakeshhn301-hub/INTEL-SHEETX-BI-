# Deploy the complete application

## Why the GitHub Pages login failed
GitHub Pages serves static files only. POST /api/auth/login cannot run there (405).
This package serves the built React frontend and FastAPI backend at one origin.
Deploy the whole project, not just index.html. The supplied single-file HTML detects
GitHub Pages and explains this limitation instead of displaying a cryptic 405.

## Upload to GitHub
Extract INTEL-SHEETX-BI-fixed.zip. Upload its CONTENTS to the repository root.
Keep Dockerfile, render.yaml, backend/, frontend/, tests/, and the documentation.
Do not upload local data, credentials, .env, node_modules, or ZIP files.
The root index.html is an interface-only copy; full deployment serves frontend/dist.

## Deploy with Docker on a Python-capable host
Build: docker build -t intel-sheetx-bi .
Run: docker run --rm -p 8000:8000 -v sheetx-data:/app/data \
  -e APP_URL=http://localhost:8000 \
  -e SESSION_SECRET=replace-with-a-long-random-secret intel-sheetx-bi
Open http://localhost:8000. Create a new account on this deployment.
Accounts from Arena or GitHub Pages are not transferred.

## Render blueprint option
Connect your GitHub repository in Render and create a Blueprint using render.yaml.
Review pricing before approving: the blueprint requests a Starter service and a
persistent 1 GB disk; this is not a promise of free hosting.
Set APP_URL to the final HTTPS service URL and redeploy if necessary.
The persistent disk preserves accounts, datasets and Parquet files on redeployment.
Use a single service instance while SQLite is the metadata database.
Then open the Render service URL, not the old GitHub Pages URL.

## Local development
python -m pip install -r backend/requirements.txt
cd frontend && npm ci --legacy-peer-deps && npm run build && cd ..
python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000
Open http://localhost:8000.
For development hot reload, run the existing Vite dev server on port 5173.

## Verify
python -m pytest -q
cd frontend && npm run build && npm audit
GET /api/health should return status=ok.
Test signup, fixture ingestion and a command before inviting users.

## Boundaries
Docker image and external cloud deployment have not been executed in this sandbox.
The same-origin production application has been tested locally. GitHub files and
hosting must still be updated by the repository owner. External email delivery and
background scheduler operation are not verified by the manual digest-run tests.
Review LIMITATIONS.md before treating this as an enterprise production service.
