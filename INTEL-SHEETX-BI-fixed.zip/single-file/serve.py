from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import urllib.request, urllib.error

class Handler(BaseHTTPRequestHandler):
    def handle_request(self):
        if self.path.startswith('/api/'):
            body = self.rfile.read(int(self.headers.get('Content-Length', 0)))
            headers = {k:v for k,v in self.headers.items() if k.lower() not in ('host','content-length','connection','accept-encoding')}
            request = urllib.request.Request('http://127.0.0.1:8000'+self.path, data=body if body else None, headers=headers, method=self.command)
            try:
                response = urllib.request.urlopen(request)
            except urllib.error.HTTPError as e:
                response = e
            self.send_response(response.status)
            for k,v in response.headers.items():
                if k.lower() not in ('transfer-encoding','connection','content-length'):
                    self.send_header(k,v)
            data=response.read()
        else:
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            data=Path(__file__).with_name('index.html').read_bytes()
        self.send_header('Content-Length',str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    do_GET=do_POST=do_PUT=do_PATCH=do_DELETE=do_OPTIONS=handle_request

ThreadingHTTPServer(('0.0.0.0', 8080), Handler).serve_forever()
