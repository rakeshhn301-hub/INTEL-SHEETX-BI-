"""
Relational Metadata Store (Chapters 26.4, 31.5, 33.1, 36.1 & 38.1).
Implements full schema with foreign keys, versioning, audit logs, and tombstones.
"""
import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from .config import settings


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def get_db_path() -> str:
    import os
    return os.environ.get("DATABASE_PATH", settings.database_path)


@contextmanager
def get_conn():
    conn = sqlite3.connect(get_db_path(), timeout=15.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workspaces (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workspace_members (
    workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK(role IN ('owner', 'editor', 'viewer')),
    created_at TEXT NOT NULL,
    PRIMARY KEY (workspace_id, user_id)
);

CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS datasets (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    current_version INTEGER NOT NULL DEFAULT 1,
    grain_description TEXT NOT NULL DEFAULT 'one row per record',
    deleted_at TEXT,
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dataset_versions (
    id TEXT PRIMARY KEY,
    dataset_id TEXT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    original_filename TEXT NOT NULL,
    sheet_name TEXT,
    content_hash TEXT NOT NULL,
    raw_path TEXT NOT NULL,
    parquet_path TEXT NOT NULL,
    row_count INTEGER NOT NULL,
    column_count INTEGER NOT NULL,
    byte_size INTEGER NOT NULL,
    encoding TEXT NOT NULL,
    delimiter TEXT NOT NULL,
    schema_fingerprint TEXT NOT NULL,
    parse_report_json TEXT NOT NULL,
    profile_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(dataset_id, version)
);

CREATE TABLE IF NOT EXISTS field_metadata (
    id TEXT PRIMARY KEY,
    dataset_id TEXT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    name TEXT NOT NULL,
    safe_col TEXT NOT NULL,
    physical_type TEXT NOT NULL,
    semantic_type TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('dimension', 'measure', 'identifier', 'detail', 'date')),
    default_agg TEXT,
    additive TEXT NOT NULL DEFAULT 'na',
    unit TEXT,
    sensitive INTEGER NOT NULL DEFAULT 0,
    exclude_from_ai INTEGER NOT NULL DEFAULT 0,
    hidden INTEGER NOT NULL DEFAULT 0,
    distinct_count INTEGER NOT NULL DEFAULT 0,
    null_count INTEGER NOT NULL DEFAULT 0,
    null_rate REAL NOT NULL DEFAULT 0.0,
    stats_json TEXT NOT NULL DEFAULT '{}',
    reason TEXT NOT NULL,
    overridden_by TEXT,
    overridden_at TEXT,
    UNIQUE(dataset_id, version, name)
);

CREATE TABLE IF NOT EXISTS relationships (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    from_dataset_id TEXT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    from_field TEXT NOT NULL,
    to_dataset_id TEXT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    to_field TEXT NOT NULL,
    cardinality TEXT NOT NULL DEFAULT 'many_to_one',
    active INTEGER NOT NULL DEFAULT 1,
    verified_unique INTEGER NOT NULL DEFAULT 0,
    guard_message TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS metric_definitions (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    metric_key TEXT NOT NULL,
    label TEXT NOT NULL,
    description TEXT NOT NULL,
    kind TEXT NOT NULL CHECK(kind IN ('additive', 'ratio', 'distinct', 'derived', 'window', 'semi_additive')),
    formula_display TEXT NOT NULL,
    spec_json TEXT NOT NULL,
    grain TEXT NOT NULL,
    null_policy TEXT NOT NULL DEFAULT 'ignore',
    format_json TEXT NOT NULL,
    current_version INTEGER NOT NULL DEFAULT 1,
    is_builtin INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    UNIQUE(project_id, metric_key)
);

CREATE TABLE IF NOT EXISTS metric_versions (
    id TEXT PRIMARY KEY,
    metric_def_id TEXT NOT NULL REFERENCES metric_definitions(id) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    spec_json TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    changed_by TEXT,
    created_at TEXT NOT NULL,
    UNIQUE(metric_def_id, version)
);

CREATE TABLE IF NOT EXISTS charts (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    dataset_id TEXT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    dataset_version INTEGER NOT NULL,
    title TEXT NOT NULL,
    spec_json TEXT NOT NULL,
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dashboards (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    dataset_id TEXT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    dataset_version INTEGER NOT NULL,
    title TEXT NOT NULL,
    subtitle TEXT NOT NULL DEFAULT '',
    current_version INTEGER NOT NULL DEFAULT 1,
    definition_json TEXT NOT NULL,
    share_token TEXT UNIQUE,
    share_role TEXT NOT NULL DEFAULT 'viewer',
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dashboard_versions (
    id TEXT PRIMARY KEY,
    dashboard_id TEXT NOT NULL REFERENCES dashboards(id) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    definition_json TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    UNIQUE(dashboard_id, version)
);

CREATE TABLE IF NOT EXISTS exports (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    dataset_id TEXT NOT NULL,
    format TEXT NOT NULL,
    row_count INTEGER NOT NULL,
    filters_json TEXT NOT NULL,
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS schedules (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    dataset_id TEXT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    kind TEXT NOT NULL CHECK(kind IN ('digest', 'alert', 'refresh')),
    name TEXT NOT NULL,
    cadence TEXT NOT NULL,
    channel TEXT NOT NULL,
    recipient TEXT NOT NULL,
    config_json TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    last_run_period TEXT,
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS job_runs (
    id TEXT PRIMARY KEY,
    schedule_id TEXT REFERENCES schedules(id) ON DELETE SET NULL,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    job_type TEXT NOT NULL,
    period_key TEXT NOT NULL,
    status TEXT NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    output_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    UNIQUE(schedule_id, period_key)
);

CREATE TABLE IF NOT EXISTS ai_analysis_log (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL,
    dataset_version INTEGER NOT NULL,
    user_id TEXT NOT NULL,
    raw_text TEXT NOT NULL,
    normalised_text TEXT NOT NULL,
    model TEXT NOT NULL,
    intent TEXT NOT NULL,
    slots_json TEXT NOT NULL,
    confidence REAL NOT NULL,
    ambiguities_json TEXT NOT NULL,
    spec_json TEXT NOT NULL,
    sql_hash TEXT NOT NULL,
    query_id TEXT NOT NULL,
    duration_ms INTEGER NOT NULL,
    row_count INTEGER NOT NULL,
    narrative TEXT NOT NULL,
    verification_passed INTEGER NOT NULL,
    rejected_figures_json TEXT NOT NULL,
    outcome TEXT NOT NULL CHECK(outcome IN ('answered', 'clarified', 'refused', 'failed')),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS agent_runs (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    dataset_id TEXT NOT NULL,
    dataset_version INTEGER NOT NULL,
    user_id TEXT NOT NULL REFERENCES users(id),
    goal TEXT NOT NULL,
    status TEXT NOT NULL,
    plan_json TEXT NOT NULL,
    steps_json TEXT NOT NULL,
    evidence_bundle_json TEXT NOT NULL,
    narrative TEXT NOT NULL,
    pending_confirmations_json TEXT NOT NULL DEFAULT '[]',
    budgets_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    id TEXT PRIMARY KEY,
    workspace_id TEXT,
    project_id TEXT,
    user_id TEXT,
    action TEXT NOT NULL,
    object_type TEXT NOT NULL,
    object_id TEXT NOT NULL,
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_projects_ws ON projects(workspace_id);
CREATE INDEX IF NOT EXISTS idx_datasets_proj ON datasets(project_id);
CREATE INDEX IF NOT EXISTS idx_fields_ds_ver ON field_metadata(dataset_id, version);
CREATE INDEX IF NOT EXISTS idx_dashboards_proj ON dashboards(project_id);
CREATE INDEX IF NOT EXISTS idx_audit_obj ON audit_log(object_type, object_id);
"""


def init_db() -> None:
    with get_conn() as conn:
        conn.executescript(SCHEMA_SQL)


def log_audit(conn, *, action: str, object_type: str, object_id: str, user_id: str = None,
              workspace_id: str = None, project_id: str = None, details: dict = None) -> None:
    conn.execute(
        """INSERT INTO audit_log (id, workspace_id, project_id, user_id, action, object_type, object_id, details_json, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            new_id("aud"),
            workspace_id,
            project_id,
            user_id,
            action,
            object_type,
            object_id,
            json.dumps(details or {}),
            now_iso(),
        ),
    )
