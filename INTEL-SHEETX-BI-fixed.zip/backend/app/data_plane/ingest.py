"""
Data Ingestion & Parquet Materialisation Pipeline (Chapter 26.1 & Phase 2).
- Validates size, extension, and binary content signatures (rejects binary masquerading as CSV).
- Detects UTF-8-BOM / UTF-8 / CP1252 encoding and delimiter (comma, semicolon, tab, pipe).
- Lists XLSX sheets and enforces explicit sheet selection when multi-sheet.
- Normalises nulls, currency/thousand formatting, multi-format dates, and preserves leading-zero IDs.
- Materialises immutable raw snapshot + versioned Parquet file via DuckDB.
"""
import csv
import hashlib
import io
import os
import re
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Tuple
import duckdb
from openpyxl import load_workbook
from fastapi import HTTPException
from ..config import settings

BINARY_SIGNATURES = (
    b"\x89PNG",
    b"%PDF",
    b"\xff\xd8\xff",
    b"GIF8",
    b"\x7fELF",
    b"MZ",
)

NULL_TOKENS = {"", "na", "n/a", "null", "none", "-", "nan", "#n/a"}
RE_PRESERVE_TEXT = re.compile(
    r"(^|[_\s])(id|uuid|guid|code|postal|zip|pincode|postcode|order_number|order_no|invoice|customer_id|sku|phone|mobile)([_\s]|$)",
    re.I,
)
RE_CURRENCY_CLEAN = re.compile(r"^[\$€£₹\s]*([+-]?\d{1,3}(?:,\d{2,3})*(?:\.\d+)?|[+-]?\d+(?:\.\d+)?)[\s]*$")
DATE_FORMATS = (
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%d-%m-%Y",
    "%d/%m/%Y",
    "%m/%d/%Y",
    "%d %b %Y",
    "%d %B %Y",
    "%b %d, %Y",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S",
)


class IngestionError(HTTPException):
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(status_code=status_code, detail=message)


def _try_parse_date(val: str) -> Optional[date]:
    s = val.strip()
    if len(s) < 6 or len(s) > 32:
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def _try_parse_number(val: str) -> Optional[float]:
    s = val.strip()
    m = RE_CURRENCY_CLEAN.match(s)
    if not m:
        return None
    try:
        return float(m.group(1).replace(",", ""))
    except ValueError:
        return None


def sniff_csv_bytes(raw_bytes: bytes) -> Tuple[str, str, str]:
    if not raw_bytes or len(raw_bytes.strip()) == 0:
        raise IngestionError("The uploaded file is empty (0 bytes of content). Upload a CSV or XLSX with a header row and data.")

    for sig in BINARY_SIGNATURES:
        if raw_bytes.startswith(sig):
            raise IngestionError("Unsupported binary file signature masquerading as text/CSV. Please upload a genuine CSV or XLSX file.")
    if raw_bytes.startswith(b"PK\x03\x04"):
        raise IngestionError("This file has an XLSX/ZIP binary signature but a .csv extension. Rename or upload it as .xlsx.")
    if b"\x00" in raw_bytes[:4096]:
        raise IngestionError("File contains binary NUL bytes and cannot be parsed as CSV text.")

    encoding = "utf-8"
    if raw_bytes.startswith(b"\xef\xbb\xbf"):
        encoding = "utf-8-sig"
        text = raw_bytes.decode("utf-8-sig")
    else:
        try:
            text = raw_bytes.decode("utf-8")
            encoding = "utf-8"
        except UnicodeDecodeError:
            try:
                text = raw_bytes.decode("cp1252")
                encoding = "cp1252"
            except UnicodeDecodeError as exc:
                raise IngestionError("Unreadable character encoding (neither UTF-8 nor CP1252). Re-save the CSV in UTF-8.") from exc

    sample_lines = "\n".join(text.splitlines()[:25])
    delimiter = ","
    try:
        dialect = csv.Sniffer().sniff(sample_lines, delimiters=",;\t|")
        delimiter = dialect.delimiter
    except Exception:
        counts = {d: sample_lines.count(d) for d in (",", ";", "\t", "|")}
        best = max(counts, key=counts.get)
        if counts[best] > 0:
            delimiter = best

    return text, encoding, delimiter


def inspect_xlsx_sheets(raw_bytes: bytes) -> List[Dict[str, Any]]:
    if not raw_bytes.startswith(b"PK\x03\x04"):
        raise IngestionError("Invalid XLSX file: missing OOXML ZIP signature.")
    try:
        wb = load_workbook(io.BytesIO(raw_bytes), read_only=True, data_only=True)
        sheets = []
        for sname in wb.sheetnames:
            ws = wb[sname]
            preview_headers = []
            approx_rows = 0
            for idx, row in enumerate(ws.iter_rows(values_only=True)):
                if idx == 0:
                    preview_headers = [str(c).strip() if c is not None else f"col_{j+1}" for j, c in enumerate(row)]
                else:
                    if any(c is not None and str(c).strip() != "" for c in row):
                        approx_rows += 1
                if idx >= 500:
                    break
            sheets.append({
                "name": sname,
                "headers": preview_headers[:15],
                "sample_row_count": approx_rows,
            })
        wb.close()
        return sheets
    except IngestionError:
        raise
    except Exception as exc:
        raise IngestionError(f"Could not read XLSX workbook structure: {exc}") from exc


def _normalise_tabular_rows(
    headers: List[str],
    raw_rows: List[List[Any]],
) -> Tuple[List[str], List[str], List[Tuple[Any, ...]], Dict[str, int], List[str]]:
    if not headers or all(h.strip() == "" for h in headers):
        raise IngestionError("Header row is missing or blank. First row must contain column names.")

    # Deduplicate/clean headers
    clean_headers: List[str] = []
    seen: Dict[str, int] = {}
    for idx, h in enumerate(headers):
        base = re.sub(r"\s+", " ", (str(h) if h is not None else "").strip()) or f"column_{idx+1}"
        if base.lower() in seen:
            seen[base.lower()] += 1
            base = f"{base}_{seen[base.lower()]}"
        else:
            seen[base.lower()] = 1
        clean_headers.append(base)

    # Filter completely empty trailing rows
    non_empty_rows: List[List[Any]] = []
    warnings: List[str] = []
    ncols = len(clean_headers)

    for r_idx, r in enumerate(raw_rows, start=2):
        if not r or all(c is None or str(c).strip() == "" for c in r):
            continue
        if len(r) > ncols:
            warnings.append(f"Row {r_idx} had {len(r)} fields (expected {ncols}); extra trailing columns truncated.")
            r = r[:ncols]
        elif len(r) < ncols:
            r = list(r) + [None] * (ncols - len(r))
        non_empty_rows.append(r)

    if not non_empty_rows:
        raise IngestionError("File contains headers but 0 data rows. Upload a file with at least one record.")

    # Infer physical type per column across sample up to 5,000 rows
    col_types: List[str] = []
    date_failures: Dict[str, int] = {}

    for c_idx, cname in enumerate(clean_headers):
        force_text = bool(RE_PRESERVE_TEXT.search(cname))
        vals = [row[c_idx] for row in non_empty_rows]
        non_null_strs: List[str] = []
        has_leading_zero = False
        already_dates = 0
        for v in vals[:5000]:
            if v is None:
                continue
            if isinstance(v, (date, datetime)):
                already_dates += 1
                non_null_strs.append(v.strftime("%Y-%m-%d"))
                continue
            s = str(v).strip()
            if s.lower() in NULL_TOKENS:
                continue
            if len(s) > 1 and s[0] == "0" and s.isdigit():
                has_leading_zero = True
            non_null_strs.append(s)

        if force_text or has_leading_zero or not non_null_strs:
            col_types.append("VARCHAR")
            continue

        # Check date
        date_ok = 0
        for s in non_null_strs:
            if _try_parse_date(s) is not None:
                date_ok += 1
        date_ratio = date_ok / len(non_null_strs)
        if already_dates == len(non_null_strs) or (date_ratio >= 0.75 and ("date" in cname.lower() or "time" in cname.lower() or "month" in cname.lower() or date_ratio >= 0.90)):
            col_types.append("DATE")
            continue

        # Check number
        num_ok = 0
        all_ints = True
        for s in non_null_strs:
            num = _try_parse_number(s)
            if num is not None:
                num_ok += 1
                if not float(num).is_integer() or "." in s:
                    all_ints = False
        if num_ok / len(non_null_strs) >= 0.92:
            col_types.append("BIGINT" if all_ints else "DOUBLE")
        else:
            col_types.append("VARCHAR")

    # Convert all cells deterministically
    typed_rows: List[Tuple[Any, ...]] = []
    for row in non_empty_rows:
        out_row: List[Any] = []
        for c_idx, val in enumerate(row):
            ctype = col_types[c_idx]
            cname = clean_headers[c_idx]
            if val is None:
                out_row.append(None)
                continue
            if isinstance(val, datetime):
                val_d = val.date()
            elif isinstance(val, date):
                val_d = val
            else:
                val_d = None

            s = str(val).strip()
            if s.lower() in NULL_TOKENS:
                out_row.append(None)
                continue

            if ctype == "VARCHAR":
                out_row.append(s)
            elif ctype == "DATE":
                if val_d is not None:
                    out_row.append(val_d)
                else:
                    parsed_d = _try_parse_date(s)
                    if parsed_d is None:
                        date_failures[cname] = date_failures.get(cname, 0) + 1
                        out_row.append(None)
                    else:
                        out_row.append(parsed_d)
            elif ctype == "BIGINT":
                num = _try_parse_number(s)
                out_row.append(int(round(num)) if num is not None else None)
            elif ctype == "DOUBLE":
                num = _try_parse_number(s)
                out_row.append(float(num) if num is not None else None)
        typed_rows.append(tuple(out_row))

    return clean_headers, col_types, typed_rows, date_failures, warnings


def ingest_file_bytes(
    *,
    filename: str,
    raw_bytes: bytes,
    dataset_id: str,
    version: int,
    sheet_name: Optional[str] = None,
) -> Dict[str, Any]:
    max_bytes = settings.max_upload_mb * 1024 * 1024
    if len(raw_bytes) > max_bytes:
        raise IngestionError(
            f"File size ({len(raw_bytes) / (1024*1024):.1f} MB) exceeds maximum allowed limit ({settings.max_upload_mb} MB).",
            status_code=413,
        )

    ext = os.path.splitext(filename.lower())[1]
    if ext not in (".csv", ".tsv", ".txt", ".xlsx"):
        raise IngestionError(f"Unsupported file extension '{ext}'. Supported formats in v1: CSV (.csv) and Excel (.xlsx).")

    content_hash = hashlib.sha256(raw_bytes).hexdigest()

    if ext == ".xlsx":
        sheets = inspect_xlsx_sheets(raw_bytes)
        if not sheets:
            raise IngestionError("XLSX workbook contains no sheets.")
        if not sheet_name:
            if len(sheets) > 1:
                return {
                    "requires_sheet_selection": True,
                    "sheets": sheets,
                    "filename": filename,
                }
            sheet_name = sheets[0]["name"]
        elif sheet_name not in [s["name"] for s in sheets]:
            raise IngestionError(f"Sheet '{sheet_name}' not found. Available sheets: {', '.join(s['name'] for s in sheets)}")

        wb = load_workbook(io.BytesIO(raw_bytes), read_only=True, data_only=True)
        ws = wb[sheet_name]
        all_rows = list(ws.iter_rows(values_only=True))
        wb.close()
        if not all_rows:
            raise IngestionError(f"Selected sheet '{sheet_name}' is empty.")
        # Skip leading single-cell title banner if row 0 has <=2 non-null cells and row 1 has >=3 non-null cells
        header_idx = 0
        if len(all_rows) >= 2:
            r0_non_null = sum(1 for c in all_rows[0] if c is not None and str(c).strip() != "")
            r1_non_null = sum(1 for c in all_rows[1] if c is not None and str(c).strip() != "")
            if r0_non_null <= 2 and r1_non_null >= 3:
                header_idx = 1
        headers = [str(c) if c is not None else "" for c in all_rows[header_idx]]
        raw_rows = [list(r) for r in all_rows[header_idx + 1 :]]
        encoding = "ooxml-utf8"
        delimiter = "xlsx-sheet"
    else:
        text, encoding, delimiter = sniff_csv_bytes(raw_bytes)
        reader = csv.reader(io.StringIO(text), delimiter=delimiter)
        try:
            all_csv_rows = list(reader)
        except csv.Error as exc:
            raise IngestionError(f"Malformed CSV syntax: {exc}") from exc
        if not all_csv_rows:
            raise IngestionError("CSV file has no rows.")
        headers = all_csv_rows[0]
        raw_rows = all_csv_rows[1:]

    clean_headers, col_types, typed_rows, date_failures, warnings = _normalise_tabular_rows(headers, raw_rows)

    # Save immutable raw snapshot by content hash
    storage_dir = os.environ.get("STORAGE_DIR", settings.storage_dir)
    parquet_dir = os.environ.get("PARQUET_DIR", settings.parquet_dir)
    os.makedirs(storage_dir, exist_ok=True)
    os.makedirs(parquet_dir, exist_ok=True)

    raw_path = os.path.join(storage_dir, f"{content_hash}{ext}")
    if not os.path.exists(raw_path):
        with open(raw_path, "wb") as f:
            f.write(raw_bytes)

    parquet_path = os.path.join(parquet_dir, f"{dataset_id}_v{version}.parquet")

    # Materialise to Parquet via DuckDB
    con = duckdb.connect(":memory:")
    try:
        cols_ddl = ", ".join(
            f'"{h.replace(chr(34), chr(34)*2)}" {t}' for h, t in zip(clean_headers, col_types)
        )
        con.execute(f"CREATE TABLE ingested ({cols_ddl})")
        placeholders = ", ".join(["?"] * len(clean_headers))
        con.executemany(f"INSERT INTO ingested VALUES ({placeholders})", typed_rows)
        p_escaped = parquet_path.replace("'", "''")
        con.execute(f"COPY ingested TO '{p_escaped}' (FORMAT PARQUET)")
    finally:
        con.close()

    schema_fp = hashlib.sha256(
        "|".join(f"{h}:{t}" for h, t in zip(clean_headers, col_types)).encode("utf-8")
    ).hexdigest()[:16]

    sample_preview = []
    for r in typed_rows[:50]:
        sample_preview.append({
            h: (v.isoformat() if hasattr(v, "isoformat") else v)
            for h, v in zip(clean_headers, r)
        })

    parse_report = {
        "original_filename": filename,
        "sheet_name": sheet_name,
        "encoding": encoding,
        "delimiter": delimiter,
        "row_count": len(typed_rows),
        "column_count": len(clean_headers),
        "headers": clean_headers,
        "detected_types": dict(zip(clean_headers, col_types)),
        "date_parse_failures": date_failures,
        "warnings": warnings[:25],
        "sample_rows": sample_preview,
    }

    return {
        "requires_sheet_selection": False,
        "content_hash": content_hash,
        "raw_path": raw_path,
        "parquet_path": parquet_path,
        "row_count": len(typed_rows),
        "column_count": len(clean_headers),
        "byte_size": len(raw_bytes),
        "encoding": encoding,
        "delimiter": delimiter,
        "sheet_name": sheet_name,
        "schema_fingerprint": schema_fp,
        "parse_report": parse_report,
        "date_parse_failures": date_failures,
    }
