"""
Explainable Semantic Typing & Sensitive Field Classifier (Chapters 9.1, 26.3 & 33.3).
Implements an ordered rule cascade that outputs (role, semantic_type, default_agg, additive, unit, sensitive, reason).
"""
import re
from typing import Any, Dict

RE_GEO_ID = re.compile(r"(^|[_\s])(postal|zip|pincode|postcode)([_\s]|$)", re.I)
RE_ID_NAME = re.compile(
    r"(^|[_\s])(id|uuid|guid|code|order_number|order_no|invoice|customer_id|order_id|sku|account_no|emp_id)([_\s]|$)",
    re.I,
)
RE_PII_NAME = re.compile(
    r"(^|[_\s])(email|e-mail|phone|mobile|ssn|passport|aadhaar|pan|address|notes|comments|remarks|full_name|customer_name)([_\s]|$)",
    re.I,
)
RE_RATIO_NAME = re.compile(r"(^|[_\s])(rate|pct|percent|percentage|ratio|share|margin_pct|row_margin)([_\s]|$)", re.I)
RE_CURRENCY_NAME = re.compile(
    r"(^|[_\s])(sales|revenue|profit|cost|price|amount|budget|target|target_sales|gross_sales|discount_amount|spend|arr|mrr|value)([_\s]|$)",
    re.I,
)
RE_QTY_NAME = re.compile(r"(^|[_\s])(units|qty|quantity|count|volume|on_hand|returned_units|headcount)([_\s]|$)", re.I)
RE_FLAG_NAME = re.compile(r"(^|[_\s])(is_|has_|on_time|flag|active|churned)", re.I)
RE_DIM_NAME = re.compile(
    r"(^|[_\s])(division|region|country|state|city|product|category|subcategory|segment|channel|department|status|tier|team|brand)([_\s]|$)",
    re.I,
)
RE_EMAIL_VAL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def classify_column(
    name: str,
    physical_type: str,
    row_count: int,
    distinct_count: int,
    sample_values: list[Any],
    date_parse_rate: float = 0.0,
) -> Dict[str, Any]:
    distinct_ratio = (distinct_count / row_count) if row_count > 0 else 0.0
    ptype = physical_type.upper()

    # Sensitivity / PII check (Chapter 33.3)
    sample_strs = [str(v) for v in sample_values if v is not None]
    looks_like_email = any(RE_EMAIL_VAL.match(s) for s in sample_strs)
    high_len_text = ptype == "VARCHAR" and any(len(s) > 65 for s in sample_strs)
    sensitive = bool(RE_PII_NAME.search(name) or looks_like_email or high_len_text)

    # 1. Postal / Geography codes (preserve leading zeroes, never sum)
    if RE_GEO_ID.search(name):
        return {
            "role": "identifier",
            "semantic_type": "geography",
            "default_agg": "count_distinct",
            "additive": "na",
            "unit": None,
            "sensitive": sensitive,
            "exclude_from_ai": sensitive,
            "reason": f"'{name}' matches postal/geography code pattern; stored as identifier so leading zeroes are preserved and values are never summed.",
        }

    # 2. Explicit identifiers (Customer ID, Order Number, SKU, high-uniqueness numeric IDs)
    if RE_ID_NAME.search(name) or (
        ptype in ("BIGINT", "INTEGER") and distinct_ratio >= 0.90 and row_count >= 20 and not RE_CURRENCY_NAME.search(name)
    ):
        return {
            "role": "identifier",
            "semantic_type": "identifier",
            "default_agg": "count_distinct",
            "additive": "na",
            "unit": None,
            "sensitive": sensitive,
            "exclude_from_ai": sensitive,
            "reason": f"'{name}' has identifier naming or near-unique keys ({distinct_count} distinct of {row_count} rows); eligible for COUNT(DISTINCT) only, never SUM.",
        }

    # 3. Date / Timestamp columns
    if "DATE" in ptype or "TIME" in ptype or date_parse_rate >= 0.85:
        return {
            "role": "date",
            "semantic_type": "date",
            "default_agg": None,
            "additive": "na",
            "unit": None,
            "sensitive": False,
            "exclude_from_ai": False,
            "reason": f"'{name}' parses cleanly as a date/time field ({max(date_parse_rate * 100, 95.0):.0f}% valid dates) with time-grain hierarchy support.",
        }

    # 4. Numeric columns: distinguish Flags, Non-Additive Ratios, Semi-Additive Inventory, Currency & Quantities
    if ptype in ("DOUBLE", "FLOAT", "DECIMAL", "BIGINT", "INTEGER", "HUGEINT"):
        if RE_FLAG_NAME.search(name) and distinct_count <= 3:
            return {
                "role": "measure",
                "semantic_type": "flag",
                "default_agg": "sum",
                "additive": "additive",
                "unit": "count",
                "sensitive": False,
                "exclude_from_ai": False,
                "reason": f"'{name}' is a binary indicator ({distinct_count} distinct values); usable for flag counts and rates.",
            }

        if RE_RATIO_NAME.search(name):
            return {
                "role": "measure",
                "semantic_type": "percentage",
                "default_agg": None,
                "additive": "non_additive",
                "unit": "%",
                "sensitive": False,
                "exclude_from_ai": False,
                "reason": f"'{name}' indicates a pre-computed ratio/percentage; flagged non-additive so the engine recomputes ratios from SUM(numerator)/SUM(denominator) instead of averaging rows.",
            }

        if re.search(r"on_hand|inventory|balance", name, re.I):
            return {
                "role": "measure",
                "semantic_type": "quantity",
                "default_agg": "sum",
                "additive": "semi_additive",
                "unit": "units",
                "sensitive": False,
                "exclude_from_ai": False,
                "reason": f"'{name}' represents a stock/balance measure; semi-additive (sums across segments, latest snapshot across time).",
            }

        if RE_CURRENCY_NAME.search(name):
            return {
                "role": "measure",
                "semantic_type": "currency",
                "default_agg": "sum",
                "additive": "additive",
                "unit": "INR",
                "sensitive": False,
                "exclude_from_ai": False,
                "reason": f"'{name}' is numeric with financial measure semantics ({distinct_count} distinct values); additive under SUM.",
            }

        if RE_QTY_NAME.search(name) or distinct_count > 12:
            return {
                "role": "measure",
                "semantic_type": "quantity",
                "default_agg": "sum",
                "additive": "additive",
                "unit": "units",
                "sensitive": False,
                "exclude_from_ai": False,
                "reason": f"'{name}' is a quantitative numeric field ({distinct_count} distinct values); additive measure.",
            }

    # 5. Categorical Dimensions (low/medium cardinality or explicit business dimension name)
    if distinct_count <= 40 or (RE_DIM_NAME.search(name) and distinct_count <= 250):
        return {
            "role": "dimension",
            "semantic_type": "category",
            "default_agg": None,
            "additive": "na",
            "unit": None,
            "sensitive": sensitive,
            "exclude_from_ai": sensitive,
            "reason": f"'{name}' has {distinct_count} distinct values, making it suitable for categorical grouping, sorting, and filtering.",
        }

    # 6. High-cardinality text / detail
    return {
        "role": "detail",
        "semantic_type": "text",
        "default_agg": "count_distinct",
        "additive": "na",
        "unit": None,
        "sensitive": sensitive,
        "exclude_from_ai": True if sensitive else False,
        "reason": f"'{name}' is high-cardinality text ({distinct_count} distinct values); suited for detail tables and tooltips rather than chart axes.",
    }
