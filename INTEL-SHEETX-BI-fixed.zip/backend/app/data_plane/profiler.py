"""
Dataset Profiler & Quality Risk Detector (Chapter 26.2 & Phase 3).
Executes server-side DuckDB aggregations over the versioned Parquet file to compute
exact column statistics, duplicate row rates, key uniqueness, and data quality warnings.
"""
import math
from typing import Any, Dict, List
import duckdb
from .classifier import classify_column


def _clean_num(val: Any) -> Any:
    if val is None:
        return None
    if isinstance(val, float) and (math.isnan(val) or math.isinf(val)):
        return None
    if hasattr(val, "isoformat"):
        return val.isoformat()
    return val


def profile_parquet(
    parquet_path: str,
    date_parse_failures_by_col: Dict[str, int] = None,
) -> Dict[str, Any]:
    date_parse_failures_by_col = date_parse_failures_by_col or {}
    con = duckdb.connect(":memory:")
    try:
        p_escaped = parquet_path.replace("'", "''")
        con.execute(f"CREATE VIEW v_data AS SELECT * FROM read_parquet('{p_escaped}')")

        row_count = con.execute("SELECT COUNT(*) FROM v_data").fetchone()[0]
        desc_rows = con.execute("DESCRIBE v_data").fetchall()

        # Duplicate row check across all columns
        if row_count > 0 and desc_rows:
            distinct_rows = con.execute("SELECT COUNT(*) FROM (SELECT DISTINCT * FROM v_data)").fetchone()[0]
            duplicate_rows = int(row_count - distinct_rows)
            duplicate_rate = round(duplicate_rows / row_count, 6)
        else:
            duplicate_rows = 0
            duplicate_rate = 0.0

        columns_profile: List[Dict[str, Any]] = []
        quality_warnings: List[Dict[str, Any]] = []

        if duplicate_rows > 0:
            quality_warnings.append({
                "severity": "high" if duplicate_rate > 0.05 else "medium",
                "kind": "duplicate_rows",
                "column": "*",
                "count": duplicate_rows,
                "rate": duplicate_rate,
                "message": f"{duplicate_rows} exact duplicate rows detected ({duplicate_rate * 100:.1f}% of dataset). Verify grain before summing additive measures.",
            })

        for col_name, col_type, *_ in desc_rows:
            qcol = f'"{col_name.replace(chr(34), chr(34)*2)}"'
            ptype = col_type.upper()

            base = con.execute(
                f"""SELECT
                        COUNT(*) FILTER (WHERE {qcol} IS NULL) AS null_cnt,
                        COUNT(DISTINCT {qcol}) AS dist_cnt
                    FROM v_data"""
            ).fetchone()
            null_cnt = int(base[0] or 0)
            dist_cnt = int(base[1] or 0)
            null_rate = round(null_cnt / row_count, 6) if row_count > 0 else 0.0

            stats: Dict[str, Any] = {
                "null_count": null_cnt,
                "null_rate": null_rate,
                "distinct_count": dist_cnt,
                "date_parse_failures": int(date_parse_failures_by_col.get(col_name, 0)),
            }

            is_num = any(t in ptype for t in ("DOUBLE", "FLOAT", "DECIMAL", "INT", "BIGINT", "HUGEINT"))
            is_date = "DATE" in ptype or "TIME" in ptype

            if is_num and row_count > null_cnt:
                num_row = con.execute(
                    f"""SELECT
                            MIN({qcol}), MAX({qcol}), AVG({qcol}), MEDIAN({qcol}), STDDEV_SAMP({qcol}),
                            COUNT(*) FILTER (WHERE {qcol} < 0),
                            COUNT(*) FILTER (WHERE {qcol} = 0)
                        FROM v_data"""
                ).fetchone()
                stats.update({
                    "min": _clean_num(num_row[0]),
                    "max": _clean_num(num_row[1]),
                    "mean": round(float(num_row[2]), 4) if num_row[2] is not None and not math.isnan(num_row[2]) else None,
                    "median": _clean_num(num_row[3]),
                    "stdev": round(float(num_row[4]), 4) if num_row[4] is not None and not math.isnan(num_row[4]) else None,
                    "negative_count": int(num_row[5] or 0),
                    "zero_count": int(num_row[6] or 0),
                })
            elif is_date and row_count > null_cnt:
                d_row = con.execute(f"SELECT MIN({qcol}), MAX({qcol}) FROM v_data").fetchone()
                stats.update({
                    "min": _clean_num(d_row[0]),
                    "max": _clean_num(d_row[1]),
                    "negative_count": 0,
                    "zero_count": 0,
                })
            else:
                stats.update({"min": None, "max": None, "negative_count": 0, "zero_count": 0})

            top_vals_rows = con.execute(
                f"""SELECT CAST({qcol} AS VARCHAR) AS val, COUNT(*) AS n
                    FROM v_data
                    WHERE {qcol} IS NOT NULL
                    GROUP BY 1
                    ORDER BY n DESC, val ASC
                    LIMIT 10"""
            ).fetchall()
            stats["top_values"] = [{"value": r[0], "count": int(r[1])} for r in top_vals_rows]
            sample_vals = [r[0] for r in top_vals_rows[:5]]
            stats["sample_values"] = sample_vals

            parse_fails = stats["date_parse_failures"]
            valid_dates = max(0, row_count - null_cnt) if is_date else 0
            date_parse_rate = (
                valid_dates / max(1, valid_dates + parse_fails)
                if (is_date or parse_fails > 0)
                else 0.0
            )

            cls = classify_column(
                name=col_name,
                physical_type=ptype,
                row_count=row_count,
                distinct_count=dist_cnt,
                sample_values=sample_vals,
                date_parse_rate=date_parse_rate,
            )

            # Key uniqueness check for identifier columns
            is_unique_key = (dist_cnt == row_count and null_cnt == 0 and row_count > 0)
            stats["is_unique_key"] = is_unique_key
            if cls["role"] == "identifier" and not is_unique_key and dist_cnt > 0:
                lines_per_key = round((row_count - null_cnt) / dist_cnt, 2)
                stats["records_per_key"] = lines_per_key

            # Quality warnings
            if null_rate > 0:
                severity = "high" if null_rate >= 0.05 else "low"
                quality_warnings.append({
                    "severity": severity,
                    "kind": "missing_values",
                    "column": col_name,
                    "count": null_cnt,
                    "rate": null_rate,
                    "message": f"'{col_name}' has {null_cnt} missing values ({null_rate * 100:.1f}%). Metrics referencing '{col_name}' ignore NULL rows; verify completeness.",
                })
            if parse_fails > 0:
                quality_warnings.append({
                    "severity": "medium",
                    "kind": "date_parse_failure",
                    "column": col_name,
                    "count": parse_fails,
                    "rate": round(parse_fails / max(1, row_count), 6),
                    "message": f"'{col_name}' had {parse_fails} unparseable date values converted to NULL during ingestion.",
                })
            if dist_cnt <= 1 and row_count > 1:
                quality_warnings.append({
                    "severity": "low",
                    "kind": "constant_column",
                    "column": col_name,
                    "count": row_count,
                    "rate": 1.0,
                    "message": f"'{col_name}' has only {dist_cnt} distinct value across {row_count} rows and cannot split comparisons.",
                })

            columns_profile.append({
                "name": col_name,
                "physical_type": ptype,
                "semantic_type": cls["semantic_type"],
                "role": cls["role"],
                "default_agg": cls["default_agg"],
                "additive": cls["additive"],
                "unit": cls["unit"],
                "sensitive": cls["sensitive"],
                "exclude_from_ai": cls["exclude_from_ai"],
                "distinct_count": dist_cnt,
                "null_count": null_cnt,
                "null_rate": null_rate,
                "reason": cls["reason"],
                "stats": stats,
            })

        # Infer human-readable grain statement (Chapter 5.1)
        id_cols = [c for c in columns_profile if c["role"] == "identifier" and c["semantic_type"] == "identifier"]
        grain_statement = f"One row per record ({row_count:,} rows)"
        if id_cols:
            primary_id = id_cols[0]
            if primary_id["stats"].get("is_unique_key"):
                grain_statement = f"One row per unique {primary_id['name']} ({row_count:,} records)"
            else:
                rpk = primary_id["stats"].get("records_per_key", 1.0)
                grain_statement = (
                    f"Sub-entity / line-item grain (~{rpk} rows per distinct {primary_id['name']}; "
                    f"{primary_id['distinct_count']:,} distinct {primary_id['name']} across {row_count:,} rows)"
                )

        return {
            "row_count": row_count,
            "column_count": len(columns_profile),
            "duplicate_rows": duplicate_rows,
            "duplicate_rate": duplicate_rate,
            "grain_statement": grain_statement,
            "columns": columns_profile,
            "quality_warnings": quality_warnings,
        }
    finally:
        con.close()
