"""INTEL SHEETX BI Backend Package."""
APP_VERSION = "1.0.0-2026.10"
