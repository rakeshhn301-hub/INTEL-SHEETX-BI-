"""
Parameterized SQL Query Compiler & Execution Service (Chapter 28).
- Strictly compiles validated ChartSpec objects into bound-parameter DuckDB SQL.
- Zero string interpolation of user filter values.
- Enforces identifier summing bans, non-additive ratio bans, zero-denominator NULL preservation,
  semi-additive latest-snapshot evaluation, Top-N + 'Other' category rollups, and scoped caching.
"""
import hashlib
import json
import math
import time
from collections import OrderedDict
from datetime import date, timedelta
from typing import Any, Dict, List, Optional, Tuple
import duckdb
from fastapi import HTTPException
from ..config import settings
from ..db import new_id
from .spec import ChartSpec, FilterClause, PeriodSpec

# Scoped in-process LRU cache keyed by (user_scope, dataset_id, version, sql_hash, params_json)
_QUERY_CACHE: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()
_MAX_CACHE_ENTRIES = 256


def clear_dataset_cache(dataset_id: str) -> int:
    keys = [k for k in _QUERY_CACHE if f"|{dataset_id}|" in k]
    for k in keys:
        _QUERY_CACHE.pop(k, None)
    return len(keys)


def _qident(col_name: str) -> str:
    return f'"{col_name.replace(chr(34), chr(34)*2)}"'


def _clean_val(v: Any) -> Any:
    if v is None:
        return None
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return None
    if hasattr(v, "isoformat"):
        return v.isoformat()
    return v


def _compile_filters(
    filters: List[FilterClause],
    period: Optional[PeriodSpec],
    fields_map: Dict[str, Dict[str, Any]],
    parquet_path: str,
) -> Tuple[List[str], List[Any], List[str]]:
    clauses: List[str] = []
    params: List[Any] = []
    applied_descriptions: List[str] = []

    for flt in filters:
        fmeta = fields_map.get(flt.field.lower())
        if not fmeta:
            raise HTTPException(status_code=400, detail=f"Unknown filter field '{flt.field}'.")
        qcol = _qident(fmeta["name"])
        op = flt.op
        val = flt.value

        if op == "=":
            clauses.append(f"{qcol} = ?")
            params.append(val)
            applied_descriptions.append(f"{fmeta['name']} = {val}")
        elif op == "!=":
            clauses.append(f"{qcol} != ?")
            params.append(val)
            applied_descriptions.append(f"{fmeta['name']} != {val}")
        elif op == "in":
            if not isinstance(val, list) or len(val) == 0:
                raise HTTPException(status_code=400, detail=f"Filter 'in' on '{fmeta['name']}' requires a non-empty list.")
            ph = ", ".join(["?"] * len(val))
            clauses.append(f"{qcol} IN ({ph})")
            params.extend(val)
            applied_descriptions.append(f"{fmeta['name']} in ({', '.join(str(x) for x in val)})")
        elif op == "between":
            if not isinstance(val, list) or len(val) != 2:
                raise HTTPException(status_code=400, detail=f"Filter 'between' on '{fmeta['name']}' requires [from, to].")
            clauses.append(f"{qcol} BETWEEN ? AND ?")
            params.extend([val[0], val[1]])
            applied_descriptions.append(f"{fmeta['name']}: {val[0]} to {val[1]}")
        elif op == ">=":
            clauses.append(f"{qcol} >= ?")
            params.append(val)
            applied_descriptions.append(f"{fmeta['name']} >= {val}")
        elif op == "<=":
            clauses.append(f"{qcol} <= ?")
            params.append(val)
            applied_descriptions.append(f"{fmeta['name']} <= {val}")
        elif op == "contains":
            clauses.append(f"CAST({qcol} AS VARCHAR) ILIKE ?")
            params.append(f"%{val}%")
            applied_descriptions.append(f"{fmeta['name']} contains '{val}'")
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported filter operator '{op}'.")

    # Period clause bound to the primary date column
    date_fields = [f for f in fields_map.values() if f["role"] == "date"]
    if period and date_fields:
        dfield = date_fields[0]["name"]
        qd = _qident(dfield)
        if period.kind == "absolute" and (period.from_date or period.to_date):
            if period.from_date and period.to_date:
                clauses.append(f"{qd} BETWEEN CAST(? AS DATE) AND CAST(? AS DATE)")
                params.extend([period.from_date, period.to_date])
                applied_descriptions.append(f"{dfield}: {period.from_date}..{period.to_date}")
            elif period.from_date:
                clauses.append(f"{qd} >= CAST(? AS DATE)")
                params.append(period.from_date)
                applied_descriptions.append(f"{dfield} >= {period.from_date}")
            elif period.to_date:
                clauses.append(f"{qd} <= CAST(? AS DATE)")
                params.append(period.to_date)
                applied_descriptions.append(f"{dfield} <= {period.to_date}")
        elif period.kind == "relative" and period.value:
            # Anchor relative periods to the dataset's max date so historical extracts behave deterministically
            con = duckdb.connect(":memory:")
            try:
                p_esc = parquet_path.replace("'", "''")
                max_d_row = con.execute(f"SELECT MAX({qd}) FROM read_parquet('{p_esc}')").fetchone()
                anchor: date = max_d_row[0] if max_d_row and max_d_row[0] else date(2026, 10, 25)
            finally:
                con.close()

            rv = period.value.lower()
            start_d = anchor
            end_d = anchor
            if rv in ("ytd", "this_year"):
                start_d = date(anchor.year, 1, 1)
            elif rv == "last_year":
                start_d = date(anchor.year - 1, 1, 1)
                end_d = date(anchor.year - 1, 12, 31)
            elif rv in ("qtd", "this_quarter"):
                q_month = ((anchor.month - 1) // 3) * 3 + 1
                start_d = date(anchor.year, q_month, 1)
            elif rv == "last_quarter":
                q_month = ((anchor.month - 1) // 3) * 3 + 1
                first_this_q = date(anchor.year, q_month, 1)
                end_d = first_this_q - timedelta(days=1)
                pq_month = ((end_d.month - 1) // 3) * 3 + 1
                start_d = date(end_d.year, pq_month, 1)
            elif rv in ("mtd", "this_month"):
                start_d = date(anchor.year, anchor.month, 1)
            elif rv == "last_30_days":
                start_d = anchor - timedelta(days=30)
            elif rv == "last_90_days":
                start_d = anchor - timedelta(days=90)
            else:
                start_d = date(anchor.year, 1, 1)

            clauses.append(f"{qd} BETWEEN CAST(? AS DATE) AND CAST(? AS DATE)")
            params.extend([start_d.isoformat(), end_d.isoformat()])
            applied_descriptions.append(f"{dfield}: {start_d.isoformat()}..{end_d.isoformat()} ({rv})")

    return clauses, params, applied_descriptions


def _metric_sql_expr(
    metric: Dict[str, Any],
    *,
    has_date_group: bool = False,
    what_if: Optional[Any] = None,
) -> str:
    bound = metric["bound"]
    kind = metric["kind"]

    if "custom_sql" in bound:
        return bound["custom_sql"]

    # Optional deterministic What-If multiplier (Chapter 12.6)
    mult = 1.0
    if what_if and getattr(what_if, "delta_pct", 0.0) != 0.0:
        mult = 1.0 + (float(what_if.delta_pct) / 100.0)

    if kind == "additive":
        qf = _qident(bound["field"])
        if mult != 1.0 and what_if.parameter in ("price_pct", "volume_pct"):
            return f"(SUM({qf}) * {mult:.6f})"
        return f"SUM({qf})"

    if kind == "distinct":
        qf = _qident(bound["field"])
        return f"COUNT(DISTINCT {qf})"

    if kind == "ratio":
        if bound.get("expr_type") == "diff_over_den":
            qs = _qident(bound["sales_field"])
            qc = _qident(bound["cost_field"])
            s_expr = f"(SUM({qs}) * {mult:.6f})" if (mult != 1.0 and what_if and what_if.parameter == "price_pct") else f"SUM({qs})"
            c_expr = f"(SUM({qc}) * {mult:.6f})" if (mult != 1.0 and what_if and what_if.parameter == "cost_pct") else f"SUM({qc})"
            return f"((CAST({s_expr} AS DOUBLE) - CAST({c_expr} AS DOUBLE)) / NULLIF(CAST({s_expr} AS DOUBLE), 0.0))"

        nf = _qident(bound["num_field"])
        df = _qident(bound["den_field"])
        num_sql = f"COUNT(DISTINCT {nf})" if bound.get("num_agg") == "count_distinct" else f"SUM({nf})"
        if bound.get("den_agg") == "count_distinct":
            den_sql = f"COUNT(DISTINCT {df})"
        elif bound.get("den_agg") == "count_non_null":
            den_sql = f"COUNT({df})"
        else:
            den_sql = f"SUM({df})"
        return f"(CAST({num_sql} AS DOUBLE) / NULLIF(CAST({den_sql} AS DOUBLE), 0.0))"

    if kind == "semi_additive":
        qq = _qident(bound["qty_field"])
        qu = _qident(bound["cost_field"])
        if not has_date_group and bound.get("date_field"):
            qd = _qident(bound["date_field"])
            return f"SUM(CASE WHEN {qd} = max_snap_dt THEN {qq} * {qu} ELSE NULL END)"
        return f"SUM({qq} * {qu})"

    if kind == "window":
        wtype = bound.get("window_type")
        qf = _qident(bound["field"])
        qd = _qident(bound["date_field"])
        if wtype == "active_window_90d":
            return f"COUNT(DISTINCT CASE WHEN {qd} >= (max_snap_dt - INTERVAL 90 DAY) THEN {qf} ELSE NULL END)"
        # yoy_growth evaluated across years in dataset/filtered scope
        return (
            f"((CAST(SUM(CASE WHEN EXTRACT(YEAR FROM {qd}) = EXTRACT(YEAR FROM max_snap_dt) THEN {qf} ELSE 0 END) AS DOUBLE) - "
            f"CAST(SUM(CASE WHEN EXTRACT(YEAR FROM {qd}) = EXTRACT(YEAR FROM max_snap_dt) - 1 THEN {qf} ELSE 0 END) AS DOUBLE)) / "
            f"NULLIF(CAST(SUM(CASE WHEN EXTRACT(YEAR FROM {qd}) = EXTRACT(YEAR FROM max_snap_dt) - 1 THEN {qf} ELSE 0 END) AS DOUBLE), 0.0))"
        )

    raise HTTPException(status_code=400, detail=f"Unsupported metric kind '{kind}'.")


def compile_and_execute(
    *,
    spec: ChartSpec,
    parquet_path: str,
    dataset_version: int,
    dataset_fields: List[Dict[str, Any]],
    resolved_metrics: List[Dict[str, Any]],
    user_scope: str,
) -> Dict[str, Any]:
    """
    Compiles a validated ChartSpec into parameterized DuckDB SQL, executes it against the
    versioned Parquet file, enforces categorical & row caps, and returns provenance metadata.
    """
    fields_map = {f["name"].lower(): f for f in dataset_fields if not f.get("hidden")}
    metrics_map = {m["metric_key"].lower(): m for m in resolved_metrics if m["available"]}

    # Validate & resolve requested measures (allow metric_key OR safe additive measure column fallback)
    active_metrics: List[Dict[str, Any]] = []
    for mslot in spec.measures:
        mkey = mslot.metric.lower()
        if mkey in metrics_map:
            active_metrics.append(metrics_map[mkey])
        elif f"sum_{mkey}" in metrics_map:
            active_metrics.append(metrics_map[f"sum_{mkey}"])
        elif mkey in fields_map:
            fmeta = fields_map[mkey]
            if fmeta["role"] == "identifier":
                raise HTTPException(
                    status_code=400,
                    detail=f"Guardrail violation: '{fmeta['name']}' is classified as an identifier and may never be summed. Use COUNT(DISTINCT) instead.",
                )
            if fmeta["additive"] == "non_additive":
                raise HTTPException(
                    status_code=400,
                    detail=f"Guardrail violation: '{fmeta['name']}' is a non-additive percentage/ratio column. Compute ratios as SUM(numerator)/SUM(denominator) via the metric layer.",
                )
            if fmeta["role"] != "measure":
                raise HTTPException(
                    status_code=400,
                    detail=f"Field '{fmeta['name']}' has role '{fmeta['role']}' and cannot be aggregated as a numeric measure.",
                )
            active_metrics.append({
                "metric_key": f"sum_{mkey}",
                "label": fmeta["name"],
                "kind": "additive",
                "formula_display": f"SUM({fmeta['name']})",
                "format": {"kind": "currency" if fmeta["semantic_type"] == "currency" else "number", "currency": "INR", "decimals": 2},
                "bound": {"field": fmeta["name"]},
            })
        else:
            unavailable = next((m for m in resolved_metrics if m["metric_key"].lower() == mkey and not m["available"]), None)
            if unavailable:
                raise HTTPException(
                    status_code=400,
                    detail=f"Metric '{unavailable['label']}' cannot run on this dataset; missing required columns: {', '.join(unavailable['missing_requirements'])}.",
                )
            raise HTTPException(status_code=400, detail=f"Unknown metric or measure '{mslot.metric}'.")

    where_clauses, params, filter_descriptions = _compile_filters(spec.filters, spec.period, fields_map, parquet_path)
    where_sql = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""
    p_esc = parquet_path.replace("'", "''")

    # Find date column for snapshot/window anchor CTE
    date_cols = [f["name"] for f in dataset_fields if f["role"] == "date"]
    snap_expr = f"MAX({_qident(date_cols[0])})" if date_cols else "CURRENT_DATE"

    # Special Case 1: Histogram (A6_distribution) — server-side binning in DuckDB
    if spec.intent == "A6_distribution" or spec.chart_type == "histogram":
        if not active_metrics:
            raise HTTPException(status_code=400, detail="Distribution requires one numeric measure.")
        target_m = active_metrics[0]
        raw_field = target_m["bound"].get("field") or target_m["bound"].get("num_field")
        if not raw_field:
            raise HTTPException(status_code=400, detail="Histogram requires a numeric column.")
        qf = _qident(raw_field)
        nbins = max(4, min(30, spec.bins))
        sql = f"""
        WITH filtered AS (
            SELECT {qf} AS val FROM read_parquet('{p_esc}') {where_sql}
        ),
        bounds AS (
            SELECT MIN(val) AS min_v, MAX(val) AS max_v, COUNT(val) AS cnt FROM filtered WHERE val IS NOT NULL
        ),
        binned AS (
            SELECT
                CASE
                    WHEN b.max_v = b.min_v THEN 0
                    ELSE LEAST({nbins} - 1, CAST(FLOOR((f.val - b.min_v) / NULLIF((b.max_v - b.min_v) / {nbins}.0, 0)) AS INTEGER))
                END AS bin_idx,
                b.min_v,
                b.max_v,
                (b.max_v - b.min_v) / {nbins}.0 AS bin_w
            FROM filtered f CROSS JOIN bounds b
            WHERE f.val IS NOT NULL
        )
        SELECT
            bin_idx,
            ROUND(min_v + bin_idx * bin_w, 2) AS bin_start,
            ROUND(min_v + (bin_idx + 1) * bin_w, 2) AS bin_end,
            COUNT(*) AS record_count
        FROM binned
        GROUP BY 1, 2, 3
        ORDER BY bin_idx ASC
        """
        return _run_sql_with_cache(
            sql=sql,
            params=params,
            spec=spec,
            dataset_version=dataset_version,
            user_scope=user_scope,
            active_metrics=active_metrics,
            filter_descriptions=filter_descriptions,
        )

    # Special Case 2: Scatter (A5_relationship) — two measures at entity/order grain
    if spec.intent == "A5_relationship" or spec.chart_type == "scatter":
        if len(active_metrics) < 2:
            raise HTTPException(status_code=400, detail="Scatter relationship requires two numeric measures.")
        m1, m2 = active_metrics[0], active_metrics[1]
        # Group by primary identifier (e.g. order_number) if present, else dim, else bounded row grain
        grain_col = None
        if spec.dimensions:
            d0 = fields_map.get(spec.dimensions[0].field.lower())
            if d0:
                grain_col = d0["name"]
        if not grain_col:
            id_cands = [f["name"] for f in dataset_fields if f["role"] == "identifier" and f["semantic_type"] == "identifier"]
            grain_col = id_cands[0] if id_cands else None

        e1 = _metric_sql_expr(m1, what_if=spec.what_if)
        e2 = _metric_sql_expr(m2, what_if=spec.what_if)
        cap = min(spec.limit if spec.limit > 20 else 500, settings.max_result_rows)
        if grain_col:
            qg = _qident(grain_col)
            sql = f"""
            WITH base AS (SELECT * FROM read_parquet('{p_esc}') {where_sql}),
                 meta AS (SELECT {snap_expr} AS max_snap_dt FROM base)
            SELECT CAST({qg} AS VARCHAR) AS entity_key,
                   {e1} AS "{m1['metric_key']}",
                   {e2} AS "{m2['metric_key']}"
            FROM base CROSS JOIN meta
            WHERE {qg} IS NOT NULL
            GROUP BY 1
            LIMIT {cap}
            """
        else:
            f1 = _qident(m1["bound"]["field"])
            f2 = _qident(m2["bound"]["field"])
            sql = f"""
            SELECT CAST(ROW_NUMBER() OVER () AS VARCHAR) AS entity_key,
                   {f1} AS "{m1['metric_key']}",
                   {f2} AS "{m2['metric_key']}"
            FROM read_parquet('{p_esc}')
            {where_sql}
            LIMIT {cap}
            """
        return _run_sql_with_cache(
            sql=sql,
            params=params,
            spec=spec,
            dataset_version=dataset_version,
            user_scope=user_scope,
            active_metrics=active_metrics,
            filter_descriptions=filter_descriptions,
        )

    # Standard Analytical Grouping (A1, A2, A3, A4, A7, A8, A9, A10, KPI, Table, Heatmap)
    dim_selects: List[str] = []
    group_positions: List[str] = []
    has_date_group = False
    primary_dim_alias = None
    is_time_dim = False

    for idx, dslot in enumerate(spec.dimensions):
        fmeta = fields_map.get(dslot.field.lower())
        if not fmeta:
            raise HTTPException(status_code=400, detail=f"Unknown dimension '{dslot.field}'.")
        qd = _qident(fmeta["name"])
        alias = fmeta["name"]
        if fmeta["role"] == "date" or dslot.grain:
            if fmeta["role"] != "date":
                raise HTTPException(status_code=400, detail=f"Time grain requested on non-date column '{fmeta['name']}'.")
            grain = dslot.grain or "month"
            if grain not in ("day", "week", "month", "quarter", "year"):
                raise HTTPException(status_code=400, detail=f"Unsupported time grain '{grain}'.")
            dim_selects.append(f"CAST(DATE_TRUNC('{grain}', {qd}) AS DATE) AS {_qident(alias)}")
            has_date_group = True
            if idx == 0:
                is_time_dim = True
        else:
            dim_selects.append(f"COALESCE(CAST({qd} AS VARCHAR), '(Missing)') AS {_qident(alias)}")
        if idx == 0:
            primary_dim_alias = alias
        group_positions.append(str(idx + 1))

    if spec.series_dimension:
        sf = fields_map.get(spec.series_dimension.lower())
        if not sf:
            raise HTTPException(status_code=400, detail=f"Unknown series field '{spec.series_dimension}'.")
        qs = _qident(sf["name"])
        dim_selects.append(f"COALESCE(CAST({qs} AS VARCHAR), '(Missing)') AS {_qident(sf['name'])}")
        group_positions.append(str(len(dim_selects)))

    if not active_metrics:
        raise HTTPException(status_code=400, detail="Query specification requires at least one metric.")

    measure_selects = [
        f'{_metric_sql_expr(m, has_date_group=has_date_group, what_if=spec.what_if)} AS {_qident(m["metric_key"])}'
        for m in active_metrics
    ]

    all_selects = dim_selects + measure_selects
    group_sql = f"GROUP BY {', '.join(group_positions)}" if group_positions else ""

    # Determine deterministic sort order (Chapter 4.3 & 6.3: time chronologically ASC, categories by measure DESC)
    primary_m_alias = _qident(active_metrics[0]["metric_key"])
    if not group_positions:
        order_sql = ""
    elif is_time_dim:
        order_sql = f"ORDER BY {_qident(primary_dim_alias)} ASC"
    else:
        d0_sort = spec.dimensions[0].sort if spec.dimensions else None
        if d0_sort and d0_sort.by == "dimension":
            sdir = "ASC" if d0_sort.dir == "asc" else "DESC"
            order_sql = f"ORDER BY {_qident(primary_dim_alias)} {sdir}"
        else:
            sdir = "ASC" if (d0_sort and d0_sort.dir == "asc") else "DESC"
            order_sql = f"ORDER BY {primary_m_alias} {sdir} NULLS LAST, {_qident(primary_dim_alias)} ASC"

    # Prior-year comparison on time-series (Chapter 28.3)
    if is_time_dim and spec.compare == "prior_year" and len(active_metrics) == 1 and active_metrics[0]["kind"] == "additive":
        dcol_raw = _qident(fields_map[spec.dimensions[0].field.lower()]["name"])
        grain = spec.dimensions[0].grain or "month"
        m0 = active_metrics[0]
        mf = _qident(m0["bound"]["field"])
        sql = f"""
        WITH base AS (SELECT * FROM read_parquet('{p_esc}') {where_sql}),
             cur AS (
                 SELECT CAST(DATE_TRUNC('{grain}', {dcol_raw}) AS DATE) AS period_dt,
                        SUM({mf}) AS cur_val
                 FROM base
                 WHERE {dcol_raw} IS NOT NULL
                 GROUP BY 1
             )
        SELECT cur.period_dt AS {_qident(primary_dim_alias)},
               cur.cur_val AS {_qident(m0['metric_key'])},
               LAG(cur.cur_val, 12) OVER (ORDER BY cur.period_dt) AS "prior_year",
               (cur.cur_val - LAG(cur.cur_val, 12) OVER (ORDER BY cur.period_dt)) AS "delta"
        FROM cur
        ORDER BY 1 ASC
        LIMIT {min(spec.limit if spec.limit > 24 else 120, settings.max_result_rows)}
        """
        return _run_sql_with_cache(
            sql=sql,
            params=params,
            spec=spec,
            dataset_version=dataset_version,
            user_scope=user_scope,
            active_metrics=active_metrics,
            filter_descriptions=filter_descriptions,
        )

    effective_limit = min(spec.limit, settings.max_result_rows)
    if is_time_dim and spec.limit <= 20:
        effective_limit = min(240, settings.max_result_rows)  # Never truncate 24 months of a trend at 12 by accident

    sql = f"""
    WITH base AS (
        SELECT * FROM read_parquet('{p_esc}')
        {where_sql}
    ),
    meta AS (
        SELECT {snap_expr} AS max_snap_dt FROM base
    ),
    agg AS (
        SELECT {', '.join(all_selects)}
        FROM base CROSS JOIN meta
        {group_sql}
    )
    SELECT * FROM agg
    {order_sql}
    """

    return _run_sql_with_cache(
        sql=sql,
        params=params,
        spec=spec,
        dataset_version=dataset_version,
        user_scope=user_scope,
        active_metrics=active_metrics,
        filter_descriptions=filter_descriptions,
        category_cap=None if (is_time_dim or not group_positions or spec.chart_type == "table") else effective_limit,
        table_limit=effective_limit if spec.chart_type == "table" else settings.max_result_rows,
        primary_dim=primary_dim_alias,
    )


def _run_sql_with_cache(
    *,
    sql: str,
    params: List[Any],
    spec: ChartSpec,
    dataset_version: int,
    user_scope: str,
    active_metrics: List[Dict[str, Any]],
    filter_descriptions: List[str],
    category_cap: Optional[int] = None,
    table_limit: int = 5000,
    primary_dim: Optional[str] = None,
) -> Dict[str, Any]:
    sql_norm = " ".join(sql.split())
    sql_hash = hashlib.sha256(sql_norm.encode("utf-8")).hexdigest()[:16]
    params_json = json.dumps(params, default=str)
    cache_key = f"{user_scope}|{spec.dataset_id}|v{dataset_version}|{sql_hash}|{params_json}|{category_cap}|{table_limit}"

    if cache_key in _QUERY_CACHE:
        cached = dict(_QUERY_CACHE[cache_key])
        cached["cached"] = True
        return cached

    t0 = time.perf_counter()
    con = duckdb.connect(":memory:")
    try:
        cur = con.execute(sql, params)
        col_names = [d[0] for d in cur.description]
        raw_rows = cur.fetchall()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Query execution failed safely: {exc}") from exc
    finally:
        con.close()

    duration_ms = max(1, int((time.perf_counter() - t0) * 1000))
    total_groups = len(raw_rows)
    hidden_count = 0

    rows_dicts: List[Dict[str, Any]] = []
    for r in raw_rows:
        rows_dicts.append({col_names[i]: _clean_val(r[i]) for i in range(len(col_names))})

    # Apply Top-N + 'Other' disclosure on categorical charts (Chapter 6.3 & 19.3)
    if category_cap and total_groups > category_cap and primary_dim and len(spec.dimensions) == 1 and not spec.series_dimension:
        top_part = rows_dicts[:category_cap]
        rest_part = rows_dicts[category_cap:]
        hidden_count = len(rest_part)
        # Only synthesize an 'Other' bar if all active metrics are strictly additive
        if all(m["kind"] == "additive" for m in active_metrics):
            other_row: Dict[str, Any] = {primary_dim: f"Other ({hidden_count} more)"}
            for m in active_metrics:
                mk = m["metric_key"]
                other_row[mk] = round(sum(float(x[mk] or 0.0) for x in rest_part), 4)
            rows_dicts = top_part + [other_row]
        else:
            rows_dicts = top_part
    elif len(rows_dicts) > table_limit:
        hidden_count = len(rows_dicts) - table_limit
        rows_dicts = rows_dicts[:table_limit]

    query_id = new_id("q")
    result = {
        "query_id": query_id,
        "dataset_id": spec.dataset_id,
        "dataset_version": dataset_version,
        "sql": sql_norm,
        "sql_hash": sql_hash,
        "params": params,
        "columns": col_names,
        "rows": rows_dicts,
        "row_count": len(rows_dicts),
        "total_groups_before_cap": total_groups,
        "hidden_categories_count": hidden_count,
        "duration_ms": duration_ms,
        "applied_filters": filter_descriptions,
        "metrics_used": [
            {
                "metric_key": m["metric_key"],
                "label": m["label"],
                "formula": m["formula_display"],
                "kind": m["kind"],
                "format": m["format"],
            }
            for m in active_metrics
        ],
        "cached": False,
    }

    _QUERY_CACHE[cache_key] = result
    while len(_QUERY_CACHE) > _MAX_CACHE_ENTRIES:
        _QUERY_CACHE.popitem(last=False)

    return result
