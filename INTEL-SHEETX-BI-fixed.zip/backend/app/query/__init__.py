"""Query specification and parameterized SQL compiler package."""
