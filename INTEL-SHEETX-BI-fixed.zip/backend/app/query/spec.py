"""
Typed Chart & Query Specification Schema (Chapters 6.4, 18.3 & 28.1).
"""
from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field

IntentType = Literal[
    "A1_compare",
    "A2_trend",
    "A3_composition",
    "A4_rank",
    "A5_relationship",
    "A6_distribution",
    "A7_target",
    "A8_anomaly",
    "A9_summary",
    "A10_explain",
    "UNSUPPORTED",
]

ChartType = Literal[
    "bar_h",
    "bar",
    "line",
    "area",
    "scatter",
    "histogram",
    "stacked_bar",
    "pct_bar",
    "donut",
    "kpi",
    "table",
    "heatmap",
    "waterfall",
    "pareto",
    "bullet",
]

FilterOp = Literal["=", "!=", "in", "between", ">=", "<=", "contains"]
TimeGrain = Literal["day", "week", "month", "quarter", "year"]


class SortSpec(BaseModel):
    by: Literal["measure", "dimension"] = "measure"
    dir: Literal["asc", "desc"] = "desc"


class DimensionSlot(BaseModel):
    field: str
    grain: Optional[TimeGrain] = None
    sort: Optional[SortSpec] = None


class MeasureSlot(BaseModel):
    metric: str


class FilterClause(BaseModel):
    field: str
    op: FilterOp
    value: Any


class PeriodSpec(BaseModel):
    kind: Literal["relative", "absolute"]
    value: Optional[str] = None
    from_date: Optional[str] = Field(default=None, alias="from")
    to_date: Optional[str] = Field(default=None, alias="to")

    model_config = {"populate_by_name": True}


class WhatIfSpec(BaseModel):
    parameter: Literal["price_pct", "volume_pct", "cost_pct"] = "price_pct"
    delta_pct: float = 0.0  # e.g. +5.0 means +5%


class ChartSpec(BaseModel):
    intent: IntentType = "A1_compare"
    chart_type: ChartType = "bar_h"
    dataset_id: str
    dimensions: List[DimensionSlot] = Field(default_factory=list)
    series_dimension: Optional[str] = None
    measures: List[MeasureSlot] = Field(default_factory=list)
    filters: List[FilterClause] = Field(default_factory=list)
    period: Optional[PeriodSpec] = None
    compare: Literal["none", "prior_period", "prior_year", "target"] = "none"
    limit: int = Field(default=12, ge=1, le=5000)
    bins: int = Field(default=10, ge=3, le=40)
    what_if: Optional[WhatIfSpec] = None
    title: Optional[str] = None
    subtitle: Optional[str] = None
    format: Optional[Dict[str, Any]] = None
