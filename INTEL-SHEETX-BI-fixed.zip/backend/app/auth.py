"""
Authentication & Multi-Tenant Object Authorization (Chapter 33.1 & Phase 1).
- PBKDF2-HMAC-SHA256 cryptographic password hashing (210,000 iterations).
- Session token hashed with SHA-256 at rest; accepted via HttpOnly cookie or Bearer header.
- Object-level authorization returning HTTP 404 (never 403) when out of scope.
"""
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional
from fastapi import Cookie, Header, HTTPException
from .db import get_conn, new_id, now_iso

ROLE_RANK = {"viewer": 1, "editor": 2, "owner": 3}


def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 210_000)
    return f"pbkdf2_sha256$210000${salt}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters_s, salt, hex_dk = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), int(iters_s))
        return hmac.compare_digest(dk.hex(), hex_dk)
    except Exception:
        return False


def hash_session_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()


def create_session(conn, user_id: str, days: int = 14) -> str:
    raw = secrets.token_urlsafe(32)
    th = hash_session_token(raw)
    exp = (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()
    conn.execute(
        "INSERT INTO sessions (token_hash, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)",
        (th, user_id, exp, now_iso()),
    )
    return raw


def get_current_user(
    authorization: Optional[str] = Header(default=None),
    sx_session: Optional[str] = Cookie(default=None),
) -> dict:
    raw_token = None
    if authorization and authorization.lower().startswith("bearer "):
        raw_token = authorization.split(" ", 1)[1].strip()
    elif sx_session:
        raw_token = sx_session.strip()

    if not raw_token:
        raise HTTPException(status_code=401, detail="Authentication required. Please sign in.")

    th = hash_session_token(raw_token)
    with get_conn() as conn:
        row = conn.execute(
            """SELECT u.id, u.email, u.name, s.expires_at
               FROM sessions s JOIN users u ON u.id = s.user_id
               WHERE s.token_hash = ?""",
            (th,),
        ).fetchone()
        if not row:
            raise HTTPException(status_code=401, detail="Invalid or expired session.")
        if row["expires_at"] < now_iso():
            conn.execute("DELETE FROM sessions WHERE token_hash = ?", (th,))
            raise HTTPException(status_code=401, detail="Session has expired. Please sign in again.")
        return {"id": row["id"], "email": row["email"], "name": row["name"], "token_hash": th}


def require_project_access(conn, user_id: str, project_id: str, min_role: str = "viewer") -> dict:
    """
    Loads a project ONLY if user_id is a member of its workspace with at least min_role.
    Returns 404 (never 403) if missing or unauthorised so existence is never leaked.
    """
    row = conn.execute(
        """SELECT p.*, wm.role AS member_role
           FROM projects p
           JOIN workspace_members wm ON wm.workspace_id = p.workspace_id
           WHERE p.id = ? AND wm.user_id = ?""",
        (project_id, user_id),
    ).fetchone()
    if not row or ROLE_RANK.get(row["member_role"], 0) < ROLE_RANK.get(min_role, 1):
        raise HTTPException(status_code=404, detail="Resource not found.")
    return dict(row)


def require_dataset_access(conn, user_id: str, dataset_id: str, min_role: str = "viewer") -> dict:
    row = conn.execute(
        """SELECT d.*, p.workspace_id, wm.role AS member_role
           FROM datasets d
           JOIN projects p ON p.id = d.project_id
           JOIN workspace_members wm ON wm.workspace_id = p.workspace_id
           WHERE d.id = ? AND d.deleted_at IS NULL AND wm.user_id = ?""",
        (dataset_id, user_id),
    ).fetchone()
    if not row or ROLE_RANK.get(row["member_role"], 0) < ROLE_RANK.get(min_role, 1):
        raise HTTPException(status_code=404, detail="Dataset not found.")
    return dict(row)


def require_dashboard_access(conn, user_id: str, dashboard_id: str, min_role: str = "viewer") -> dict:
    row = conn.execute(
        """SELECT db.*, p.workspace_id, wm.role AS member_role
           FROM dashboards db
           JOIN projects p ON p.id = db.project_id
           JOIN workspace_members wm ON wm.workspace_id = p.workspace_id
           WHERE db.id = ? AND wm.user_id = ?""",
        (dashboard_id, user_id),
    ).fetchone()
    if not row or ROLE_RANK.get(row["member_role"], 0) < ROLE_RANK.get(min_role, 1):
        raise HTTPException(status_code=404, detail="Dashboard not found.")
    return dict(row)
