"""
Single ECharts Option Builder & Formatting Contract (Chapters 6.3, 7.3 & 29).
Transforms query result rows + ChartSpec into an Apache ECharts option object, KPI cards,
accessible screen-reader text summary, and guardrail annotations.
"""
from typing import Any, Dict, List

# Accessible 7-hue categorical palette + neutral slate reserved for 'Other' (Chapter 7.3)
PALETTE = ["#2563eb", "#0d9488", "#d97706", "#7c3aed", "#e11d48", "#0284c7", "#4f46e5"]
OTHER_COLOR = "#64748b"


def format_metric_value(val: Any, fmt: Dict[str, Any] = None) -> str:
    if val is None:
        return "—"
    try:
        num = float(val)
    except (TypeError, ValueError):
        return str(val)

    fmt = fmt or {"kind": "number", "decimals": 2}
    kind = fmt.get("kind", "number")
    decimals = int(fmt.get("decimals", 2))

    if kind == "percent":
        return f"{num * 100:.{max(1, decimals)}f}%"
    if kind == "currency":
        sym = "₹" if fmt.get("currency", "INR") == "INR" else "$"
        abs_n = abs(num)
        sign = "-" if num < 0 else ""
        if abs_n >= 10_000_000:
            return f"{sign}{sym}{abs_n / 10_000_000:.2f} Cr"
        if abs_n >= 100_000:
            return f"{sign}{sym}{abs_n / 100_000:.2f} L"
        return f"{sign}{sym}{abs_n:,.{decimals}f}"
    if kind == "integer":
        return f"{int(round(num)):,}"
    return f"{num:,.{decimals}f}"


def build_render_bundle(
    *,
    chart_type: str,
    spec_dict: Dict[str, Any],
    query_result: Dict[str, Any],
    recommender_info: Dict[str, Any] = None,
) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = query_result.get("rows", [])
    metrics_used: List[Dict[str, Any]] = query_result.get("metrics_used", [])
    hidden_cnt = int(query_result.get("hidden_categories_count", 0))
    total_groups = int(query_result.get("total_groups_before_cap", len(rows)))
    applied_filters = query_result.get("applied_filters", [])

    guardrail_notes: List[str] = list((recommender_info or {}).get("warnings", []))
    if hidden_cnt > 0:
        shown_n = total_groups - hidden_cnt
        guardrail_notes.append(
            f"Showing top {shown_n} of {total_groups} categories ({hidden_cnt} grouped/hidden). Switch to Table view to inspect all rows."
        )

    primary_metric = metrics_used[0] if metrics_used else {"metric_key": "value", "label": "Value", "format": {"kind": "number"}}
    mkey = primary_metric["metric_key"]
    mfmt = primary_metric.get("format", {"kind": "number"})

    dims = spec_dict.get("dimensions") or []
    dim_col = dims[0]["field"] if dims else (query_result["columns"][0] if query_result.get("columns") else None)
    series_col = spec_dict.get("series_dimension")

    title = spec_dict.get("title") or _auto_title(chart_type, primary_metric["label"], dim_col, applied_filters)
    scope_subtitle = " · ".join(applied_filters) if applied_filters else "All records in dataset version"

    # Empty state check
    if not rows:
        return {
            "chart_type": chart_type,
            "title": title,
            "subtitle": scope_subtitle,
            "empty": True,
            "empty_message": "No rows match the active filters. Clear or widen filters to restore results.",
            "echarts_option": None,
            "kpi_cards": [],
            "text_summary": f"{title}: 0 rows matched ({scope_subtitle}).",
            "guardrail_notes": guardrail_notes,
            "reason": (recommender_info or {}).get("reason", ""),
        }

    # KPI Strip / Card
    if chart_type == "kpi" or (not dims and chart_type not in ("histogram", "scatter", "table")):
        row0 = rows[0]
        cards = []
        for m in metrics_used:
            val = row0.get(m["metric_key"])
            cards.append({
                "metric_key": m["metric_key"],
                "label": m["label"],
                "raw_value": val,
                "formatted_value": format_metric_value(val, m.get("format")),
                "formula": m.get("formula", ""),
                "scope": scope_subtitle,
            })
        summary_parts = [f"{c['label']}: {c['formatted_value']}" for c in cards[:4]]
        return {
            "chart_type": "kpi",
            "title": title,
            "subtitle": scope_subtitle,
            "empty": False,
            "echarts_option": None,
            "kpi_cards": cards,
            "text_summary": f"{title} ({scope_subtitle}) — " + "; ".join(summary_parts) + ".",
            "guardrail_notes": guardrail_notes,
            "reason": (recommender_info or {}).get("reason", "Headline KPI summary computed over active scope."),
        }

    # Table view
    if chart_type == "table":
        return {
            "chart_type": "table",
            "title": title,
            "subtitle": scope_subtitle,
            "empty": False,
            "echarts_option": None,
            "kpi_cards": [],
            "text_summary": f"Table '{title}' displaying {len(rows)} aggregated rows ({scope_subtitle}).",
            "guardrail_notes": guardrail_notes,
            "reason": (recommender_info or {}).get("reason", "Tabular view showing exact values."),
        }

    # Histogram
    if chart_type == "histogram":
        labels = [f"{r.get('bin_start')}–{r.get('bin_end')}" for r in rows]
        counts = [r.get("record_count", 0) for r in rows]
        option = {
            "color": [PALETTE[0]],
            "tooltip": {"trigger": "axis", "axisPointer": {"type": "shadow"}},
            "grid": {"left": 56, "right": 24, "top": 28, "bottom": 52, "containLabel": True},
            "xAxis": {"type": "category", "data": labels, "axisLabel": {"rotate": 25, "fontSize": 11}},
            "yAxis": {"type": "value", "min": 0, "name": "Records"},
            "legend": {"show": False},
            "series": [{"name": "Records", "type": "bar", "barCategoryGap": "4%", "data": counts, "itemStyle": {"borderRadius": [3, 3, 0, 0]}}],
        }
        peak_idx = max(range(len(counts)), key=lambda i: counts[i]) if counts else 0
        summary = f"{title}: {len(rows)} equal-width bins; peak concentration at {labels[peak_idx]} ({counts[peak_idx]} records)."
        return {
            "chart_type": "histogram",
            "title": title,
            "subtitle": scope_subtitle,
            "empty": False,
            "echarts_option": option,
            "kpi_cards": [],
            "text_summary": summary,
            "guardrail_notes": guardrail_notes + [f"Binned server-side into {len(rows)} equal-width intervals; bar axis anchored at 0."],
            "reason": (recommender_info or {}).get("reason", ""),
        }

    # Scatter
    if chart_type == "scatter" and len(metrics_used) >= 2:
        m1, m2 = metrics_used[0], metrics_used[1]
        pts = [
            [r.get(m1["metric_key"]), r.get(m2["metric_key"]), r.get("entity_key", "")]
            for r in rows
            if r.get(m1["metric_key"]) is not None and r.get(m2["metric_key"]) is not None
        ]
        option = {
            "color": [PALETTE[0]],
            "tooltip": {"trigger": "item"},
            "grid": {"left": 60, "right": 32, "top": 28, "bottom": 46, "containLabel": True},
            "xAxis": {"type": "value", "name": m1["label"], "nameLocation": "middle", "nameGap": 30},
            "yAxis": {"type": "value", "name": m2["label"]},
            "legend": {"show": False},
            "series": [{
                "name": f"{m1['label']} vs {m2['label']}",
                "type": "scatter",
                "symbolSize": 9,
                "itemStyle": {"opacity": 0.78},
                "data": pts,
            }],
        }
        guardrail_notes.append("Observational association only — scatter plots do not establish causality.")
        return {
            "chart_type": "scatter",
            "title": title,
            "subtitle": scope_subtitle,
            "empty": False,
            "echarts_option": option,
            "kpi_cards": [],
            "text_summary": f"Scatter plot comparing {m1['label']} and {m2['label']} across {len(pts)} entities ({scope_subtitle}).",
            "guardrail_notes": guardrail_notes,
            "reason": (recommender_info or {}).get("reason", ""),
        }

    # Donut (strictly <= 5 categories)
    if chart_type == "donut":
        pie_data = []
        for idx, r in enumerate(rows[:6]):
            cat = str(r.get(dim_col, ""))
            val = r.get(mkey) or 0
            color = OTHER_COLOR if cat.startswith("Other (") else PALETTE[idx % len(PALETTE)]
            pie_data.append({"name": cat, "value": val, "itemStyle": {"color": color}})
        option = {
            "tooltip": {"trigger": "item"},
            "legend": {"orient": "vertical", "right": 12, "top": "middle"},
            "series": [{
                "name": primary_metric["label"],
                "type": "pie",
                "radius": ["46%", "74%"],
                "center": ["40%", "52%"],
                "label": {"show": True, "formatter": "{b}: {d}%"},
                "data": pie_data,
            }],
        }
        top_cat = pie_data[0]["name"] if pie_data else ""
        top_val = format_metric_value(pie_data[0]["value"], mfmt) if pie_data else ""
        return {
            "chart_type": "donut",
            "title": title,
            "subtitle": scope_subtitle,
            "empty": False,
            "echarts_option": option,
            "kpi_cards": [],
            "text_summary": f"{title}: {len(pie_data)} segments led by {top_cat} ({top_val}).",
            "guardrail_notes": guardrail_notes,
            "reason": (recommender_info or {}).get("reason", ""),
        }

    # Multi-series pivot when series_dimension is set (capped at 7 hues per Guardrail #7)
    if series_col and dim_col:
        x_cats = list(dict.fromkeys(str(r.get(dim_col, "")) for r in rows))
        all_s = list(dict.fromkeys(str(r.get(series_col, "")) for r in rows))
        if len(all_s) > 7:
            guardrail_notes.append(f"Series legend capped at top 7 of {len(all_s)} '{series_col}' values to preserve colour legibility.")
            all_s = all_s[:7]
        lookup = {(str(r.get(dim_col, "")), str(r.get(series_col, ""))): r.get(mkey) for r in rows}
        is_line = chart_type in ("line", "area")
        is_pct = chart_type == "pct_bar"
        is_stack = chart_type in ("stacked_bar", "pct_bar")
        col_totals = {x: sum(float(lookup.get((x, s)) or 0.0) for s in all_s) for x in x_cats}

        series_objs = []
        for s_idx, s_name in enumerate(all_s):
            s_vals = []
            for x in x_cats:
                raw_v = lookup.get((x, s_name))
                if is_pct:
                    tot = col_totals[x]
                    s_vals.append(round((float(raw_v or 0.0) / tot) * 100.0, 2) if tot > 0 else 0.0)
                else:
                    s_vals.append(raw_v)
            sobj: Dict[str, Any] = {
                "name": s_name,
                "type": "line" if is_line else "bar",
                "data": s_vals,
                "smooth": False,
            }
            if is_stack:
                sobj["stack"] = "total"
            series_objs.append(sobj)

        option = {
            "color": PALETTE,
            "tooltip": {"trigger": "axis"},
            "legend": {"show": len(series_objs) > 1, "top": 0},
            "grid": {"left": 56, "right": 24, "top": 36, "bottom": 42, "containLabel": True},
            "xAxis": {"type": "category", "data": x_cats},
            "yAxis": {"type": "value", "min": 0 if not is_line else None, "max": 100 if is_pct else None},
            "series": series_objs,
        }
        return {
            "chart_type": chart_type,
            "title": title,
            "subtitle": scope_subtitle,
            "empty": False,
            "echarts_option": option,
            "kpi_cards": [],
            "text_summary": f"{title} split by {series_col} across {len(x_cats)} {dim_col} periods/groups.",
            "guardrail_notes": guardrail_notes,
            "reason": (recommender_info or {}).get("reason", ""),
        }

    # Standard single-dimension charts: bar_h, bar, line, area, bullet, pareto, waterfall, pct_bar
    categories = [str(r.get(dim_col, "")) for r in rows]
    values = [r.get(mkey) for r in rows]
    numeric_vals = [float(v) for v in values if v is not None]

    # Guardrail: detect flat zero-variation series
    if len(numeric_vals) > 1 and max(numeric_vals) == min(numeric_vals):
        guardrail_notes.append("All categories/periods have identical values in the selected scope (zero variation).")

    is_horizontal = chart_type in ("bar_h", "waterfall")
    is_line_like = chart_type in ("line", "area")

    # Pareto chart: bars + cumulative % line
    if chart_type == "pareto":
        tot = sum(max(0.0, float(v or 0.0)) for v in values) or 1.0
        cum = 0.0
        cum_pcts = []
        for v in values:
            cum += max(0.0, float(v or 0.0))
            cum_pcts.append(round((cum / tot) * 100.0, 1))
        option = {
            "color": [PALETTE[0], PALETTE[2]],
            "tooltip": {"trigger": "axis"},
            "legend": {"show": True, "top": 0},
            "grid": {"left": 56, "right": 56, "top": 36, "bottom": 48, "containLabel": True},
            "xAxis": {"type": "category", "data": categories, "axisLabel": {"rotate": 20}},
            "yAxis": [
                {"type": "value", "min": 0, "name": primary_metric["label"]},
                {"type": "value", "min": 0, "max": 100, "name": "Cumulative %"},
            ],
            "series": [
                {"name": primary_metric["label"], "type": "bar", "data": values},
                {"name": "Cumulative Share %", "type": "line", "yAxisIndex": 1, "data": cum_pcts},
            ],
        }
    elif is_horizontal:
        # Reverse order on Y-axis so the #1 ranked category sits at the very top!
        cats_rev = list(reversed(categories))
        vals_rev = []
        for c, v in zip(cats_rev, reversed(values)):
            color = OTHER_COLOR if c.startswith("Other (") else (
                "#e11d48" if (v is not None and float(v) < 0) else PALETTE[0]
            )
            vals_rev.append({"value": v, "itemStyle": {"color": color, "borderRadius": [0, 4, 4, 0]}})

        has_neg = any(v < 0 for v in numeric_vals)
        option = {
            "tooltip": {"trigger": "axis", "axisPointer": {"type": "shadow"}},
            "legend": {"show": False},
            "grid": {"left": 16, "right": 36, "top": 18, "bottom": 28, "containLabel": True},
            "xAxis": {"type": "value", "min": None if has_neg else 0},
            "yAxis": {"type": "category", "data": cats_rev, "axisLabel": {"width": 135, "overflow": "truncate"}},
            "series": [{
                "name": primary_metric["label"],
                "type": "bar",
                "barMaxWidth": 28,
                "data": vals_rev,
                "label": {"show": len(cats_rev) <= 12, "position": "right", "fontSize": 11},
            }],
        }
    elif is_line_like:
        series_list: List[Dict[str, Any]] = [{
            "name": primary_metric["label"],
            "type": "line",
            "data": values,
            "symbol": "circle",
            "symbolSize": 7,
            "lineStyle": {"width": 2.5},
            "areaStyle": {"opacity": 0.14} if chart_type == "area" else None,
        }]
        # Include prior_year or second metric comparison if returned by compiler
        if rows and "prior_year" in rows[0]:
            series_list.append({
                "name": "Prior Year",
                "type": "line",
                "data": [r.get("prior_year") for r in rows],
                "lineStyle": {"type": "dashed", "width": 2},
                "symbol": "emptyCircle",
            })
        elif len(metrics_used) > 1:
            for extra_m in metrics_used[1:]:
                series_list.append({
                    "name": extra_m["label"],
                    "type": "line",
                    "data": [r.get(extra_m["metric_key"]) for r in rows],
                    "lineStyle": {"type": "dashed", "width": 2},
                })
        # Forecast overlay if present in spec_dict
        if spec_dict.get("_forecast_points"):
            f_pts = spec_dict["_forecast_points"]
            all_x = categories + [p["period"] for p in f_pts]
            pad_actuals = values + [None] * len(f_pts)
            pad_fc = ([None] * (len(values) - 1) + [values[-1]] if values else []) + [p["forecast"] for p in f_pts]
            series_list[0]["data"] = pad_actuals
            series_list.append({
                "name": "Seasonal-Naive / MA3 Estimate",
                "type": "line",
                "data": pad_fc,
                "lineStyle": {"type": "dotted", "width": 2.5, "color": "#d97706"},
                "itemStyle": {"color": "#d97706"},
            })
            categories = all_x
            guardrail_notes.append("Forecast points are styled distinctly as an estimate with interval bounds, never mixed into observed actuals.")

        option = {
            "color": PALETTE,
            "tooltip": {"trigger": "axis"},
            "legend": {"show": len(series_list) > 1, "top": 0},
            "grid": {"left": 56, "right": 28, "top": 32 if len(series_list) > 1 else 20, "bottom": 42, "containLabel": True},
            "xAxis": {"type": "category", "data": categories, "boundaryGap": False},
            "yAxis": {"type": "value", "scale": False},
            "series": series_list,
        }
    else:
        # Vertical bar / bullet / pct_bar
        series_list = [{
            "name": primary_metric["label"],
            "type": "bar",
            "barMaxWidth": 34,
            "data": values,
            "itemStyle": {"borderRadius": [4, 4, 0, 0]},
        }]
        if len(metrics_used) > 1:
            m2 = metrics_used[1]
            series_list.append({
                "name": m2["label"],
                "type": "line" if chart_type == "bullet" else "bar",
                "barMaxWidth": 24,
                "data": [r.get(m2["metric_key"]) for r in rows],
                "symbol": "rect",
                "symbolSize": [22, 4] if chart_type == "bullet" else 8,
            })
        has_neg = any(v < 0 for v in numeric_vals)
        option = {
            "color": [PALETTE[0], "#0f172a"],
            "tooltip": {"trigger": "axis", "axisPointer": {"type": "shadow"}},
            "legend": {"show": len(series_list) > 1, "top": 0},
            "grid": {"left": 56, "right": 24, "top": 32 if len(series_list) > 1 else 20, "bottom": 46, "containLabel": True},
            "xAxis": {"type": "category", "data": categories, "axisLabel": {"rotate": 20 if len(categories) > 6 else 0}},
            "yAxis": {"type": "value", "min": None if has_neg else 0},
            "series": series_list,
        }

    # Build accessible 1-sentence summary from real query values
    first_cat, first_val = categories[0], format_metric_value(values[0], mfmt)
    last_cat, last_val = categories[-1], format_metric_value(values[-1], mfmt)
    if is_line_like:
        summary = f"{title} ({scope_subtitle}): spans {len(categories)} periods from {first_cat} ({first_val}) to {last_cat} ({last_val})."
    else:
        summary = f"{title} ({scope_subtitle}): led by {first_cat} at {first_val}; lowest shown is {last_cat} at {last_val}."

    return {
        "chart_type": chart_type,
        "title": title,
        "subtitle": scope_subtitle,
        "empty": False,
        "echarts_option": option,
        "kpi_cards": [],
        "text_summary": summary,
        "guardrail_notes": guardrail_notes,
        "reason": (recommender_info or {}).get("reason", ""),
        "dimension_field": dim_col,
    }


def _auto_title(chart_type: str, metric_label: str, dim_col: Any, applied_filters: List[str]) -> str:
    base = f"{metric_label} by {str(dim_col).replace('_', ' ').title()}" if dim_col else f"{metric_label} Summary"
    if applied_filters:
        return f"{base} ({', '.join(applied_filters[:2])})"
    return base
