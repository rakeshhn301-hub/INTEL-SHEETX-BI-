"""
The Chart Recommender & Visual Guardrail Engine (Chapters 6, 19 & Appendix C).
Consumes charts/matrix.json and scores valid chart types using:
  score = 0.45 * intent_affinity + 0.25 * encoding_accuracy + 0.20 * cardinality_fit + 0.10 * readability
"""
import json
import os
from typing import Any, Dict, List, Optional

MATRIX_PATH = os.path.join(os.path.dirname(__file__), "matrix.json")
with open(MATRIX_PATH, "r", encoding="utf-8") as _f:
    CHART_MATRIX: List[Dict[str, Any]] = json.load(_f)

ENCODING_ACCURACY = {
    "bar_h": 1.00,
    "bar": 0.96,
    "line": 0.98,
    "bullet": 0.94,
    "scatter": 0.90,
    "histogram": 0.90,
    "pareto": 0.88,
    "waterfall": 0.86,
    "area": 0.82,
    "stacked_bar": 0.76,
    "pct_bar": 0.78,
    "kpi": 0.92,
    "table": 0.85,
    "heatmap": 0.68,
    "donut": 0.58,
}

ALL_CHARTS = list(ENCODING_ACCURACY.keys())


def recommend_charts(
    *,
    intent: str,
    has_date: bool,
    distinct_categories: int,
    has_negative_values: bool,
    row_count: int,
    measure_count: int = 1,
    has_target: bool = False,
    requested_override: Optional[str] = None,
) -> Dict[str, Any]:
    matrix_row = next((m for m in CHART_MATRIX if m["intent"] == intent), CHART_MATRIX[0])
    best_type = matrix_row["best"]
    alt_types = matrix_row.get("alt", [])

    candidates: List[Dict[str, Any]] = []
    warnings: List[str] = []
    override_refusal: Optional[str] = None

    for ctype in ALL_CHARTS:
        # Hard filters (Chapter 19.1)
        if ctype in ("line", "area") and not has_date and ctype != requested_override:
            continue
        if ctype == "donut" and distinct_categories > 5:
            if requested_override == "donut":
                override_refusal = (
                    f"A donut/pie chart was requested, but {distinct_categories} categories exceed the 5-slice readability limit. "
                    f"Showing a sorted horizontal bar instead; donuts work well up to 5 slices."
                )
            continue
        if ctype in ("donut", "pct_bar", "stacked_bar") and has_negative_values:
            if requested_override == ctype:
                override_refusal = (
                    f"'{ctype}' cannot represent negative values accurately. Falling back to a zero-anchored bar chart."
                )
            continue
        if ctype in ("stacked_bar", "pct_bar") and distinct_categories > 40:
            continue
        if ctype == "scatter" and measure_count < 2:
            continue
        if ctype == "histogram" and row_count < 30:
            if requested_override == "histogram":
                override_refusal = f"There are {row_count} rows, which is below the 30-row minimum for a reliable histogram. Showing a table instead."
            continue
        if ctype == "bullet" and not has_target and measure_count < 2:
            continue
        if distinct_categories == 1 and ctype not in ("kpi", "table"):
            warnings.append("Selected dimension has only 1 distinct value; a KPI summary or table is clearer than a grouped axis.")
            if ctype != requested_override:
                continue

        # Weighted scoring
        if ctype == best_type:
            affinity = 1.0
        elif ctype in alt_types:
            affinity = 0.78 - (0.06 * alt_types.index(ctype))
        else:
            affinity = 0.25

        enc = ENCODING_ACCURACY.get(ctype, 0.7)

        if distinct_categories == 0:
            card_fit = 1.0 if ctype in ("kpi", "histogram", "scatter") else 0.4
        elif distinct_categories <= 5:
            card_fit = 0.95 if ctype in ("bar_h", "bar", "donut", "pct_bar", "bullet") else 0.75
        elif distinct_categories <= 15:
            card_fit = 1.0 if ctype in ("bar_h", "line", "pareto", "waterfall", "bullet") else 0.65
        elif distinct_categories <= 40:
            card_fit = 0.95 if ctype in ("bar_h", "line", "table", "bullet") else 0.45
        else:
            card_fit = 0.95 if ctype in ("table", "bar_h", "line") else 0.30

        readability = 0.95 if ctype in ("bar_h", "line", "kpi", "table", "bullet") else 0.80
        score = round(0.45 * affinity + 0.25 * enc + 0.20 * card_fit + 0.10 * readability, 4)

        reason = _build_reason(ctype, intent, distinct_categories)
        candidates.append({
            "chart_type": ctype,
            "score": score,
            "reason": reason,
        })

    candidates.sort(key=lambda c: -c["score"])
    if not candidates:
        candidates = [{"chart_type": "table", "score": 0.80, "reason": "Tabular view preserves exact values when visual constraints exclude grouped charts."}]

    chosen = candidates[0]
    if requested_override and not override_refusal:
        match_ov = next((c for c in candidates if c["chart_type"] == requested_override), None)
        if match_ov:
            chosen = {
                "chart_type": requested_override,
                "score": match_ov["score"],
                "reason": f"User explicitly requested '{requested_override}' chart override ({match_ov['reason']}).",
            }
        elif requested_override in ALL_CHARTS:
            chosen = {
                "chart_type": requested_override,
                "score": 0.70,
                "reason": f"User explicitly requested '{requested_override}' chart override.",
            }

    if override_refusal:
        warnings.insert(0, override_refusal)

    return {
        "selected": chosen["chart_type"],
        "reason": override_refusal or chosen["reason"],
        "warnings": warnings,
        "candidates": candidates[:6],
    }


def _build_reason(chart_type: str, intent: str, distinct_categories: int) -> str:
    if chart_type == "bar_h":
        return (
            f"Horizontal bar chart, sorted descending with a zero baseline, because comparing {max(distinct_categories, 2)} categories "
            f"along a common axis gives the highest visual comparison accuracy."
        )
    if chart_type == "line":
        return "Continuous line chart ordered chronologically along the X-axis to reveal trend direction, inflection points, and seasonality."
    if chart_type == "donut":
        return f"Donut chart permitted because there are only {distinct_categories} non-negative segments (<= 5 guardrail)."
    if chart_type == "pct_bar":
        return "100% normalized bar chart showing exact part-to-whole composition on a linear scale."
    if chart_type == "scatter":
        return "Scatter plot encoding two measures on X and Y at shared grain to inspect association (never implying causation)."
    if chart_type == "histogram":
        return "Server-binned histogram showing value spread and skewness across equal-width intervals."
    if chart_type == "bullet":
        return "Bullet/variance comparison contrasting actual performance directly against target benchmark."
    if chart_type == "waterfall":
        return "Ranked contributor variance chart isolating which segments drove the net movement."
    if chart_type == "kpi":
        return "Headline KPI strip surfacing top-line scope metrics before detailed breakdowns."
    return f"'{chart_type}' selected for intent {intent} based on schema cardinality and encoding accuracy."
