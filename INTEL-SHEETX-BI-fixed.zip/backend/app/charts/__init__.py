"""Chart recommender, guardrails, and ECharts option builder."""
