"""
Domain helper services connecting metadata DB, Parquet ingestion, profiling, and metrics.
"""
import json
import os
from typing import Any, Dict, List, Optional
import duckdb
from .data_plane.ingest import ingest_file_bytes
from .data_plane.profiler import profile_parquet
from .db import log_audit, new_id, now_iso
from .model.metrics import resolve_metrics_for_dataset, seed_project_metrics
from .query.compiler import clear_dataset_cache


def persist_ingested_dataset(
    conn,
    *,
    project_id: str,
    workspace_id: str,
    user_id: str,
    filename: str,
    raw_bytes: bytes,
    dataset_id: Optional[str] = None,
    sheet_name: Optional[str] = None,
) -> Dict[str, Any]:
    is_new = dataset_id is None
    if is_new:
        ds_id = new_id("ds")
        version = 1
    else:
        row = conn.execute("SELECT id, current_version FROM datasets WHERE id = ? AND project_id = ?", (dataset_id, project_id)).fetchone()
        if not row:
            ds_id = new_id("ds")
            version = 1
            is_new = True
        else:
            ds_id = row["id"]
            version = int(row["current_version"]) + 1

    ingested = ingest_file_bytes(
        filename=filename,
        raw_bytes=raw_bytes,
        dataset_id=ds_id,
        version=version,
        sheet_name=sheet_name,
    )
    if ingested.get("requires_sheet_selection"):
        return ingested

    profile = profile_parquet(
        ingested["parquet_path"],
        date_parse_failures_by_col=ingested["date_parse_failures"],
    )

    ts = now_iso()
    display_name = f"{filename} ({ingested['sheet_name']})" if ingested.get("sheet_name") else filename

    if is_new:
        conn.execute(
            """INSERT INTO datasets
               (id, project_id, name, current_version, grain_description, created_by, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (ds_id, project_id, display_name, version, profile["grain_statement"], user_id, ts, ts),
        )
    else:
        conn.execute(
            "UPDATE datasets SET current_version = ?, grain_description = ?, updated_at = ? WHERE id = ?",
            (version, profile["grain_statement"], ts, ds_id),
        )
        clear_dataset_cache(ds_id)

    ver_id = new_id("dsv")
    conn.execute(
        """INSERT INTO dataset_versions
           (id, dataset_id, version, original_filename, sheet_name, content_hash, raw_path, parquet_path,
            row_count, column_count, byte_size, encoding, delimiter, schema_fingerprint,
            parse_report_json, profile_json, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            ver_id,
            ds_id,
            version,
            filename,
            ingested.get("sheet_name"),
            ingested["content_hash"],
            ingested["raw_path"],
            ingested["parquet_path"],
            ingested["row_count"],
            ingested["column_count"],
            ingested["byte_size"],
            ingested["encoding"],
            ingested["delimiter"],
            ingested["schema_fingerprint"],
            json.dumps(ingested["parse_report"]),
            json.dumps(profile),
            ts,
        ),
    )

    # Carry forward previous version overrides if refreshing an existing dataset
    prev_overrides: Dict[str, Dict[str, Any]] = {}
    if not is_new and version > 1:
        prev_rows = conn.execute(
            "SELECT * FROM field_metadata WHERE dataset_id = ? AND version = ? AND overridden_by IS NOT NULL",
            (ds_id, version - 1),
        ).fetchall()
        for pr in prev_rows:
            prev_overrides[pr["name"].lower()] = dict(pr)

    for idx, col in enumerate(profile["columns"]):
        ov = prev_overrides.get(col["name"].lower())
        role = ov["role"] if ov else col["role"]
        sem = ov["semantic_type"] if ov else col["semantic_type"]
        additive = ov["additive"] if ov else col["additive"]
        excl = int(ov["exclude_from_ai"]) if ov else (1 if col["exclude_from_ai"] else 0)
        reason = ov["reason"] if ov else col["reason"]
        ov_by = ov["overridden_by"] if ov else None
        ov_at = ov["overridden_at"] if ov else None

        conn.execute(
            """INSERT INTO field_metadata
               (id, dataset_id, version, name, safe_col, physical_type, semantic_type, role, default_agg,
                additive, unit, sensitive, exclude_from_ai, hidden, distinct_count, null_count, null_rate,
                stats_json, reason, overridden_by, overridden_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)""",
            (
                new_id("fld"),
                ds_id,
                version,
                col["name"],
                f"c_{idx}",
                col["physical_type"],
                sem,
                role,
                col["default_agg"],
                additive,
                col["unit"],
                1 if col["sensitive"] else 0,
                excl,
                col["distinct_count"],
                col["null_count"],
                col["null_rate"],
                json.dumps(col["stats"]),
                reason,
                ov_by,
                ov_at,
            ),
        )

    seed_project_metrics(conn, project_id)
    log_audit(
        conn,
        action="dataset_ingested" if is_new else "dataset_refreshed",
        object_type="dataset",
        object_id=ds_id,
        user_id=user_id,
        workspace_id=workspace_id,
        project_id=project_id,
        details={"filename": filename, "version": version, "row_count": ingested["row_count"]},
    )

    return {
        "requires_sheet_selection": False,
        "dataset_id": ds_id,
        "name": display_name,
        "version": version,
        "row_count": ingested["row_count"],
        "column_count": ingested["column_count"],
        "byte_size": ingested["byte_size"],
        "encoding": ingested["encoding"],
        "delimiter": ingested["delimiter"],
        "grain_statement": profile["grain_statement"],
        "parse_report": ingested["parse_report"],
        "quality_warnings": profile["quality_warnings"],
    }


def load_dataset_context(conn, dataset_id: str, version: Optional[int] = None) -> Dict[str, Any]:
    ds = conn.execute("SELECT * FROM datasets WHERE id = ? AND deleted_at IS NULL", (dataset_id,)).fetchone()
    if not ds:
        raise ValueError("Dataset not found.")
    ver = version if version is not None else int(ds["current_version"])
    dsv = conn.execute(
        "SELECT * FROM dataset_versions WHERE dataset_id = ? AND version = ?",
        (dataset_id, ver),
    ).fetchone()
    if not dsv:
        raise ValueError(f"Dataset version {ver} not found.")

    f_rows = conn.execute(
        "SELECT * FROM field_metadata WHERE dataset_id = ? AND version = ? ORDER BY rowid ASC",
        (dataset_id, ver),
    ).fetchall()
    fields = []
    for r in f_rows:
        d = dict(r)
        d["stats"] = json.loads(d["stats_json"]) if d.get("stats_json") else {}
        d["sensitive"] = bool(d["sensitive"])
        d["exclude_from_ai"] = bool(d["exclude_from_ai"])
        d["hidden"] = bool(d["hidden"])
        fields.append(d)

    m_rows = conn.execute(
        "SELECT * FROM metric_definitions WHERE project_id = ? ORDER BY is_builtin DESC, created_at ASC",
        (ds["project_id"],),
    ).fetchall()
    project_metrics = [dict(r) for r in m_rows]
    resolved_metrics = resolve_metrics_for_dataset(project_metrics, fields)

    return {
        "dataset": dict(ds),
        "version_row": dict(dsv),
        "parquet_path": dsv["parquet_path"],
        "profile": json.loads(dsv["profile_json"]),
        "parse_report": json.loads(dsv["parse_report_json"]),
        "fields": fields,
        "resolved_metrics": resolved_metrics,
    }


def read_parquet_preview(parquet_path: str, offset: int = 0, limit: int = 50) -> Dict[str, Any]:
    con = duckdb.connect(":memory:")
    try:
        p_esc = parquet_path.replace("'", "''")
        total = con.execute(f"SELECT COUNT(*) FROM read_parquet('{p_esc}')").fetchone()[0]
        cur = con.execute(f"SELECT * FROM read_parquet('{p_esc}') LIMIT ? OFFSET ?", [limit, offset])
        cols = [d[0] for d in cur.description]
        rows = [
            {cols[i]: (r[i].isoformat() if hasattr(r[i], "isoformat") else r[i]) for i in range(len(cols))}
            for r in cur.fetchall()
        ]
        return {"columns": cols, "rows": rows, "total_rows": int(total), "offset": offset, "limit": limit}
    finally:
        con.close()


def delete_dataset_artifacts(conn, dataset: Dict[str, Any], user_id: str) -> Dict[str, Any]:
    """
    Implements Chapter 33.4 Deletion & Tombstone:
    Removes Parquet files, unreferenced raw upload files, cached query results,
    dashboards/charts referencing the dataset, marks tombstone, and logs audit event.
    """
    ds_id = dataset["id"]
    versions = conn.execute("SELECT * FROM dataset_versions WHERE dataset_id = ?", (ds_id,)).fetchall()
    removed_files = []

    for v in versions:
        pp = v["parquet_path"]
        if pp and os.path.exists(pp):
            os.remove(pp)
            removed_files.append(pp)
        rp = v["raw_path"]
        if rp and os.path.exists(rp):
            other_refs = conn.execute(
                "SELECT COUNT(*) FROM dataset_versions WHERE content_hash = ? AND dataset_id != ?",
                (v["content_hash"], ds_id),
            ).fetchone()[0]
            if other_refs == 0:
                os.remove(rp)
                removed_files.append(rp)

    purged_cache = clear_dataset_cache(ds_id)
    conn.execute("DELETE FROM field_metadata WHERE dataset_id = ?", (ds_id,))
    conn.execute("DELETE FROM dataset_versions WHERE dataset_id = ?", (ds_id,))
    conn.execute("DELETE FROM charts WHERE dataset_id = ?", (ds_id,))
    conn.execute("DELETE FROM dashboards WHERE dataset_id = ?", (ds_id,))
    # Tombstone retained on datasets row + audit_log per Chapter 33.4
    ts = now_iso()
    conn.execute(
        "UPDATE datasets SET deleted_at = ?, name = '[DELETED TOMBSTONE]', updated_at = ? WHERE id = ?",
        (ts, ts, ds_id),
    )
    log_audit(
        conn,
        action="dataset_deleted_tombstone",
        object_type="dataset",
        object_id=ds_id,
        user_id=user_id,
        workspace_id=dataset.get("workspace_id"),
        project_id=dataset["project_id"],
        details={"removed_files_count": len(removed_files), "purged_cache_entries": purged_cache},
    )
    return {"deleted_dataset_id": ds_id, "removed_files_count": len(removed_files), "purged_cache_entries": purged_cache, "tombstone_at": ts}
