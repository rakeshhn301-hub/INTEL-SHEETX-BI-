"""
Relationship & Fan-Out Uniqueness Guard (Chapters 5.3 & 27.3).
Before any many-to-one relationship can be marked active/verified, verifies that the 'one' side
has zero duplicate keys so joins can never silently inflate SUMs.
"""
from typing import Any, Dict
import duckdb


def verify_one_side_uniqueness(parquet_path: str, key_field: str) -> Dict[str, Any]:
    con = duckdb.connect(":memory:")
    try:
        p_esc = parquet_path.replace("'", "''")
        qcol = f'"{key_field.replace(chr(34), chr(34)*2)}"'
        dupes = con.execute(
            f"""SELECT CAST({qcol} AS VARCHAR) AS k, COUNT(*) AS c
                FROM read_parquet('{p_esc}')
                WHERE {qcol} IS NOT NULL
                GROUP BY 1
                HAVING COUNT(*) > 1
                ORDER BY c DESC
                LIMIT 10"""
        ).fetchall()
        nulls = con.execute(
            f"SELECT COUNT(*) FROM read_parquet('{p_esc}') WHERE {qcol} IS NULL"
        ).fetchone()[0]

        if dupes:
            samples = ", ".join(f"{r[0]} (x{r[1]})" for r in dupes[:3])
            return {
                "verified_unique": False,
                "duplicate_key_count": len(dupes),
                "null_key_count": int(nulls),
                "message": (
                    f"Fan-out trap blocked: '{key_field}' on the dimension table is NOT unique "
                    f"(duplicate keys found: {samples}). Joining would multiply rows and inflate every SUM."
                ),
            }
        return {
            "verified_unique": True,
            "duplicate_key_count": 0,
            "null_key_count": int(nulls),
            "message": f"Verified unique key '{key_field}' (0 duplicate keys). Relationship is safe from join fan-out.",
        }
    finally:
        con.close()
