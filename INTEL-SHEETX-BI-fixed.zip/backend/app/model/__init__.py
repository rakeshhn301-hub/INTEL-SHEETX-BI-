"""Semantic model package: metrics registry, AST expression compiler, and relationship guards."""
