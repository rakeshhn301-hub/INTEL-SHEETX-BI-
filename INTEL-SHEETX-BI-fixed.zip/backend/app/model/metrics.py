"""
The 15 Governed Metrics Catalogue & Safe Expression AST Compiler (Chapters 27.2, 28.5 & Appendix B).
"""
import ast
import json
import re
from typing import Any, Dict, List, Optional
from ..db import new_id, now_iso

# Canonical 15 Metrics from Chapter 27.2 (Table 27.1) & Appendix B (Table B.1)
CORE_15_METRICS: List[Dict[str, Any]] = [
    {
        "metric_key": "total_sales",
        "label": "Total Sales",
        "description": "Sum of net sales/revenue over the selected scope.",
        "kind": "additive",
        "formula_display": "SUM(sales)",
        "spec": {"agg": "sum", "field_candidates": ["sales", "revenue", "net_sales", "amount", "total_sales"]},
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "currency", "currency": "INR", "decimals": 2},
        "synonyms": ["sales", "revenue", "turnover", "top line", "net sales", "rev"],
    },
    {
        "metric_key": "total_profit",
        "label": "Total Profit",
        "description": "Sum of profit over the selected scope (negatives preserved).",
        "kind": "additive",
        "formula_display": "SUM(profit)",
        "spec": {"agg": "sum", "field_candidates": ["profit", "net_profit", "margin_amount", "operating_profit"]},
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "currency", "currency": "INR", "decimals": 2},
        "synonyms": ["profit", "earnings", "bottom line", "net income", "gain"],
    },
    {
        "metric_key": "profit_margin",
        "label": "Profit Margin",
        "description": "Ratio of total profit to total sales over the selected scope. Never averages row-level margins.",
        "kind": "ratio",
        "formula_display": "SUM(profit) / NULLIF(SUM(sales), 0)",
        "spec": {
            "num": {"agg": "sum", "field_candidates": ["profit", "net_profit"]},
            "den": {"agg": "sum", "field_candidates": ["sales", "revenue", "net_sales", "amount"]},
        },
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "percent", "decimals": 1},
        "synonyms": ["margin", "profit margin", "net margin", "profitability", "margin %"],
    },
    {
        "metric_key": "order_count",
        "label": "Order Count",
        "description": "Distinct count of order identifiers (prevents double-counting multi-line orders).",
        "kind": "distinct",
        "formula_display": "COUNT(DISTINCT order_number)",
        "spec": {"agg": "count_distinct", "field_candidates": ["order_number", "order_id", "order_no", "invoice", "invoice_no"]},
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "integer", "decimals": 0},
        "synonyms": ["orders", "order count", "number of orders", "invoices", "transactions"],
    },
    {
        "metric_key": "customer_count",
        "label": "Customer Count",
        "description": "Distinct count of unique customer identifiers in scope.",
        "kind": "distinct",
        "formula_display": "COUNT(DISTINCT customer_id)",
        "spec": {"agg": "count_distinct", "field_candidates": ["customer_id", "client_id", "account_id", "buyer_id"]},
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "integer", "decimals": 0},
        "synonyms": ["customers", "customer count", "buyers", "unique customers", "clients"],
    },
    {
        "metric_key": "avg_order_value",
        "label": "Avg Order Value",
        "description": "Total sales divided by distinct order count (true per-order average, not per-line).",
        "kind": "ratio",
        "formula_display": "SUM(sales) / NULLIF(COUNT(DISTINCT order_number), 0)",
        "spec": {
            "num": {"agg": "sum", "field_candidates": ["sales", "revenue", "amount"]},
            "den": {"agg": "count_distinct", "field_candidates": ["order_number", "order_id", "order_no", "invoice"]},
        },
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "currency", "currency": "INR", "decimals": 2},
        "synonyms": ["aov", "average order value", "avg order value", "order size", "basket size"],
    },
    {
        "metric_key": "units_sold",
        "label": "Units Sold",
        "description": "Sum of unit quantities sold (negative quantities represent returns).",
        "kind": "additive",
        "formula_display": "SUM(units)",
        "spec": {"agg": "sum", "field_candidates": ["units", "quantity", "qty", "volume"]},
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "integer", "decimals": 0},
        "synonyms": ["units", "units sold", "quantity", "volume", "items"],
    },
    {
        "metric_key": "discount_rate",
        "label": "Discount Rate",
        "description": "Weighted discount rate: total discount amount divided by gross sales.",
        "kind": "ratio",
        "formula_display": "SUM(discount_amount) / NULLIF(SUM(gross_sales), 0)",
        "spec": {
            "num": {"agg": "sum", "field_candidates": ["discount_amount", "discount_value", "discount"]},
            "den": {"agg": "sum", "field_candidates": ["gross_sales", "list_sales", "sales"]},
        },
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "percent", "decimals": 1},
        "synonyms": ["discount", "discount rate", "discount %", "markdown rate"],
    },
    {
        "metric_key": "yoy_growth",
        "label": "YoY Sales Growth",
        "description": "Year-over-year relative change in sales vs. the equivalent prior-year window.",
        "kind": "window",
        "formula_display": "(SUM(sales) - prior_year_sales) / NULLIF(prior_year_sales, 0)",
        "spec": {
            "window_type": "yoy",
            "field_candidates": ["sales", "revenue", "amount"],
            "date_candidates": ["order_date", "date", "invoice_date", "created_at"],
        },
        "grain": "order_line + date",
        "null_policy": "ignore",
        "format": {"kind": "percent", "decimals": 1},
        "synonyms": ["yoy", "yoy growth", "year over year", "annual growth"],
    },
    {
        "metric_key": "sales_per_customer",
        "label": "Sales per Customer",
        "description": "Total sales divided by distinct active customers in the selected scope.",
        "kind": "ratio",
        "formula_display": "SUM(sales) / NULLIF(COUNT(DISTINCT customer_id), 0)",
        "spec": {
            "num": {"agg": "sum", "field_candidates": ["sales", "revenue", "amount"]},
            "den": {"agg": "count_distinct", "field_candidates": ["customer_id", "client_id", "account_id"]},
        },
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "currency", "currency": "INR", "decimals": 2},
        "synonyms": ["sales per customer", "arpu", "revenue per customer", "customer spend"],
    },
    {
        "metric_key": "return_rate",
        "label": "Return Rate",
        "description": "Returned units divided by total units sold over the selected scope.",
        "kind": "ratio",
        "formula_display": "SUM(returned_units) / NULLIF(SUM(units), 0)",
        "spec": {
            "num": {"agg": "sum", "field_candidates": ["returned_units", "returns", "refund_units"]},
            "den": {"agg": "sum", "field_candidates": ["units", "quantity", "qty"]},
        },
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "percent", "decimals": 2},
        "synonyms": ["return rate", "returns", "refund rate"],
    },
    {
        "metric_key": "active_customers",
        "label": "Active Customers (90d Window)",
        "description": "Distinct customers with at least one order inside the trailing 90-day window of the dataset.",
        "kind": "window",
        "formula_display": "COUNT(DISTINCT customer_id) FILTER (trailing 90d window)",
        "spec": {
            "window_type": "active_window_90d",
            "field_candidates": ["customer_id", "client_id"],
            "date_candidates": ["order_date", "date", "invoice_date"],
        },
        "grain": "order_line + date",
        "null_policy": "ignore",
        "format": {"kind": "integer", "decimals": 0},
        "synonyms": ["active customers", "90d active", "recent buyers"],
    },
    {
        "metric_key": "inventory_value",
        "label": "Inventory Value",
        "description": "Semi-additive stock value SUM(on_hand * unit_cost) evaluated at the latest snapshot date (never summed across time).",
        "kind": "semi_additive",
        "formula_display": "SUM(on_hand * unit_cost) AT LATEST DATE",
        "spec": {
            "qty_candidates": ["on_hand", "stock_qty", "inventory_units"],
            "cost_candidates": ["unit_cost", "cost_per_unit"],
            "date_candidates": ["order_date", "snapshot_date", "date"],
        },
        "grain": "snapshot",
        "null_policy": "ignore",
        "format": {"kind": "currency", "currency": "INR", "decimals": 2},
        "synonyms": ["inventory", "inventory value", "stock value", "on hand value"],
    },
    {
        "metric_key": "on_time_delivery_pct",
        "label": "On-Time Delivery %",
        "description": "Share of dated shipments delivered on time (excludes rows without a due date).",
        "kind": "ratio",
        "formula_display": "SUM(on_time_flag) / NULLIF(COUNT(due_date), 0)",
        "spec": {
            "num": {"agg": "sum", "field_candidates": ["on_time_flag", "on_time", "delivered_on_time"]},
            "den": {"agg": "count_non_null", "field_candidates": ["due_date", "promised_date", "on_time_flag"]},
        },
        "grain": "shipment",
        "null_policy": "ignore",
        "format": {"kind": "percent", "decimals": 1},
        "synonyms": ["on time delivery", "otd", "delivery rate", "sla %"],
    },
    {
        "metric_key": "contribution_margin",
        "label": "Contribution Margin",
        "description": "Sales minus variable costs divided by total sales over the selected scope.",
        "kind": "ratio",
        "formula_display": "(SUM(sales) - SUM(variable_cost)) / NULLIF(SUM(sales), 0)",
        "spec": {
            "expr_type": "diff_over_den",
            "sales_candidates": ["sales", "revenue", "net_sales"],
            "cost_candidates": ["variable_cost", "cost", "cogs"],
        },
        "grain": "order_line",
        "null_policy": "ignore",
        "format": {"kind": "percent", "decimals": 1},
        "synonyms": ["contribution margin", "contribution %", "gross margin", "cm %"],
    },
]


def seed_project_metrics(conn, project_id: str) -> None:
    """Seeds the 15 governed metrics for a newly created project (idempotent)."""
    ts = now_iso()
    for m in CORE_15_METRICS:
        existing = conn.execute(
            "SELECT id FROM metric_definitions WHERE project_id = ? AND metric_key = ?",
            (project_id, m["metric_key"]),
        ).fetchone()
        if existing:
            continue
        mid = new_id("met")
        spec_with_syn = dict(m["spec"])
        spec_with_syn["synonyms"] = m.get("synonyms", [])
        conn.execute(
            """INSERT INTO metric_definitions
               (id, project_id, metric_key, label, description, kind, formula_display, spec_json,
                grain, null_policy, format_json, current_version, is_builtin, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?)""",
            (
                mid,
                project_id,
                m["metric_key"],
                m["label"],
                m["description"],
                m["kind"],
                m["formula_display"],
                json.dumps(spec_with_syn),
                m["grain"],
                m["null_policy"],
                json.dumps(m["format"]),
                ts,
            ),
        )
        conn.execute(
            """INSERT INTO metric_versions (id, metric_def_id, version, spec_json, note, changed_by, created_at)
               VALUES (?, ?, 1, ?, 'Initial canonical v1 definition', 'system', ?)""",
            (new_id("mv"), mid, json.dumps(spec_with_syn), ts),
        )


def _match_col(candidates: List[str], fields_by_lower: Dict[str, dict]) -> Optional[dict]:
    for cand in candidates:
        if cand.lower() in fields_by_lower:
            return fields_by_lower[cand.lower()]
    # Substring fallback on word boundary ONLY if unambiguously matching a single column
    for cand in candidates:
        pat = re.compile(rf"(^|[_\s]){re.escape(cand.lower())}([_\s]|$)")
        matches = [fmeta for fname_l, fmeta in fields_by_lower.items() if pat.search(fname_l)]
        if len(matches) == 1:
            return matches[0]
    return None


def resolve_metrics_for_dataset(
    project_metrics: List[Dict[str, Any]],
    dataset_fields: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Binds each project metric definition against a specific dataset's field_metadata,
    marking whether it is executable on this dataset and adding dynamic field-backed metrics
    for custom numeric/identifier columns not already covered by the 15 builtins.
    """
    fields_by_lower = {f["name"].lower(): f for f in dataset_fields if not f.get("hidden")}
    covered_cols = set()
    resolved: List[Dict[str, Any]] = []

    for m in project_metrics:
        spec = json.loads(m["spec_json"]) if isinstance(m["spec_json"], str) else dict(m["spec_json"])
        fmt = json.loads(m["format_json"]) if isinstance(m["format_json"], str) else dict(m["format_json"])
        kind = m["kind"]
        bound: Dict[str, Any] = {}
        missing: List[str] = []

        if "custom_ast_sql" in spec:
            req_cols = spec.get("referenced_columns", [])
            for rc in req_cols:
                if rc.lower() not in fields_by_lower:
                    missing.append(rc)
            bound["custom_sql"] = spec["custom_ast_sql"]

        elif kind in ("additive", "distinct"):
            col = _match_col(spec.get("field_candidates", []), fields_by_lower)
            if not col:
                missing.append("/".join(spec.get("field_candidates", ["field"])[:2]))
            elif kind == "additive" and col["role"] == "identifier":
                missing.append(f"{col['name']} is an identifier and cannot be summed")
            else:
                bound["field"] = col["name"]
                covered_cols.add(col["name"].lower())

        elif kind == "ratio":
            if spec.get("expr_type") == "diff_over_den":
                scol = _match_col(spec.get("sales_candidates", []), fields_by_lower)
                ccol = _match_col(spec.get("cost_candidates", []), fields_by_lower)
                if not scol:
                    missing.append("sales")
                if not ccol:
                    missing.append("variable_cost")
                if scol and ccol:
                    bound["expr_type"] = "diff_over_den"
                    bound["sales_field"] = scol["name"]
                    bound["cost_field"] = ccol["name"]
                    covered_cols.update([scol["name"].lower(), ccol["name"].lower()])
            else:
                num_spec = spec.get("num", {})
                den_spec = spec.get("den", {})
                ncol = _match_col(num_spec.get("field_candidates", []), fields_by_lower)
                dcol = _match_col(den_spec.get("field_candidates", []), fields_by_lower)
                if not ncol:
                    missing.append("/".join(num_spec.get("field_candidates", ["numerator"])[:2]))
                if not dcol:
                    missing.append("/".join(den_spec.get("field_candidates", ["denominator"])[:2]))
                if ncol and dcol:
                    bound["num_agg"] = num_spec.get("agg", "sum")
                    bound["num_field"] = ncol["name"]
                    bound["den_agg"] = den_spec.get("agg", "sum")
                    bound["den_field"] = dcol["name"]
                    covered_cols.update([ncol["name"].lower(), dcol["name"].lower()])

        elif kind == "semi_additive":
            qcol = _match_col(spec.get("qty_candidates", []), fields_by_lower)
            ucol = _match_col(spec.get("cost_candidates", []), fields_by_lower)
            dcol = _match_col(spec.get("date_candidates", []), fields_by_lower)
            if not qcol:
                missing.append("on_hand")
            if not ucol:
                missing.append("unit_cost")
            if qcol and ucol:
                bound["qty_field"] = qcol["name"]
                bound["cost_field"] = ucol["name"]
                bound["date_field"] = dcol["name"] if dcol else None
                covered_cols.update([qcol["name"].lower(), ucol["name"].lower()])

        elif kind == "window":
            fcol = _match_col(spec.get("field_candidates", []), fields_by_lower)
            dcol = _match_col(spec.get("date_candidates", []), fields_by_lower)
            if not fcol:
                missing.append("/".join(spec.get("field_candidates", ["measure"])[:2]))
            if not dcol:
                missing.append("date column")
            if fcol and dcol:
                bound["window_type"] = spec.get("window_type", "yoy")
                bound["field"] = fcol["name"]
                bound["date_field"] = dcol["name"]

        resolved.append({
            "id": m["id"],
            "metric_key": m["metric_key"],
            "label": m["label"],
            "description": m["description"],
            "kind": kind,
            "formula_display": m["formula_display"],
            "grain": m["grain"],
            "null_policy": m["null_policy"],
            "format": fmt,
            "version": m["current_version"],
            "is_builtin": bool(m["is_builtin"]),
            "available": len(missing) == 0,
            "missing_requirements": missing,
            "bound": bound,
            "synonyms": spec.get("synonyms", []),
        })

    # Also auto-expose additive numeric columns in arbitrary user CSVs (e.g. target_sales, kwh, spend)
    for f in dataset_fields:
        fl = f["name"].lower()
        if fl in covered_cols or f.get("hidden"):
            continue
        if f["role"] == "measure" and f["additive"] == "additive":
            slug = re.sub(r"[^a-z0-9]+", "_", fl).strip("_")
            mkey = f"sum_{slug}"
            if any(r["metric_key"] == mkey for r in resolved):
                continue
            fmt_kind = "currency" if f["semantic_type"] == "currency" else "number"
            resolved.append({
                "id": f"auto_{mkey}",
                "metric_key": mkey,
                "label": f"Total {f['name'].replace('_', ' ').title()}",
                "description": f"Additive sum of '{f['name']}' over the selected scope.",
                "kind": "additive",
                "formula_display": f"SUM({f['name']})",
                "grain": "record",
                "null_policy": "ignore",
                "format": {"kind": fmt_kind, "currency": "INR", "decimals": 2 if fmt_kind == "currency" else 0},
                "version": 1,
                "is_builtin": False,
                "available": True,
                "missing_requirements": [],
                "bound": {"field": f["name"]},
                "synonyms": [fl, f["name"].replace("_", " ").lower()],
            })

    return resolved


# ---- Safe Expression Grammar Compiler (Chapter 28.5) ----
ALLOWED_FUNCS = {"sum", "count_distinct", "min", "max", "abs", "round", "nullif", "coalesce"}
FORBIDDEN_WORDS = re.compile(r"\b(select|from|where|drop|delete|insert|update|alter|copy|attach|pragma)\b", re.I)


def compile_safe_metric_expression(expr: str, dataset_fields: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Parses a bounded arithmetic/aggregate formula via Python's AST (zero SQL string concatenation)
    and verifies every column reference against field_metadata, blocking summing identifiers.
    Example: "round(sum(sales) / nullif(count_distinct(order_number), 0), 2)"
    """
    if ";" in expr or "--" in expr or "/*" in expr or FORBIDDEN_WORDS.search(expr):
        raise ValueError("Expression contains forbidden SQL tokens or comments.")

    fields_map = {f["name"].lower(): f for f in dataset_fields}
    referenced_cols: List[str] = []

    try:
        tree = ast.parse(expr.strip(), mode="eval")
    except SyntaxError as exc:
        raise ValueError(f"Invalid metric formula syntax: {exc.msg}") from exc

    def _emit(node: ast.AST) -> str:
        if isinstance(node, ast.Expression):
            return _emit(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return str(node.value)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            op_s = "+" if isinstance(node.op, ast.UAdd) else "-"
            return f"({op_s}{_emit(node.operand)})"
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)):
            left = _emit(node.left)
            right = _emit(node.right)
            if isinstance(node.op, ast.Div):
                return f"(CAST({left} AS DOUBLE) / NULLIF(CAST({right} AS DOUBLE), 0.0))"
            op_map = {ast.Add: "+", ast.Sub: "-", ast.Mult: "*"}
            return f"({left} {op_map[type(node.op)]} {right})"
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            fn = node.func.id.lower()
            if fn not in ALLOWED_FUNCS:
                raise ValueError(f"Function '{fn}' is not allowed. Allowed: {', '.join(sorted(ALLOWED_FUNCS))}.")
            if fn in ("sum", "min", "max", "count_distinct"):
                if len(node.args) != 1 or not isinstance(node.args[0], ast.Name):
                    raise ValueError(f"{fn}(...) must wrap a single column identifier.")
                cname_l = node.args[0].id.lower()
                if cname_l not in fields_map:
                    raise ValueError(f"Unknown column '{node.args[0].id}'.")
                fmeta = fields_map[cname_l]
                if fn == "sum" and fmeta["role"] == "identifier":
                    raise ValueError(f"Column '{fmeta['name']}' is an identifier and may never be summed.")
                if fn == "sum" and fmeta["additive"] == "non_additive":
                    raise ValueError(f"Column '{fmeta['name']}' is a non-additive ratio; compute from SUM components instead.")
                referenced_cols.append(fmeta["name"])
                qcol = f'"{fmeta["name"].replace(chr(34), chr(34)*2)}"'
                if fn == "count_distinct":
                    return f"COUNT(DISTINCT {qcol})"
                return f"{fn.upper()}({qcol})"
            args_sql = ", ".join(_emit(a) for a in node.args)
            return f"{fn.upper()}({args_sql})"
        raise ValueError(f"Unsupported expression construct '{type(node).__name__}'.")

    sql_expr = _emit(tree)
    return {"sql_expr": sql_expr, "referenced_columns": list(dict.fromkeys(referenced_cols))}
