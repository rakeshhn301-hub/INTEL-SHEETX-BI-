"""
Stage 3: Deterministic Slot Resolver, Ambiguity Clarification & Refusal Engine (Chapters 18.4-18.6, 30.1 & 31.4).
Resolves parsed hints against the real dataset schema & metric registry, asks one concrete
clarification question when top candidates fall within CLARIFICATION_MARGIN (0.10), and returns
closest executable alternatives whenever a question cannot be answered by the dataset.
"""
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional, Tuple
from ..config import settings
from ..query.spec import ChartSpec, DimensionSlot, FilterClause, MeasureSlot, PeriodSpec, SortSpec


def _similarity(a: str, b: str) -> float:
    al, bl = a.lower().replace("_", " "), b.lower().replace("_", " ")
    if al == bl:
        return 1.0
    if al in bl or bl in al:
        # Substring boost, e.g. 'revenue' inside 'gross revenue' vs 'net revenue' both score ~0.88!
        return round(0.86 + 0.10 * (min(len(al), len(bl)) / max(len(al), len(bl))), 4)
    return round(SequenceMatcher(None, al, bl).ratio(), 4)


def _closest_valid_alternatives(
    dataset_id: str,
    dataset_fields: List[Dict[str, Any]],
    available_metrics: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    alts: List[Dict[str, Any]] = []
    dims = [f for f in dataset_fields if f["role"] == "dimension" and 2 <= f["distinct_count"] <= 30]
    dates = [f for f in dataset_fields if f["role"] == "date"]
    primary_m = available_metrics[0] if available_metrics else None

    if primary_m and dims:
        alts.append({
            "label": f"Compare {primary_m['label']} by {dims[0]['name']}",
            "command": f"compare {primary_m['label'].lower()} by {dims[0]['name'].lower()}",
            "dataset_id": dataset_id,
        })
    if primary_m and dates:
        alts.append({
            "label": f"{primary_m['label']} trend by month",
            "command": f"{primary_m['label'].lower()} trend by month",
            "dataset_id": dataset_id,
        })
    if len(available_metrics) >= 2 and dims:
        alts.append({
            "label": f"Compare {available_metrics[1]['label']} by {dims[0]['name']}",
            "command": f"compare {available_metrics[1]['label'].lower()} by {dims[0]['name'].lower()}",
            "dataset_id": dataset_id,
        })
    if primary_m:
        alts.append({
            "label": "Headline KPI Summary",
            "command": "how are we doing this quarter",
            "dataset_id": dataset_id,
        })
    return alts[:3]


def _resolve_measure_token(
    token: str,
    available_metrics: List[Dict[str, Any]],
    dataset_fields: List[Dict[str, Any]],
) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
    """
    Returns (resolved_metric_key, clarification_payload_if_ambiguous).
    Checks ambiguity across similarly named numeric columns FIRST when a generic word
    like 'revenue' matches multiple dataset columns ('gross_revenue' and 'net_revenue') within 0.10!
    """
    tl = token.lower().strip()

    # Check if multiple dataset measure columns match a generic token within CLARIFICATION_MARGIN (Chapter 30.3 Ex 3)
    measure_cols = [f for f in dataset_fields if f["role"] == "measure" and f["additive"] == "additive"]
    exact_col = next((f for f in measure_cols if f["name"].lower() == tl), None)
    if not exact_col and len(measure_cols) >= 2:
        col_scores = sorted(
            [(f, _similarity(tl, f["name"])) for f in measure_cols],
            key=lambda x: -x[1],
        )
        if col_scores[0][1] >= 0.80 and (col_scores[0][1] - col_scores[1][1]) <= settings.clarification_margin:
            opts = [
                {
                    "label": c["name"].replace("_", " ").title(),
                    "metric_key": f"sum_{c['name'].lower()}",
                    "description": f"SUM({c['name']}) — {c['reason']}",
                }
                for c, s in col_scores[:3]
                if s >= 0.75
            ]
            return None, {
                "slot": "measure",
                "question": f"'{token}' matches multiple measures in this dataset. Which one did you mean?",
                "options": opts,
            }

    # Exact match on metric_key or label or synonym
    for m in available_metrics:
        if tl == m["metric_key"].lower() or tl == m["label"].lower():
            return m["metric_key"], None
    for m in available_metrics:
        if tl in [s.lower() for s in m.get("synonyms", [])]:
            return m["metric_key"], None
    if exact_col:
        # Prefer canonical metric backed by exact_col if present
        backed = next(
            (m for m in available_metrics if m["kind"] == "additive" and m["bound"].get("field", "").lower() == exact_col["name"].lower()),
            None,
        )
        return (backed["metric_key"] if backed else f"sum_{exact_col['name'].lower()}"), None

    # Fuzzy match across available metrics
    scored = []
    for m in available_metrics:
        best_s = max(
            [_similarity(tl, m["metric_key"]), _similarity(tl, m["label"])]
            + [_similarity(tl, syn) for syn in m.get("synonyms", [])]
        )
        scored.append((m, best_s))
    scored.sort(key=lambda x: -x[1])

    if not scored or scored[0][1] < 0.72:
        return None, {
            "slot": "measure",
            "question": f"I could not find a metric matching '{token}'. Choose one of this dataset's verified metrics:",
            "options": [
                {"label": m["label"], "metric_key": m["metric_key"], "description": m["formula_display"]}
                for m in available_metrics[:4]
            ],
        }

    if len(scored) >= 2 and (scored[0][1] - scored[1][1]) <= settings.clarification_margin and scored[0][1] < 0.99:
        return None, {
            "slot": "measure",
            "question": f"'{token}' is close to both '{scored[0][0]['label']}' and '{scored[1][0]['label']}'. Which metric should I run?",
            "options": [
                {"label": scored[0][0]["label"], "metric_key": scored[0][0]["metric_key"], "description": scored[0][0]["formula_display"]},
                {"label": scored[1][0]["label"], "metric_key": scored[1][0]["metric_key"], "description": scored[1][0]["formula_display"]},
            ],
        }

    return scored[0][0]["metric_key"], None


def resolve_to_chart_spec(
    *,
    dataset_id: str,
    row_count: int,
    parsed: Dict[str, Any],
    dataset_fields: List[Dict[str, Any]],
    resolved_metrics: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Returns one of:
    - { "outcome": "answered", "spec": ChartSpec, "forecast_requested": bool, "guardrail_notes": [...] }
    - { "outcome": "clarified", "question": str, "options": [...], "alternatives": [...] }
    - { "outcome": "refused", "reason": str, "alternatives": [...] }
    """
    available_metrics = [m for m in resolved_metrics if m["available"]]
    alts = _closest_valid_alternatives(dataset_id, dataset_fields, available_metrics)

    intent = parsed.get("intent", "UNSUPPORTED")
    if intent == "UNSUPPORTED":
        ambs = parsed.get("ambiguities") or ["This dataset does not contain the columns needed for that question."]
        return {
            "outcome": "refused",
            "reason": f"Cannot compute on this dataset: {ambs[0]}.",
            "alternatives": alts,
        }

    if not available_metrics:
        return {
            "outcome": "refused",
            "reason": "This dataset has no summable numeric measures or countable identifiers.",
            "alternatives": [],
        }

    slots = parsed.get("slots", {})
    m_hints: List[str] = slots.get("measure_hints") or []
    d_hints: List[str] = slots.get("dimension_hints") or []
    date_fields = [f for f in dataset_fields if f["role"] == "date"]
    dim_fields = [f for f in dataset_fields if f["role"] == "dimension" and f["distinct_count"] >= 2]
    id_fields = [f for f in dataset_fields if f["role"] == "identifier"]

    # Executability check 1: Trend / Anomaly / Forecast require a real date column! (Table 18.3 & 31.1)
    if intent in ("A2_trend", "A8_anomaly") and not date_fields:
        return {
            "outcome": "refused",
            "reason": "This dataset has no date column, so a time-series trend is not possible. Choose a categorical comparison instead or upload a file with an order date.",
            "alternatives": alts,
        }

    # Executability check 2: Distribution requires >= 30 rows! (Table 6.1 & 31.1)
    if intent == "A6_distribution" and row_count < 30:
        return {
            "outcome": "refused",
            "reason": f"There are {row_count} rows, which is below the 30-row minimum needed to describe a distribution reliably.",
            "alternatives": alts,
        }

    # Executability check 3: Performance vs Target (A7) requires a target/budget column!
    target_metric = next(
        (m for m in available_metrics if any(k in m["metric_key"].lower() for k in ("target", "budget", "plan"))),
        None,
    )
    if intent == "A7_target" and not target_metric:
        return {
            "outcome": "refused",
            "reason": "This dataset has no target or budget column, so variance against plan cannot be computed.",
            "alternatives": alts,
        }

    # Resolve primary & secondary measures
    chosen_metrics: List[str] = []
    for mh in m_hints[:2]:
        mkey, clar = _resolve_measure_token(mh, available_metrics, dataset_fields)
        if clar:
            return {
                "outcome": "clarified",
                "question": clar["question"],
                "options": clar["options"],
                "alternatives": alts,
            }
        if mkey and mkey not in chosen_metrics:
            chosen_metrics.append(mkey)

    # Smart defaults per archetype when user omitted explicit measure
    if not chosen_metrics:
        if intent == "A9_summary":
            chosen_metrics = [m["metric_key"] for m in available_metrics[:5] if m["kind"] in ("additive", "ratio", "distinct")][:4]
        else:
            chosen_metrics = [available_metrics[0]["metric_key"]]

    if intent == "A7_target" and target_metric and target_metric["metric_key"] not in chosen_metrics:
        chosen_metrics = [chosen_metrics[0], target_metric["metric_key"]]

    if intent == "A5_relationship" and len(chosen_metrics) < 2:
        # Pick second available measure (e.g., discount_rate + total_profit)
        second = next((m["metric_key"] for m in available_metrics if m["metric_key"] != chosen_metrics[0]), None)
        if not second:
            return {
                "outcome": "refused",
                "reason": "Scatter relationship analysis requires at least two numeric measures in the dataset.",
                "alternatives": alts,
            }
        chosen_metrics.append(second)

    # Resolve dimensions & series split
    guardrail_notes: List[str] = []
    dimensions: List[DimensionSlot] = []
    series_dimension: Optional[str] = None

    if intent == "A9_summary":
        dimensions = []
    elif intent in ("A2_trend", "A8_anomaly") or (intent == "A7_target" and date_fields and not [d for d in d_hints if d not in [df["name"] for df in date_fields]]):
        df_name = date_fields[0]["name"]
        grain = slots.get("time_grain") or "month"
        dimensions = [DimensionSlot(field=df_name, grain=grain, sort=SortSpec(by="dimension", dir="asc"))]
        # Check if a categorical dimension was ALSO requested -> series split (Benchmark #18: "revenue by month and division")
        non_date_dims = [d for d in d_hints if d.lower() != df_name.lower()]
        if non_date_dims:
            series_dimension = non_date_dims[0]
    elif intent in ("A5_relationship", "A6_distribution"):
        dimensions = []
    else:
        # Categorical grouping (A1, A3, A4, A7, A10)
        non_date_hints = [d for d in d_hints if d.lower() not in {df["name"].lower() for df in date_fields}]
        # For A10_explain ("why is west margin down"), if 'west' filtered 'region', pick a different dimension (e.g. product or division) to decompose drivers!
        filtered_fields = {flt["field"].lower() for flt in slots.get("filters", [])}
        if intent == "A10_explain":
            driver_cands = [f["name"] for f in dim_fields if f["name"].lower() not in filtered_fields]
            chosen_dim = non_date_hints[0] if (non_date_hints and non_date_hints[0].lower() not in filtered_fields) else (driver_cands[0] if driver_cands else (dim_fields[0]["name"] if dim_fields else None))
        elif non_date_hints:
            chosen_dim = non_date_hints[0]
        elif dim_fields:
            chosen_dim = dim_fields[0]["name"]
        elif id_fields:
            chosen_dim = id_fields[0]["name"]
        else:
            chosen_dim = None

        if not chosen_dim:
            return {
                "outcome": "refused",
                "reason": "This dataset has no categorical dimension to group or compare across.",
                "alternatives": alts,
            }

        # Identifier guardrail note (Benchmark #13: "which customers buy most")
        matched_f = next((f for f in dataset_fields if f["name"] == chosen_dim), None)
        if matched_f and matched_f["role"] == "identifier":
            guardrail_notes.append(
                f"Identifier guardrail applied: '{chosen_dim}' is grouped as an entity key ranked by {chosen_metrics[0]} (identifier values themselves are never summed)."
            )

        dimensions = [DimensionSlot(field=chosen_dim, sort=SortSpec(by="measure", dir=slots.get("sort_dir", "desc")))]

    # Map initial chart_type (recommender refines it against actual cardinality & sign)
    default_chart_by_intent = {
        "A1_compare": "bar_h",
        "A2_trend": "line",
        "A3_composition": "donut",
        "A4_rank": "bar_h",
        "A5_relationship": "scatter",
        "A6_distribution": "histogram",
        "A7_target": "bullet",
        "A8_anomaly": "line",
        "A9_summary": "kpi",
        "A10_explain": "bar_h",
    }
    chart_type = slots.get("chart_override") or default_chart_by_intent.get(intent, "bar_h")
    limit = slots.get("limit") or (10 if intent == "A4_rank" else 12)

    filters = [FilterClause(**flt) for flt in slots.get("filters", [])]
    period_raw = slots.get("period")
    period = PeriodSpec(**period_raw) if period_raw else None

    spec = ChartSpec(
        intent=intent,
        chart_type=chart_type,
        dataset_id=dataset_id,
        dimensions=dimensions,
        series_dimension=series_dimension,
        measures=[MeasureSlot(metric=mk) for mk in chosen_metrics],
        filters=filters,
        period=period,
        compare=slots.get("compare", "none"),
        limit=limit,
    )

    return {
        "outcome": "answered",
        "spec": spec,
        "chart_override": slots.get("chart_override"),
        "forecast_requested": bool(slots.get("forecast", False)),
        "guardrail_notes": guardrail_notes,
    }
