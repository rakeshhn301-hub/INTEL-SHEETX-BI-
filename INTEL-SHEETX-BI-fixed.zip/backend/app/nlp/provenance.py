"""
Stage 5: EvidenceBundle Builder, Grounded Narrator & Strict Provenance Numeric Verifier (Chapter 31).
Guarantees structurally that no explanation or agent answer ever states a figure absent from
its executed query EvidenceBundle.
"""
import json
import re
from typing import Any, Dict, List, Set, Tuple
import httpx
from ..charts.echarts_builder import format_metric_value
from ..config import settings

# Matches numbers including decimals, comma-separated numbers, negatives, and trailing %
RE_NUMERIC_TOKEN = re.compile(r"(?<![A-Za-z0-9_])-?\d[\d,]*\.?\d*\s?%?")
RE_ISO_DATE_SPAN = re.compile(r"\b\d{4}-\d{2}(?:-\d{2})?\b")


def build_evidence_bundle(
    *,
    query_result: Dict[str, Any],
    dataset_name: str,
    total_dataset_rows: int,
    quality_warnings: List[Dict[str, Any]],
) -> Dict[str, Any]:
    rows = query_result.get("rows", [])
    metrics = query_result.get("metrics_used", [])
    primary_m = metrics[0] if metrics else None
    mkey = primary_m["metric_key"] if primary_m else None
    cols = query_result.get("columns", [])
    dim_col = cols[0] if (cols and mkey and cols[0] != mkey) else None

    derived: Dict[str, Any] = {"returned_rows": len(rows)}
    if mkey and rows:
        vals = [float(r[mkey]) for r in rows if r.get(mkey) is not None and isinstance(r.get(mkey), (int, float))]
        if vals:
            derived["max_value"] = round(max(vals), 4)
            derived["min_value"] = round(min(vals), 4)
            derived["gap_top_to_bottom"] = round(max(vals) - min(vals), 4)
            if primary_m and primary_m.get("kind") == "ratio":
                derived["gap_pp"] = round((max(vals) - min(vals)) * 100.0, 2)
            if primary_m and primary_m.get("kind") == "additive":
                derived["visible_sum"] = round(sum(vals), 4)
                if sum(vals) > 0:
                    derived["top_share_pct"] = round((vals[0] / sum(vals)) * 100.0, 1)
            if dim_col:
                top_row = max(
                    (r for r in rows if r.get(mkey) is not None),
                    key=lambda r: float(r[mkey]),
                    default=None,
                )
                bot_row = min(
                    (r for r in rows if r.get(mkey) is not None),
                    key=lambda r: float(r[mkey]),
                    default=None,
                )
                if top_row:
                    derived["leader"] = str(top_row.get(dim_col))
                    derived["leader_value"] = round(float(top_row[mkey]), 4)
                if bot_row:
                    derived["laggard"] = str(bot_row.get(dim_col))
                    derived["laggard_value"] = round(float(bot_row[mkey]), 4)
            if len(vals) >= 2:
                derived["first_value"] = round(vals[0], 4)
                derived["last_value"] = round(vals[-1], 4)
                derived["net_change"] = round(vals[-1] - vals[0], 4)

    caveats = [w["message"] for w in quality_warnings[:3]]
    null_rates = {w["column"]: round(float(w["rate"]) * 100.0, 1) for w in quality_warnings if w.get("kind") == "missing_values"}

    return {
        "query_id": query_result["query_id"],
        "sql_hash": query_result["sql_hash"],
        "dataset": {
            "id": query_result["dataset_id"],
            "name": dataset_name,
            "version": query_result["dataset_version"],
            "rows": total_dataset_rows,
        },
        "metrics": metrics,
        "scope": {
            "filters": query_result.get("applied_filters") or ["all records"],
            "grain": dim_col or "dataset_summary",
            "hidden_categories": query_result.get("hidden_categories_count", 0),
            "total_groups": query_result.get("total_groups_before_cap", len(rows)),
        },
        "rows": rows[:50],
        "derived": derived,
        "quality": {
            "null_rates_pct": null_rates,
            "caveats": caveats,
        },
    }


def _collect_allowed_numbers(bundle: Any, out: Set[float]) -> None:
    if isinstance(bundle, bool) or bundle is None:
        return
    if isinstance(bundle, (int, float)):
        v = float(bundle)
        for candidate in (v, v * 100.0, v / 100_000.0, v / 10_000_000.0):
            out.add(round(candidate, 4))
            out.add(round(candidate, 2))
            out.add(round(candidate, 1))
            out.add(float(round(candidate)))
        return
    if isinstance(bundle, str):
        # Extract calendar years/days from date labels in rows/scope so date mentions don't false-reject
        for dm in re.findall(r"\d+(?:\.\d+)?", bundle):
            try:
                out.add(float(dm))
            except ValueError:
                pass
        return
    if isinstance(bundle, dict):
        for v in bundle.values():
            _collect_allowed_numbers(v, out)
    elif isinstance(bundle, list):
        for item in bundle:
            _collect_allowed_numbers(item, out)


def verify_narrative_numbers(narrative: str, evidence_bundle: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """
    Extracts every numeric token from `narrative` and verifies that it matches a value in
    `evidence_bundle` within rounding tolerance max(0.06, abs(a) * 0.005) (Chapter 31.2).
    """
    allowed: Set[float] = set()
    _collect_allowed_numbers(evidence_bundle, allowed)

    # Strip ISO date tokens like 2026-01-15 before numeric token extraction if those dates exist in bundle strings
    bundle_text = json.dumps(evidence_bundle)
    scrubbed = narrative
    for dtok in RE_ISO_DATE_SPAN.findall(narrative):
        if dtok in bundle_text:
            scrubbed = scrubbed.replace(dtok, " ")

    bad_tokens: List[str] = []
    for raw_tok in RE_NUMERIC_TOKEN.findall(scrubbed):
        clean_s = raw_tok.strip().rstrip("%").replace(",", "").strip()
        if not clean_s or clean_s in ("-", "."):
            continue
        try:
            n = float(clean_s)
        except ValueError:
            continue

        matched = any(abs(n - a) <= max(0.06, abs(a) * 0.005) for a in allowed)
        if not matched:
            bad_tokens.append(raw_tok.strip())

    return (len(bad_tokens) == 0, bad_tokens)


def generate_grounded_explanation(
    *,
    question: str,
    intent: str,
    evidence_bundle: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Produces a concise, grounded business explanation strictly from `evidence_bundle`.
    If an AI provider is configured, runs Prompt N-L3 and verifies every figure via
    `verify_narrative_numbers` (regenerating/falling back if any figure is unverified).
    Otherwise uses the deterministic grounded narrator so every number is 100% provenance-bound.
    """
    rejected_figures: List[str] = []

    if settings.ai_provider not in ("none", "") and settings.ai_api_key:
        for attempt in range(2):
            candidate = _call_llm_narrator(question, evidence_bundle, feedback=rejected_figures if attempt == 1 else None)
            if candidate:
                ok, bad = verify_narrative_numbers(candidate, evidence_bundle)
                if ok:
                    return {
                        "narrative": candidate,
                        "verified": True,
                        "rejected_figures": rejected_figures,
                        "source": f"llm_grounded:{settings.ai_model_narrate}",
                    }
                rejected_figures.extend(bad)

    # Deterministic grounded narrative constructed solely from EvidenceBundle figures
    det_text = _deterministic_narrative(intent, evidence_bundle)
    ok, bad = verify_narrative_numbers(det_text, evidence_bundle)
    return {
        "narrative": det_text,
        "verified": ok,
        "rejected_figures": rejected_figures + bad,
        "source": "deterministic_grounded",
    }


def _deterministic_narrative(intent: str, bundle: Dict[str, Any]) -> str:
    ds = bundle["dataset"]
    scope = bundle["scope"]
    metrics = bundle["metrics"]
    rows = bundle["rows"]
    derived = bundle["derived"]
    caveats = bundle["quality"]["caveats"]

    scope_str = ", ".join(scope["filters"])
    if not rows:
        return (
            f"Scope: {ds['name']} (v{ds['version']}, {scope_str}). "
            f"Observed: 0 rows matched the active filter criteria, so no aggregate metric could be computed."
        )

    m0 = metrics[0] if metrics else {"label": "Value", "metric_key": "value", "format": {"kind": "number"}}
    fmt = m0.get("format", {"kind": "number"})
    mkey = m0["metric_key"]

    parts: List[str] = [
        f"Scope: {ds['name']} v{ds['version']} ({ds['rows']} source rows; filters: {scope_str}; grain: {scope['grain']})."
    ]

    if scope["grain"] == "dataset_summary":
        summary_bits = []
        for m in metrics[:4]:
            v = rows[0].get(m["metric_key"])
            if v is not None:
                summary_bits.append(f"{m['label']} is {format_metric_value(v, m.get('format'))}")
        parts.append("Observed: " + ", ".join(summary_bits) + ".")
    elif "leader" in derived and "laggard" in derived:
        l_val = format_metric_value(derived["leader_value"], fmt)
        b_val = format_metric_value(derived["laggard_value"], fmt)
        parts.append(
            f"Observed: Across {derived['returned_rows']} displayed groups, {derived['leader']} leads {m0['label']} at {l_val}, "
            f"while {derived['laggard']} is lowest at {b_val}."
        )
        if intent == "A10_explain":
            parts.append(
                f"This suggests variation in {m0['label']} is concentrated between {derived['leader']} and {derived['laggard']}; "
                f"inspect pricing, discount rate, and cost completeness at order grain to confirm."
            )
        elif intent == "A5_relationship":
            parts.append("Note: Observational co-movement indicates association only and does not prove causation.")
    elif "first_value" in derived and "last_value" in derived:
        f_val = format_metric_value(derived["first_value"], fmt)
        e_val = format_metric_value(derived["last_value"], fmt)
        parts.append(
            f"Observed: Over {derived['returned_rows']} periods, {m0['label']} moved from {f_val} in the opening period to {e_val} in the latest period."
        )

    if caveats:
        parts.append(f"Caveat: {caveats[0]}")

    return " ".join(parts)


def _call_llm_narrator(question: str, bundle: Dict[str, Any], feedback: List[str] = None) -> str:
    sys_msg = (
        "You write a short business explanation from an executed query EvidenceBundle. "
        "1. Every number you write MUST appear in the bundle. Do not compute or estimate new numbers. "
        "2. State scope (dataset version, filters, grain) in the first sentence. "
        "3. Separate OBSERVED facts from INFERENCE ('This suggests...'). "
        "4. Never claim causation. "
        "5. Mention any caveat in bundle.quality.caveats. Maximum 110 words."
    )
    if feedback:
        sys_msg += f" Previous draft was rejected because these numbers were not in the bundle: {feedback}. Use ONLY exact numbers from bundle."
    try:
        resp = httpx.post(
            f"{settings.ai_base_url.rstrip('/')}/chat/completions",
            headers={"Authorization": f"Bearer {settings.ai_api_key}"},
            json={
                "model": settings.ai_model_narrate,
                "temperature": 0.0,
                "messages": [
                    {"role": "system", "content": sys_msg},
                    {"role": "user", "content": f"EVIDENCE BUNDLE:\n{json.dumps(bundle)}\n\nQUESTION: {question}"},
                ],
            },
            timeout=settings.ai_timeout_ms / 1000.0,
        )
        if resp.status_code == 200:
            return resp.json()["choices"][0]["message"]["content"].strip()
    except Exception:
        pass
    return ""
