"""
Stage 2: Deterministic Rule Parser + Optional Server-Side LLM Structured Output Parser (Chapter 30).
Maps a normalised user command into the closed intent vocabulary (A1..A10 or UNSUPPORTED)
and typed slot hints. Never generates SQL or chart code.
"""
import json
import re
from typing import Any, Dict, List, Optional
import httpx
from ..config import settings

UNSUPPORTED_CONCEPTS = [
    (re.compile(r"\b(churn|churned)\b", re.I), "customer churn requires a subscription status or multi-year inactivity lifecycle log"),
    (re.compile(r"\b(retention|cohort retention)\b", re.I), "customer retention requires a longitudinal customer_id history"),
    (re.compile(r"\b(nps|net promoter|csat|sentiment)\b", re.I), "satisfaction/NPS requires survey score responses"),
    (re.compile(r"\b(cac|customer acquisition cost|ad spend|impressions|clicks)\b", re.I), "marketing attribution requires campaign spend and impression logs"),
    (re.compile(r"\b(employee|attrition|payroll|salary)\b", re.I), "HR analytics requires employee headcount and compensation tables"),
]

ADVERSARIAL_PATTERNS = re.compile(
    r"(\bdrop\s+table\b|\bdelete\s+from\b|\btruncate\s+table\b|\bignore\s+(all\s+|previous\s+|your\s+)?instructions\b|\breveal\s+(the\s+)?(api\s+key|secret|password)\b|\bshow\s+all\s+users\b|\bunion\s+select\b)",
    re.I,
)

MONTH_MAP = {
    "january": "01", "jan": "01",
    "february": "02", "feb": "02",
    "march": "03", "mar": "03",
    "april": "04", "apr": "04",
    "may": "05",
    "june": "06", "jun": "06",
    "july": "07", "jul": "07",
    "august": "08", "aug": "08",
    "september": "09", "sep": "09", "sept": "09",
    "october": "10", "oct": "10",
    "november": "11", "nov": "11",
    "december": "12", "dec": "12",
}


def parse_command_slots(
    *,
    normalised_info: Dict[str, Optional[str]],
    dataset_fields: List[Dict[str, Any]],
    resolved_metrics: List[Dict[str, Any]],
    previous_spec: Optional[Dict[str, Any]] = None,
    anchor_year: int = 2026,
) -> Dict[str, Any]:
    raw_text = normalised_info["raw_text"] or ""
    norm = normalised_info["normalised"] or ""
    chart_override = normalised_info["chart_override"]

    # 0. Adversarial / SQL / Prompt-injection block (Chapter 32.5 & Appendix F.2)
    if ADVERSARIAL_PATTERNS.search(raw_text):
        return {
            "intent": "UNSUPPORTED",
            "confidence": 1.0,
            "parser_source": "security_guardrail",
            "ambiguities": [
                "Adversarial or raw SQL instruction rejected. INTEL SHEETX BI compiles validated analytical intents only and never executes raw SQL or system instructions."
            ],
            "slots": {},
        }

    if not norm and not chart_override:
        return {
            "intent": "UNSUPPORTED",
            "confidence": 1.0,
            "parser_source": "rules",
            "ambiguities": ["Empty command. Try e.g. 'compare sales by division' or '/line profit trend by month'."],
            "slots": {},
        }

    # 1. Context follow-up ("same but as a line chart")
    if previous_spec and (re.search(r"\b(same|it|previous|that)\b", norm) or (chart_override and len(norm.split()) <= 2)):
        prev_dims = previous_spec.get("dimensions") or []
        prev_ms = previous_spec.get("measures") or []
        return {
            "intent": previous_spec.get("intent", "A1_compare"),
            "confidence": 0.95,
            "parser_source": "context_followup",
            "ambiguities": [],
            "slots": {
                "measure_hint": prev_ms[0]["metric"] if prev_ms else None,
                "dimension_hint": prev_dims[0]["field"] if prev_dims else None,
                "time_grain": prev_dims[0].get("grain") if prev_dims else None,
                "chart_override": chart_override or previous_spec.get("chart_type"),
                "filters": previous_spec.get("filters", []),
                "period": previous_spec.get("period"),
                "limit": previous_spec.get("limit"),
                "compare": previous_spec.get("compare", "none"),
                "forecast": False,
            },
        }

    # 2. Check domain concepts that require specific schema columns (e.g. churn, retention, NPS)
    field_names_blob = " ".join(f["name"].lower() for f in dataset_fields)
    for pat, reason in UNSUPPORTED_CONCEPTS:
        if pat.search(norm):
            # For retention, check if customer_id + date actually exist; for churn, require subscription/churn col
            if "churn" in norm and "churn" not in field_names_blob and "subscription" not in field_names_blob:
                return {
                    "intent": "UNSUPPORTED",
                    "confidence": 0.96,
                    "parser_source": "rules",
                    "ambiguities": [reason],
                    "slots": {},
                }
            if "retention" in norm and "customer" not in field_names_blob:
                return {
                    "intent": "UNSUPPORTED",
                    "confidence": 0.95,
                    "parser_source": "rules",
                    "ambiguities": [reason],
                    "slots": {},
                }
            if "churn" not in norm and "retention" not in norm:
                return {
                    "intent": "UNSUPPORTED",
                    "confidence": 0.96,
                    "parser_source": "rules",
                    "ambiguities": [reason],
                    "slots": {},
                }

    # 3. Extract time grain, period, top-N, filters, compare, and forecast flags deterministically
    time_grain: Optional[str] = None
    for g in ("day", "week", "month", "quarter", "year"):
        if re.search(rf"\b(by\s+{g}|{g}\b)", norm):
            # Distinguish "this quarter" / "last year" period words from grouping grain unless "by <grain>" or standalone grain
            if re.search(rf"\bby\s+{g}\b", norm) or not re.search(rf"\b(this|last|next|prior)\s+{g}\b", norm):
                time_grain = g
                break

    period: Optional[Dict[str, Any]] = None
    m_since = re.search(r"\bsince\s+([a-z]+)(?:\s+(\d{4}))?\b", norm)
    if m_since and m_since.group(1) in MONTH_MAP:
        yr = int(m_since.group(2)) if m_since.group(2) else anchor_year
        mm = MONTH_MAP[m_since.group(1)]
        period = {"kind": "absolute", "from": f"{yr}-{mm}-01", "to": None}
    elif re.search(r"\blast\s+quarter\b", norm):
        period = {"kind": "relative", "value": "last_quarter"}
    elif re.search(r"\bthis\s+quarter\b|\bqtd\b", norm):
        period = {"kind": "relative", "value": "this_quarter"}
    elif re.search(r"\bthis\s+year\b|\bytd\b", norm) and not re.search(r"\blast\s+year\b", norm):
        period = {"kind": "relative", "value": "this_year"}
    elif re.search(r"\blast\s+30\s+days\b", norm):
        period = {"kind": "relative", "value": "last_30_days"}
    elif re.search(r"\blast\s+90\s+days\b", norm):
        period = {"kind": "relative", "value": "last_90_days"}

    compare = "none"
    if re.search(r"\b(prior[\s_]year|last\s+year|with\s+last\s+year|vs\.?\s+last\s+year)\b", norm):
        compare = "prior_year"

    forecast = bool(re.search(r"\b(forecast|predict|project|next\s+quarter|next\s+3\s+months)\b", norm))

    limit: Optional[int] = None
    sort_dir = "desc"
    m_top = re.search(r"\b(top|bottom|worst|lowest|highest)\s+(\d+)\b", norm)
    if m_top:
        limit = int(m_top.group(2))
        if m_top.group(1) in ("bottom", "worst", "lowest"):
            sort_dir = "asc"

    # Extract value filters from known low-cardinality dimension top_values in schema (e.g. "north only", "for the West division")
    extracted_filters: List[Dict[str, Any]] = []
    for f in dataset_fields:
        if f["role"] != "dimension" or f.get("exclude_from_ai"):
            continue
        stats = json.loads(f["stats_json"]) if isinstance(f.get("stats_json"), str) else (f.get("stats") or {})
        for tv in stats.get("top_values", []):
            v_str = str(tv.get("value", "")).strip()
            if len(v_str) >= 3 and re.search(rf"\b{re.escape(v_str.lower())}\b", norm):
                extracted_filters.append({"field": f["name"], "op": "=", "value": v_str})
                break

    # 4. Classify Intent (A1..A10)
    intent: Optional[str] = None
    if re.search(r"\b(show me everything|everything|overall|overview|how are we doing|headline|summary|kpi)\b", norm):
        intent = "A9_summary"
    elif forecast:
        intent = "A2_trend"
        time_grain = time_grain or "month"
    elif re.search(r"\b(vs\.?\s*target|against\s+target|against\s+plan|vs\.?\s*budget|target)\b", norm):
        intent = "A7_target"
    elif re.search(r"\b(why\s+is|why\s+did|explain\s+why|drivers?\s+of|what\s+drove)\b", norm):
        intent = "A10_explain"
    elif re.search(r"\b(where\s+did\s+.*\s+(drop|fall|spike)|anomal|unusual|outlier)\b", norm):
        intent = "A8_anomaly"
        time_grain = time_grain or "month"
    elif re.search(r"\b(affect|correlat|relationship|vs\.?|versus|against)\b", norm) and compare == "none" and "target" not in norm:
        intent = "A5_relationship"
    elif re.search(r"\b(spread\s+of|distribution\s+of|histogram)\b", norm) or chart_override == "histogram":
        intent = "A6_distribution"
    elif re.search(r"\b(share|composition|mix|proportion|breakdown\s+share|percentage\s+of)\b", norm) or chart_override in ("donut", "pct_bar"):
        intent = "A3_composition"
    elif m_top or re.search(r"\b(which\s+\w+\s+buy\s+most|most|rank|top\b|bottom\b)\b", norm):
        intent = "A4_rank"
        limit = limit or 10
    elif compare == "prior_year" or re.search(r"\b(trend|over\s+time|since\s+[a-z]+)\b", norm) or time_grain is not None or chart_override in ("line", "area"):
        intent = "A2_trend"
        time_grain = time_grain or "month"
    elif re.search(r"\b(compare|by\s+\w+)\b", norm) or chart_override in ("bar_h", "bar"):
        intent = "A1_compare"

    # Extract measure & dimension tokens mentioned in text
    measure_hints = _extract_measure_hints(norm, dataset_fields, resolved_metrics)
    dim_hints = _extract_dimension_hints(norm, dataset_fields)

    # Fallback: if rules did not match a clear intent AND an AI provider key is configured, call structured LLM parser
    if intent is None and settings.ai_provider not in ("none", "") and settings.ai_api_key:
        llm_res = _call_structured_llm_parser(norm, dataset_fields, resolved_metrics)
        if llm_res:
            return llm_res

    if intent is None:
        if dim_hints and measure_hints:
            intent = "A1_compare"
        elif measure_hints and not dim_hints:
            intent = "A9_summary"
        else:
            return {
                "intent": "UNSUPPORTED",
                "confidence": 0.45,
                "parser_source": "rules",
                "ambiguities": [
                    f"Could not map '{raw_text}' to a supported analytical question on this dataset."
                ],
                "slots": {},
            }

    return {
        "intent": intent,
        "confidence": 0.92,
        "parser_source": "deterministic_rules",
        "ambiguities": [],
        "slots": {
            "measure_hints": measure_hints,
            "dimension_hints": dim_hints,
            "time_grain": time_grain,
            "chart_override": chart_override,
            "filters": extracted_filters,
            "period": period,
            "limit": limit,
            "sort_dir": sort_dir,
            "compare": compare,
            "forecast": forecast,
        },
    }


def _extract_measure_hints(
    norm: str,
    dataset_fields: List[Dict[str, Any]],
    resolved_metrics: List[Dict[str, Any]],
) -> List[str]:
    found: List[Tuple[int, int, str]] = []  # (position, -length, token)

    # Check canonical metrics & synonyms (longest phrases first so 'avg_order_value' beats 'sales')
    candidates: List[Tuple[str, str]] = []
    for m in resolved_metrics:
        candidates.append((m["metric_key"].lower(), m["metric_key"]))
        candidates.append((m["label"].lower(), m["metric_key"]))
        for syn in m.get("synonyms", []):
            candidates.append((syn.lower(), m["metric_key"]))

    for f in dataset_fields:
        if f["role"] == "measure":
            candidates.append((f["name"].lower(), f["name"]))
            candidates.append((f["name"].lower().replace("_", " "), f["name"]))

    candidates.sort(key=lambda x: -len(x[0]))
    occupied = [False] * (len(norm) + 1)

    for phrase, target_key in candidates:
        if len(phrase) < 3:
            continue
        m = re.search(rf"\b{re.escape(phrase)}\b", norm)
        if m:
            s, e = m.span()
            if any(occupied[s:e]):
                continue
            for idx in range(s, e):
                occupied[idx] = True
            found.append((s, -len(phrase), target_key))

    # Also keep raw measure-like words (e.g. 'revenue' when dataset has gross_revenue & net_revenue) for ambiguity checks!
    for generic_word in ("revenue", "sales", "margin", "profit", "cost", "discount", "price", "value"):
        m = re.search(rf"\b{generic_word}\b", norm)
        if m and not any(occupied[m.start():m.end()]):
            found.append((m.start(), -len(generic_word), generic_word))

    found.sort(key=lambda x: x[0])
    out: List[str] = []
    for _, _, tok in found:
        if tok not in out:
            out.append(tok)
    return out


def _extract_dimension_hints(norm: str, dataset_fields: List[Dict[str, Any]]) -> List[str]:
    found: List[Tuple[int, str]] = []
    for f in dataset_fields:
        if f["role"] in ("dimension", "identifier", "date"):
            fl = f["name"].lower()
            variants = {fl, fl.replace("_", " "), fl.rstrip("s"), fl + "s"}
            if "customer" in fl:
                variants.update({"customer", "customers", "client", "clients"})
            if "product" in fl:
                variants.update({"product", "products", "item", "items", "sku", "skus"})
            for v in sorted(variants, key=lambda s: -len(s)):
                if len(v) < 3:
                    continue
                m = re.search(rf"\b{re.escape(v)}\b", norm)
                if m:
                    found.append((m.start(), f["name"]))
                    break
    found.sort(key=lambda x: x[0])
    out: List[str] = []
    for _, name in found:
        if name not in out:
            out.append(name)
    return out


def _call_structured_llm_parser(
    norm: str,
    dataset_fields: List[Dict[str, Any]],
    resolved_metrics: List[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """
    Optional server-side OpenAI-compatible structured-output intent parser (Prompt N-L1, Chapter 30.2).
    Sends ONLY schema metadata (never raw rows, never PII-excluded columns).
    """
    safe_schema = {
        "fields": [
            {"name": f["name"], "role": f["role"], "semantic_type": f["semantic_type"], "distinct_count": f["distinct_count"]}
            for f in dataset_fields
            if not f.get("exclude_from_ai") and not f.get("hidden")
        ],
        "metrics": [
            {"metric_key": m["metric_key"], "label": m["label"], "available": m["available"]}
            for m in resolved_metrics
            if m["available"]
        ],
    }
    sys_prompt = (
        "You are the intent parser for INTEL SHEETX BI. Convert one user sentence into JSON with keys: "
        "intent (one of A1_compare, A2_trend, A3_composition, A4_rank, A5_relationship, A6_distribution, "
        "A7_target, A8_anomaly, A9_summary, A10_explain, UNSUPPORTED), measure, measure_2, dimension, "
        "time_grain, limit, confidence, ambiguities. Never output SQL or prose."
    )
    try:
        resp = httpx.post(
            f"{settings.ai_base_url.rstrip('/')}/chat/completions",
            headers={"Authorization": f"Bearer {settings.ai_api_key}"},
            json={
                "model": settings.ai_model_parse,
                "temperature": 0.0,
                "response_format": {"type": "json_object"},
                "messages": [
                    {"role": "system", "content": sys_prompt},
                    {"role": "user", "content": f"SCHEMA:\n{json.dumps(safe_schema)}\n\nUSER SENTENCE:\n{norm}"},
                ],
            },
            timeout=settings.ai_timeout_ms / 1000.0,
        )
        if resp.status_code != 200:
            return None
        parsed = json.loads(resp.json()["choices"][0]["message"]["content"])
        m_hints = [x for x in (parsed.get("measure"), parsed.get("measure_2")) if x]
        d_hints = [parsed["dimension"]] if parsed.get("dimension") else []
        return {
            "intent": parsed.get("intent", "UNSUPPORTED"),
            "confidence": float(parsed.get("confidence", 0.7)),
            "parser_source": f"llm:{settings.ai_model_parse}",
            "ambiguities": parsed.get("ambiguities", []),
            "slots": {
                "measure_hints": m_hints,
                "dimension_hints": d_hints,
                "time_grain": parsed.get("time_grain"),
                "chart_override": None,
                "filters": [],
                "period": None,
                "limit": parsed.get("limit"),
                "sort_dir": "desc",
                "compare": "none",
                "forecast": False,
            },
        }
    except Exception:
        return None
