"""Natural-language command compiler and grounded provenance verification package."""
