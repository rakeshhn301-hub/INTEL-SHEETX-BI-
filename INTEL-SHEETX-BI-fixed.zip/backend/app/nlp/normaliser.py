"""
Stage 1: Deterministic Command Normaliser (Chapters 17.3, 18.4 & 30.1).
Extracts leading '/' slash visual directives, strips polite filler, and expands business aliases.
"""
import re
from typing import Dict, List, Optional, Tuple

SLASH_MAP: Dict[str, str] = {
    "/bar": "bar_h",
    "/bar_h": "bar_h",
    "/barh": "bar_h",
    "/vbar": "bar",
    "/column": "bar",
    "/line": "line",
    "/area": "area",
    "/scatter": "scatter",
    "/histogram": "histogram",
    "/hist": "histogram",
    "/stacked": "stacked_bar",
    "/stacked_bar": "stacked_bar",
    "/pct": "pct_bar",
    "/pct_bar": "pct_bar",
    "/donut": "donut",
    "/pie": "donut",
    "/bullet": "bullet",
    "/kpi": "kpi",
    "/table": "table",
    "/heatmap": "heatmap",
    "/waterfall": "waterfall",
    "/pareto": "pareto",
}

EXPLICIT_CHART_PHRASES: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"\b(as a |to a |in a )?(horizontal bar|bar_h)( chart)?\b", re.I), "bar_h"),
    (re.compile(r"\b(as a |to a |in a )?(bar|column)( chart)?\b", re.I), "bar_h"),
    (re.compile(r"\b(as a |to a |in a )?line( chart| graph)?\b", re.I), "line"),
    (re.compile(r"\b(as an? |to an? )?area( chart)?\b", re.I), "area"),
    (re.compile(r"\b(as a |to a )?scatter( plot| chart)?\b", re.I), "scatter"),
    (re.compile(r"\b(as a |to a )?histogram\b", re.I), "histogram"),
    (re.compile(r"\b(as a |to a )?(donut|doughnut|pie)( chart)?\b", re.I), "donut"),
    (re.compile(r"\b(as a |to a )?(100%\s*stacked|pct bar|percentage bar)( chart)?\b", re.I), "pct_bar"),
    (re.compile(r"\b(as a |to a )?stacked bar( chart)?\b", re.I), "stacked_bar"),
    (re.compile(r"\b(as a |to a )?bullet( chart)?\b", re.I), "bullet"),
    (re.compile(r"\b(as a |to a )?waterfall( chart)?\b", re.I), "waterfall"),
    (re.compile(r"\b(as a |to a )?pareto( chart)?\b", re.I), "pareto"),
    (re.compile(r"\b(as a |to a )?table\b", re.I), "table"),
    (re.compile(r"\b(as a |to a )?kpi( strip| cards?)?\b", re.I), "kpi"),
]

ALIASES: Dict[str, List[str]] = {
    "revenue": ["rev", "revs", "turnover"],
    "profit_margin": ["margin %", "profit margin", "net margin"],
    "avg_order_value": ["aov", "average order value", "avg order value", "order value", "order values"],
    "month": ["mth", "mo", "monthly"],
    "quarter": ["qtr", "quarterly"],
    "year": ["yr", "yearly", "annual"],
    "week": ["wk", "weekly"],
    "day": ["daily"],
    "yoy_growth": ["yoy"],
}

POLITE_FILLER = re.compile(
    r"\b(please|kindly|could you|can you|would you|i want to see|i'd like to see|give me|display|plot|draw|create a|make a)\b",
    re.I,
)


def normalise_command(raw_text: str) -> Dict[str, Optional[str]]:
    t = (raw_text or "").strip()
    chart_override: Optional[str] = None

    # 1. Leading slash command (/bar, /line, /scatter, etc.)
    if t.startswith("/"):
        parts = t.split(None, 1)
        cmd_tok = parts[0].lower()
        if cmd_tok in SLASH_MAP:
            chart_override = SLASH_MAP[cmd_tok]
            t = parts[1] if len(parts) > 1 else ""

    t_low = t.lower()

    # 2. Explicit chart override phrases ("... as a line chart", "move ... to a line chart")
    for pat, ctype in EXPLICIT_CHART_PHRASES:
        if pat.search(t_low):
            if chart_override is None:
                chart_override = ctype
            t_low = pat.sub(" ", t_low)
            break

    # 3. Strip filler while preserving 'show me everything'
    if "show me everything" not in t_low and "everything" != t_low.strip():
        t_low = re.sub(r"\b(show me|chart|move)\b", " ", t_low)
    t_low = POLITE_FILLER.sub(" ", t_low)

    # 4. Expand canonical aliases on word boundaries
    for canonical, variants in ALIASES.items():
        for v in variants:
            t_low = re.sub(rf"\b{re.escape(v)}\b", canonical, t_low)

    t_low = re.sub(r"\s+", " ", t_low).strip(" ,.?!;")
    return {
        "raw_text": raw_text,
        "normalised": t_low,
        "chart_override": chart_override,
    }
