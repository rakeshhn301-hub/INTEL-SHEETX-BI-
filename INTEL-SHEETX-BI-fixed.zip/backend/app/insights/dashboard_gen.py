"""
The 6-Tile 12-Column Auto-Dashboard Blueprint Generator (Chapter 20 & Phase 7).
Produces a persisted, editable JSON dashboard definition bound to a specific dataset version
where every tile executes a live DuckDB query.
"""
from typing import Any, Dict, List
from ..db import new_id, now_iso


def generate_dashboard_blueprint(
    *,
    dataset_id: str,
    dataset_name: str,
    dataset_version: int,
    profile: Dict[str, Any],
    dataset_fields: List[Dict[str, Any]],
    resolved_metrics: List[Dict[str, Any]],
) -> Dict[str, Any]:
    available = [m for m in resolved_metrics if m["available"]]
    additive = [m for m in available if m["kind"] == "additive"]
    ratios = [m for m in available if m["kind"] == "ratio"]

    date_fields = [f for f in dataset_fields if f["role"] == "date"]
    low_dims = sorted(
        [f for f in dataset_fields if f["role"] == "dimension" and 2 <= f["distinct_count"] <= 30],
        key=lambda f: abs(f["distinct_count"] - 6),  # ~5-8 categories is ideal visual spine
    )
    high_dims = [f for f in dataset_fields if f["role"] in ("dimension", "detail") and f["distinct_count"] >= 2]
    all_dims = low_dims or high_dims

    primary_m = additive[0] if additive else (available[0] if available else None)
    quality_m = next((m for m in ratios if m["metric_key"] == "profit_margin"), ratios[0] if ratios else primary_m)
    profit_m = next((m for m in available if m["metric_key"] == "total_profit"), primary_m)

    if not primary_m:
        raise ValueError("Cannot generate a dashboard: dataset has no executable metrics.")

    kpi_metrics = [m["metric_key"] for m in available[:5]]
    dim_primary = all_dims[0]["name"] if all_dims else None
    dim_secondary = all_dims[1]["name"] if len(all_dims) > 1 else dim_primary
    date_col = date_fields[0]["name"] if date_fields else None

    tiles: List[Dict[str, Any]] = []

    # Tile 1: Headline KPI Strip (Full 12 columns — "Where are we?")
    tiles.append({
        "id": new_id("tile"),
        "title": "Executive Headline KPIs",
        "col_span": 12,
        "row_height": "sm",
        "why_chosen": "Opens the dashboard reading order ('Where are we?') with top-line scope totals and ratios.",
        "spec": {
            "intent": "A9_summary",
            "chart_type": "kpi",
            "dataset_id": dataset_id,
            "dimensions": [],
            "measures": [{"metric": mk} for mk in kpi_metrics],
            "filters": [],
            "limit": 10,
            "title": "Executive Headline KPIs",
        },
    })

    # Tile 2: Primary Trend (8 columns — "What changed over time?")
    if date_col:
        tiles.append({
            "id": new_id("tile"),
            "title": f"{primary_m['label']} Trend by Month",
            "col_span": 8,
            "row_height": "md",
            "why_chosen": f"Primary measure '{primary_m['label']}' plotted along real date field '{date_col}' at monthly grain with prior-year baseline.",
            "spec": {
                "intent": "A2_trend",
                "chart_type": "line",
                "dataset_id": dataset_id,
                "dimensions": [{"field": date_col, "grain": "month", "sort": {"by": "dimension", "dir": "asc"}}],
                "measures": [{"metric": primary_m["metric_key"]}],
                "filters": [],
                "compare": "prior_year",
                "limit": 60,
                "title": f"{primary_m['label']} Trend by Month",
            },
        })
    elif dim_secondary:
        tiles.append({
            "id": new_id("tile"),
            "title": f"{primary_m['label']} by {dim_secondary}",
            "col_span": 8,
            "row_height": "md",
            "why_chosen": f"No date column present in dataset; substituted ranked '{dim_secondary}' comparison.",
            "spec": {
                "intent": "A1_compare",
                "chart_type": "bar_h",
                "dataset_id": dataset_id,
                "dimensions": [{"field": dim_secondary, "sort": {"by": "measure", "dir": "desc"}}],
                "measures": [{"metric": primary_m["metric_key"]}],
                "filters": [],
                "limit": 12,
                "title": f"{primary_m['label']} by {dim_secondary}",
            },
        })

    # Tile 3: Ranked Breakdown by Primary Dimension (4 columns — "Where is it concentrated?")
    if dim_primary:
        tiles.append({
            "id": new_id("tile"),
            "title": f"{primary_m['label']} by {dim_primary} (Sorted)",
            "col_span": 4,
            "row_height": "md",
            "why_chosen": f"Sorted horizontal bar on '{dim_primary}' ({all_dims[0]['distinct_count']} distinct values) with zero baseline.",
            "spec": {
                "intent": "A1_compare",
                "chart_type": "bar_h",
                "dataset_id": dataset_id,
                "dimensions": [{"field": dim_primary, "sort": {"by": "measure", "dir": "desc"}}],
                "measures": [{"metric": primary_m["metric_key"]}],
                "filters": [],
                "limit": 10,
                "title": f"{primary_m['label']} by {dim_primary} (Sorted)",
            },
        })

    # Tile 4: Quality / Margin Metric on Same Dimension (6 columns — "Volume vs Profitability")
    if dim_primary and quality_m:
        tiles.append({
            "id": new_id("tile"),
            "title": f"{quality_m['label']} by {dim_primary}",
            "col_span": 6,
            "row_height": "md",
            "why_chosen": f"Pairs volume with quality metric '{quality_m['label']}' ({quality_m['formula_display']}) across '{dim_primary}'.",
            "spec": {
                "intent": "A1_compare",
                "chart_type": "bar_h",
                "dataset_id": dataset_id,
                "dimensions": [{"field": dim_primary, "sort": {"by": "measure", "dir": "desc"}}],
                "measures": [{"metric": quality_m["metric_key"]}],
                "filters": [],
                "limit": 10,
                "title": f"{quality_m['label']} by {dim_primary}",
            },
        })

    # Tile 5: Composition Share (6 columns — Donut if <=5 categories, else 100% / Horizontal Bar)
    if dim_secondary:
        sec_f = next((f for f in dataset_fields if f["name"] == dim_secondary), None)
        d_cnt = sec_f["distinct_count"] if sec_f else 6
        comp_chart = "donut" if d_cnt <= 5 else "bar_h"
        tiles.append({
            "id": new_id("tile"),
            "title": f"{primary_m['label']} Share by {dim_secondary}",
            "col_span": 6,
            "row_height": "md",
            "why_chosen": f"Composition share across '{dim_secondary}' ({d_cnt} categories -> {comp_chart} per <=5 donut guardrail).",
            "spec": {
                "intent": "A3_composition",
                "chart_type": comp_chart,
                "dataset_id": dataset_id,
                "dimensions": [{"field": dim_secondary, "sort": {"by": "measure", "dir": "desc"}}],
                "measures": [{"metric": primary_m["metric_key"]}],
                "filters": [],
                "limit": 10,
                "title": f"{primary_m['label']} Share by {dim_secondary}",
            },
        })

    # Tile 6: Exception Action Table (12 columns — "What needs action today?")
    detail_dim = next(
        (f["name"] for f in dataset_fields if "product" in f["name"].lower() or (f["role"] == "dimension" and f["name"] != dim_primary)),
        dim_primary,
    )
    if detail_dim and profit_m:
        exc_measures = [profit_m["metric_key"]]
        if quality_m and quality_m["metric_key"] != profit_m["metric_key"]:
            exc_measures.append(quality_m["metric_key"])
        if primary_m["metric_key"] not in exc_measures:
            exc_measures.insert(0, primary_m["metric_key"])

        tiles.append({
            "id": new_id("tile"),
            "title": f"Exceptions & Lowest {profit_m['label']} by {detail_dim}",
            "col_span": 12,
            "row_height": "md",
            "why_chosen": f"Exception table sorted ascending by '{profit_m['label']}' so loss-making or underperforming '{detail_dim}' items surface first.",
            "spec": {
                "intent": "A4_rank",
                "chart_type": "table",
                "dataset_id": dataset_id,
                "dimensions": [{"field": detail_dim, "sort": {"by": "measure", "dir": "asc"}}],
                "measures": [{"metric": mk} for mk in exc_measures[:3]],
                "filters": [],
                "limit": 15,
                "title": f"Exceptions & Lowest {profit_m['label']} by {detail_dim}",
            },
        })

    filter_fields = []
    if date_col:
        filter_fields.append({"field": date_col, "kind": "date"})
    for lf in low_dims[:2]:
        stats = lf.get("stats") or {}
        vals = [tv["value"] for tv in stats.get("top_values", [])]
        filter_fields.append({"field": lf["name"], "kind": "category", "options": vals})

    row_count = profile.get("row_count", 0)
    subtitle = (
        f"Generated from {dataset_name} (v{dataset_version}, {row_count:,} rows · {profile.get('grain_statement', 'verified grain')})"
    )

    return {
        "title": f"{dataset_name.rsplit('.', 1)[0].replace('_', ' ').title()} — Executive Performance",
        "subtitle": subtitle,
        "dataset_id": dataset_id,
        "dataset_version": dataset_version,
        "grid_columns": 12,
        "global_filter_controls": filter_fields,
        "active_filters": [],
        "tiles": tiles,
        "generated_at": now_iso(),
    }
