"""
Deterministic Insight Detectors & Defensible Seasonal-Naive/MA3 Forecaster (Chapters 12, 21.4 & Phase 8).
Every insight card executes through the single query compiler and carries its query_id, formula,
scope, and verified figures — never approximating when requirements are unmet.
"""
import statistics
from typing import Any, Dict, List
from ..charts.echarts_builder import build_render_bundle, format_metric_value
from ..charts.recommender import recommend_charts
from ..query.compiler import compile_and_execute
from ..query.spec import ChartSpec, DimensionSlot, MeasureSlot, SortSpec


def compute_defensible_forecast(rows: List[Dict[str, Any]], date_key: str, val_key: str, horizon: int = 3) -> Dict[str, Any]:
    """
    Implements Chapter 12.2: 3-period moving average + seasonal-naive (lag 12 when available)
    with holdout MAE/MAPE backtest and explicit uncertainty band.
    """
    clean = [(str(r[date_key]), float(r[val_key])) for r in rows if r.get(date_key) and r.get(val_key) is not None]
    if len(clean) < 6:
        return {"supported": False, "reason": f"Need at least 6 complete time periods for a baseline forecast (found {len(clean)})."}

    vals = [v for _, v in clean]
    # Backtest on last min(3, len//3) periods using trailing-3 moving average
    holdout_n = min(3, len(vals) // 3)
    errors = []
    pct_errors = []
    for idx in range(len(vals) - holdout_n, len(vals)):
        window = vals[max(0, idx - 3) : idx]
        pred = sum(window) / len(window)
        if idx >= 12:
            pred = 0.5 * pred + 0.5 * vals[idx - 12]
        err = abs(vals[idx] - pred)
        errors.append(err)
        if abs(vals[idx]) > 1e-6:
            pct_errors.append(err / abs(vals[idx]))

    mae = round(sum(errors) / len(errors), 2) if errors else 0.0
    mape_pct = round((sum(pct_errors) / len(pct_errors)) * 100.0, 1) if pct_errors else 0.0
    band = max(mae * 1.5, abs(vals[-1]) * 0.08)

    last_label = clean[-1][0]  # e.g. '2026-09-01'
    yr, mo = 2026, 9
    try:
        parts = last_label.split("-")
        yr, mo = int(parts[0]), int(parts[1])
    except Exception:
        pass

    forecast_pts = []
    rolling = list(vals)
    for step in range(1, horizon + 1):
        mo += 1
        if mo > 12:
            mo = 1
            yr += 1
        ma3 = sum(rolling[-3:]) / 3.0
        if len(rolling) >= 12:
            pt = round(0.5 * ma3 + 0.5 * rolling[-12], 2)
        else:
            pt = round(ma3, 2)
        rolling.append(pt)
        forecast_pts.append({
            "period": f"{yr:04d}-{mo:02d}-01",
            "forecast": pt,
            "lower": round(pt - band, 2),
            "upper": round(pt + band, 2),
        })

    return {
        "supported": True,
        "method": "Seasonal-Naive + 3-Period Moving Average Baseline",
        "backtest_mae": mae,
        "backtest_mape_pct": mape_pct,
        "points": forecast_pts,
    }


def detect_mad_anomalies(rows: List[Dict[str, Any]], label_key: str, val_key: str) -> List[Dict[str, Any]]:
    """
    Robust outlier scan using Median and Median Absolute Deviation (MAD) per Chapter 12.3
    so extreme outliers do not distort their own baseline.
    """
    pts = [(str(r[label_key]), float(r[val_key])) for r in rows if r.get(label_key) and r.get(val_key) is not None]
    if len(pts) < 5:
        return []
    vals = [v for _, v in pts]
    med = statistics.median(vals)
    abs_devs = [abs(v - med) for v in vals]
    mad = statistics.median(abs_devs)
    scale = 1.4826 * mad if mad > 1e-9 else (statistics.pstdev(vals) or 1.0)

    flagged = []
    for lbl, v in pts:
        robust_z = (v - med) / scale if scale > 1e-9 else 0.0
        if abs(robust_z) >= 2.0:
            flagged.append({
                "period": lbl,
                "value": round(v, 4),
                "baseline_median": round(med, 4),
                "deviation": round(v - med, 4),
                "robust_z": round(robust_z, 2),
            })
    flagged.sort(key=lambda x: -abs(x["deviation"]))
    return flagged


def execute_insight_plan(
    *,
    dataset_id: str,
    parquet_path: str,
    dataset_version: int,
    profile: Dict[str, Any],
    dataset_fields: List[Dict[str, Any]],
    resolved_metrics: List[Dict[str, Any]],
    user_scope: str,
) -> List[Dict[str, Any]]:
    """
    Runs all executable insight detectors against the real Parquet dataset via `compile_and_execute`
    and returns ranked insight cards with complete 'How this was calculated' provenance.
    """
    cards: List[Dict[str, Any]] = []
    available = [m for m in resolved_metrics if m["available"]]
    additive = [m for m in available if m["kind"] == "additive"]
    low_dims = [f for f in dataset_fields if f["role"] == "dimension" and 2 <= f["distinct_count"] <= 30]
    date_fields = [f for f in dataset_fields if f["role"] == "date"]
    warnings = profile.get("quality_warnings", [])

    # 1. Data quality card FIRST if medium/high warnings exist
    severe = [w for w in warnings if w.get("severity") in ("high", "medium")]
    if severe and available:
        spec = ChartSpec(
            intent="A9_summary",
            chart_type="kpi",
            dataset_id=dataset_id,
            measures=[MeasureSlot(metric=m["metric_key"]) for m in available[:3]],
        )
        qres = compile_and_execute(
            spec=spec,
            parquet_path=parquet_path,
            dataset_version=dataset_version,
            dataset_fields=dataset_fields,
            resolved_metrics=resolved_metrics,
            user_scope=user_scope,
        )
        w0 = severe[0]
        cards.append({
            "id": "ins_quality",
            "category": "Data Quality Risk",
            "headline_figure": f"{w0['count']} rows ({w0['rate'] * 100:.1f}%)",
            "title": f"Data quality check: {w0['column']}",
            "interpretation": f"Observed: {w0['message']} Review completeness before committing budget decisions.",
            "query_id": qres["query_id"],
            "how_calculated": {
                "formula": "COUNT(*) FILTER (WHERE col IS NULL) / COUNT(*)",
                "fields": [w0["column"]],
                "filters": ["all records"],
                "dataset_version": dataset_version,
                "sql_hash": qres["sql_hash"],
            },
            "render": build_render_bundle(chart_type="kpi", spec_dict=spec.model_dump(), query_result=qres),
        })

    # 2. Top & Bottom Performer Concentration
    if additive and low_dims:
        m0 = additive[0]
        d0 = low_dims[0]
        spec = ChartSpec(
            intent="A1_compare",
            chart_type="bar_h",
            dataset_id=dataset_id,
            dimensions=[DimensionSlot(field=d0["name"], sort=SortSpec(by="measure", dir="desc"))],
            measures=[MeasureSlot(metric=m0["metric_key"])],
            limit=10,
        )
        qres = compile_and_execute(
            spec=spec,
            parquet_path=parquet_path,
            dataset_version=dataset_version,
            dataset_fields=dataset_fields,
            resolved_metrics=resolved_metrics,
            user_scope=user_scope,
        )
        rows = qres["rows"]
        if rows:
            vals = [float(r[m0["metric_key"]] or 0.0) for r in rows]
            tot = sum(vals) or 1.0
            top_share = round((vals[0] / tot) * 100.0, 1)
            rec = recommend_charts(
                intent="A1_compare",
                has_date=bool(date_fields),
                distinct_categories=d0["distinct_count"],
                has_negative_values=any(v < 0 for v in vals),
                row_count=profile["row_count"],
            )
            cards.append({
                "id": "ins_concentration",
                "category": "Concentration & Ranking",
                "headline_figure": f"{rows[0][d0['name']]} ({top_share}%)",
                "title": f"{m0['label']} concentration by {d0['name']}",
                "interpretation": (
                    f"Observed: {rows[0][d0['name']]} generates {format_metric_value(vals[0], m0['format'])} "
                    f"({top_share}% of visible {m0['label']}), while {rows[-1][d0['name']]} contributes "
                    f"{format_metric_value(vals[-1], m0['format'])}."
                ),
                "query_id": qres["query_id"],
                "how_calculated": {
                    "formula": m0["formula_display"],
                    "fields": [d0["name"], m0["bound"].get("field", m0["metric_key"])],
                    "filters": qres["applied_filters"] or ["all records"],
                    "dataset_version": dataset_version,
                    "sql_hash": qres["sql_hash"],
                },
                "render": build_render_bundle(chart_type="bar_h", spec_dict=spec.model_dump(), query_result=qres, recommender_info=rec),
            })

    # 3. Margin / Rate Variance & Laggards
    margin_m = next((m for m in available if m["metric_key"] == "profit_margin"), None)
    if margin_m and low_dims:
        dim_choice = low_dims[1] if len(low_dims) > 1 else low_dims[0]
        spec = ChartSpec(
            intent="A1_compare",
            chart_type="bar_h",
            dataset_id=dataset_id,
            dimensions=[DimensionSlot(field=dim_choice["name"], sort=SortSpec(by="measure", dir="asc"))],
            measures=[MeasureSlot(metric="profit_margin")],
            limit=10,
        )
        qres = compile_and_execute(
            spec=spec,
            parquet_path=parquet_path,
            dataset_version=dataset_version,
            dataset_fields=dataset_fields,
            resolved_metrics=resolved_metrics,
            user_scope=user_scope,
        )
        rows = qres["rows"]
        if rows and rows[0].get("profit_margin") is not None:
            worst = rows[0]
            best = rows[-1]
            w_fmt = format_metric_value(worst["profit_margin"], margin_m["format"])
            b_fmt = format_metric_value(best["profit_margin"], margin_m["format"])
            cards.append({
                "id": "ins_margin_gap",
                "category": "Margin Laggard",
                "headline_figure": f"{worst[dim_choice['name']]}: {w_fmt}",
                "title": f"Lowest Profit Margin in {dim_choice['name']}",
                "interpretation": (
                    f"Observed: {worst[dim_choice['name']]} has the lowest Profit Margin at {w_fmt} "
                    f"compared with {best[dim_choice['name']]} at {b_fmt} (computed as SUM(profit)/SUM(sales))."
                ),
                "query_id": qres["query_id"],
                "how_calculated": {
                    "formula": margin_m["formula_display"],
                    "fields": [dim_choice["name"], margin_m["bound"]["num_field"], margin_m["bound"]["den_field"]],
                    "filters": qres["applied_filters"] or ["all records"],
                    "dataset_version": dataset_version,
                    "sql_hash": qres["sql_hash"],
                },
                "render": build_render_bundle(chart_type="bar_h", spec_dict=spec.model_dump(), query_result=qres),
            })

    # 4. Time Trend & Robust MAD Outlier Detection
    if date_fields and available:
        df0 = date_fields[0]
        m0 = margin_m or available[0]
        spec = ChartSpec(
            intent="A2_trend",
            chart_type="line",
            dataset_id=dataset_id,
            dimensions=[DimensionSlot(field=df0["name"], grain="month", sort=SortSpec(by="dimension", dir="asc"))],
            measures=[MeasureSlot(metric=m0["metric_key"])],
            limit=60,
        )
        qres = compile_and_execute(
            spec=spec,
            parquet_path=parquet_path,
            dataset_version=dataset_version,
            dataset_fields=dataset_fields,
            resolved_metrics=resolved_metrics,
            user_scope=user_scope,
        )
        rows = qres["rows"]
        if len(rows) >= 2:
            anomalies = detect_mad_anomalies(rows, df0["name"], m0["metric_key"])
            first_v = format_metric_value(rows[0].get(m0["metric_key"]), m0["format"])
            last_v = format_metric_value(rows[-1].get(m0["metric_key"]), m0["format"])
            anom_note = (
                f" Robust median/MAD scan flagged {len(anomalies)} unusual period(s), led by {anomalies[0]['period']}."
                if anomalies
                else " No extreme median/MAD outliers exceeded the 2.0 threshold."
            )
            cards.append({
                "id": "ins_trend_anomaly",
                "category": "Trend & Outliers",
                "headline_figure": f"{first_v} → {last_v}",
                "title": f"Monthly {m0['label']} trajectory",
                "interpretation": (
                    f"Observed across {len(rows)} months: {m0['label']} moved from {first_v} ({rows[0][df0['name']]}) "
                    f"to {last_v} ({rows[-1][df0['name']]}).{anom_note}"
                ),
                "query_id": qres["query_id"],
                "how_calculated": {
                    "formula": f"{m0['formula_display']} grouped by DATE_TRUNC('month', {df0['name']})",
                    "fields": [df0["name"], m0["metric_key"]],
                    "filters": qres["applied_filters"] or ["all records"],
                    "dataset_version": dataset_version,
                    "sql_hash": qres["sql_hash"],
                },
                "render": build_render_bundle(chart_type="line", spec_dict=spec.model_dump(), query_result=qres),
            })

    return cards
