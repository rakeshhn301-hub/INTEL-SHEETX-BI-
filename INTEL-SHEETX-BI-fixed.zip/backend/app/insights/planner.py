"""
Schema-Aware Analysis Planner & Data Brief Generator (Chapter 21 & Phase 8).
Evaluates candidate analytical questions strictly against the dataset's actual fields,
cardinality, row count, and quality profile — dropping unmet candidates and explaining what
the dataset can and cannot answer.
"""
from typing import Any, Dict, List


def generate_analysis_brief(
    *,
    dataset_id: str,
    dataset_name: str,
    dataset_version: int,
    profile: Dict[str, Any],
    dataset_fields: List[Dict[str, Any]],
    resolved_metrics: List[Dict[str, Any]],
) -> Dict[str, Any]:
    row_count = int(profile.get("row_count", 0))
    col_count = int(profile.get("column_count", len(dataset_fields)))
    warnings = profile.get("quality_warnings", [])

    date_fields = [f for f in dataset_fields if f["role"] == "date"]
    low_card_dims = [f for f in dataset_fields if f["role"] == "dimension" and 2 <= f["distinct_count"] <= 30]
    high_card_dims = [f for f in dataset_fields if f["role"] in ("dimension", "detail") and f["distinct_count"] > 30]
    id_fields = [f for f in dataset_fields if f["role"] == "identifier" and f["semantic_type"] == "identifier"]
    available_metrics = [m for m in resolved_metrics if m["available"]]
    additive_metrics = [m for m in available_metrics if m["kind"] == "additive"]

    has_margin = any(m["metric_key"] == "profit_margin" for m in available_metrics)
    has_discount = any(m["metric_key"] == "discount_rate" for m in available_metrics) or any("discount" in f["name"].lower() for f in dataset_fields)
    has_target = any("target" in f["name"].lower() or "budget" in f["name"].lower() for f in dataset_fields)
    has_customer = any("customer" in f["name"].lower() for f in id_fields)

    # Check negative values in profit/measure columns
    neg_cols = [
        c for c in profile.get("columns", [])
        if (c.get("stats") or {}).get("negative_count", 0) > 0 and c["role"] == "measure"
    ]
    severe_quality = [w for w in warnings if w.get("severity") in ("high", "medium")]

    can_answer: List[Dict[str, Any]] = []
    cannot_answer: List[Dict[str, str]] = []

    # 1. Severe data quality review rises to #1 when high null/duplicate/parse errors exist (Table 21.1 & Phase 8 Gate)
    if severe_quality:
        can_answer.append({
            "id": "plan_quality",
            "rank_score": 98,
            "title": "Data quality & completeness risks before decision-making",
            "why_supported": f"{len(severe_quality)} medium/high quality flags detected ({severe_quality[0]['message']})",
            "detector": "quality_risks",
            "command": "how are we doing this quarter",
        })

    # 2. Loss-making / negative profit concentration
    if neg_cols and low_card_dims:
        nc = neg_cols[0]
        neg_n = nc["stats"]["negative_count"]
        can_answer.append({
            "id": "plan_losses",
            "rank_score": 94,
            "title": f"Where negative {nc['name']} / loss-making records are concentrated",
            "why_supported": f"{neg_n} records have {nc['name']} < 0 across {low_card_dims[0]['name']}",
            "detector": "loss_concentration",
            "command": f"compare {nc['name']} by {low_card_dims[0]['name']}",
        })

    # 3. Margin breakdown across segments
    if has_margin and low_card_dims:
        d0 = low_card_dims[0]
        can_answer.append({
            "id": "plan_margin_by_dim",
            "rank_score": 90,
            "title": f"Which {d0['name']} segments drive Profit Margin variation",
            "why_supported": f"Profit + Sales columns and {d0['distinct_count']}-value '{d0['name']}' dimension present",
            "detector": "margin_variance",
            "command": f"compare profit margin by {d0['name']}",
        })

    # 4. Primary additive measure comparison & concentration
    if additive_metrics and low_card_dims:
        m0 = additive_metrics[0]
        d0 = low_card_dims[0]
        can_answer.append({
            "id": "plan_compare_primary",
            "rank_score": 86,
            "title": f"How {m0['label']} compares and concentrates across {d0['name']}",
            "why_supported": f"Additive metric '{m0['label']}' + '{d0['name']}' ({d0['distinct_count']} distinct categories)",
            "detector": "top_bottom_concentration",
            "command": f"compare {m0['label'].lower()} by {d0['name'].lower()}",
        })

    # 5. Time-series trend & anomaly scan (ONLY when a real date column exists!)
    if date_fields and available_metrics:
        df0 = date_fields[0]
        m0 = available_metrics[0]
        d_stats = next((c.get("stats", {}) for c in profile.get("columns", []) if c["name"] == df0["name"]), {})
        span = f"{d_stats.get('min', '?')} to {d_stats.get('max', '?')}"
        can_answer.append({
            "id": "plan_trend",
            "rank_score": 84,
            "title": f"How {m0['label']} has trended over time and where anomalies occurred",
            "why_supported": f"Valid date column '{df0['name']}' ({span}) + metric '{m0['label']}'",
            "detector": "time_trend_anomalies",
            "command": f"{m0['label'].lower()} trend by month",
        })
    else:
        cannot_answer.append({
            "topic": "Time-series trends, YoY growth, or forecasting",
            "missing_input": "No valid date/timestamp column is present in this dataset.",
        })

    # 6. Discount vs Profit association
    if has_discount and any(m["metric_key"] == "total_profit" for m in available_metrics):
        can_answer.append({
            "id": "plan_discount_profit",
            "rank_score": 79,
            "title": "Whether Discount Rate is associated with Profit Margin pressure",
            "why_supported": "Both discount and profit measures exist at shared record grain",
            "detector": "discount_association",
            "command": "does discount affect profit",
        })

    # 7. Distribution spread (ONLY when row_count >= 30!)
    if row_count >= 30 and additive_metrics:
        m0 = additive_metrics[0]
        can_answer.append({
            "id": "plan_distribution",
            "rank_score": 70,
            "title": f"Spread and skewness of {m0['label']} values",
            "why_supported": f"{row_count:,} rows (>= 30 minimum) + numeric measure '{m0['label']}'",
            "detector": "distribution_spread",
            "command": f"spread of {m0['label'].lower()}",
        })
    elif row_count < 30:
        cannot_answer.append({
            "topic": "Statistical distribution / histogram / clustering",
            "missing_input": f"Dataset has only {row_count} rows (minimum 30 required for reliable binning).",
        })

    # Explicit 'What it cannot answer' disclosures (Chapter 21.3)
    if not has_customer:
        cannot_answer.append({
            "topic": "Customer cohort retention or repeat-buyer lifetime value",
            "missing_input": "No customer identifier column (e.g. customer_id) present.",
        })
    if not has_target:
        cannot_answer.append({
            "topic": "Plan / budget variance (Actual vs Target)",
            "missing_input": "No target or budget column present in the uploaded file.",
        })
    if high_card_dims and not low_card_dims:
        cannot_answer.append({
            "topic": "Whole-population pie/donut composition",
            "missing_input": f"Dimensions have high cardinality ({high_card_dims[0]['distinct_count']} values); use Top-N bars or tables.",
        })
    cannot_answer.append({
        "topic": "Causal proof (e.g. proving a lever caused an outcome)",
        "missing_input": "Observational transaction data supports association only; causal claims require a controlled experiment.",
    })

    can_answer.sort(key=lambda x: -x["rank_score"])

    date_span_note = ""
    if date_fields:
        ds0 = next((c.get("stats", {}) for c in profile.get("columns", []) if c["name"] == date_fields[0]["name"]), {})
        if ds0.get("min") and ds0.get("max"):
            date_span_note = f", spanning {ds0['min']} to {ds0['max']}"

    return {
        "dataset_id": dataset_id,
        "dataset_name": dataset_name,
        "dataset_version": dataset_version,
        "row_count": row_count,
        "column_count": col_count,
        "what_this_data_is": (
            f"{profile.get('grain_statement', f'{row_count:,} records')}{date_span_note}, "
            f"with {len(low_card_dims)} groupable dimensions and {len(available_metrics)} verified metrics."
        ),
        "can_answer": can_answer,
        "cannot_answer": cannot_answer,
    }
