"""Insights, schema-aware planner, detectors, forecaster, and auto-dashboard generator."""
