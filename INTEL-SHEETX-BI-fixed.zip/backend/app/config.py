"""
Server-side configuration module (Chapter 36.1 & Appendix D).
Reads environment variables with sensible local defaults and validates required paths/secrets.
"""
import os
from dataclasses import dataclass

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass(frozen=True)
class Settings:
    database_path: str
    storage_dir: str
    parquet_dir: str
    fixtures_dir: str
    session_secret: str
    app_url: str

    ai_provider: str
    ai_api_key: str
    ai_base_url: str
    ai_model_parse: str
    ai_model_narrate: str
    ai_max_tokens_per_run: int
    ai_max_calls_per_run: int
    ai_timeout_ms: int

    max_upload_mb: int
    max_rows_preview: int
    max_result_rows: int
    max_distinct_categories: int
    query_timeout_ms: int
    max_concurrent_queries_per_user: int
    clarification_margin: float
    row_scan_warn_threshold: int

    enable_agent: bool
    enable_forecast: bool
    enable_scheduling: bool
    enable_signup: bool


def load_settings() -> Settings:
    db_path = os.environ.get("DATABASE_PATH", os.path.join(ROOT_DIR, "data", "metadata.db"))
    storage_dir = os.environ.get("STORAGE_DIR", os.path.join(ROOT_DIR, "data", "storage"))
    parquet_dir = os.environ.get("PARQUET_DIR", os.path.join(ROOT_DIR, "data", "parquet"))
    fixtures_dir = os.environ.get("FIXTURES_DIR", os.path.join(ROOT_DIR, "tests", "fixtures"))
    session_secret = os.environ.get(
        "SESSION_SECRET", "intelsheetx-local-dev-secret-key-32-bytes-minimum-2026"
    )
    if len(session_secret) < 16:
        raise RuntimeError("SESSION_SECRET must be at least 16 characters long.")

    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    os.makedirs(storage_dir, exist_ok=True)
    os.makedirs(parquet_dir, exist_ok=True)

    return Settings(
        database_path=db_path,
        storage_dir=storage_dir,
        parquet_dir=parquet_dir,
        fixtures_dir=fixtures_dir,
        session_secret=session_secret,
        app_url=os.environ.get("APP_URL", "http://0.0.0.0:5173"),
        ai_provider=os.environ.get("AI_PROVIDER", "none").lower(),
        ai_api_key=os.environ.get("AI_API_KEY", ""),
        ai_base_url=os.environ.get("AI_BASE_URL", "https://api.openai.com/v1"),
        ai_model_parse=os.environ.get("AI_MODEL_PARSE", "gpt-4.1-mini"),
        ai_model_narrate=os.environ.get("AI_MODEL_NARRATE", "gpt-4.1"),
        ai_max_tokens_per_run=int(os.environ.get("AI_MAX_TOKENS_PER_RUN", "20000")),
        ai_max_calls_per_run=int(os.environ.get("AI_MAX_CALLS_PER_RUN", "25")),
        ai_timeout_ms=int(os.environ.get("AI_TIMEOUT_MS", "30000")),
        max_upload_mb=int(os.environ.get("MAX_UPLOAD_MB", "200")),
        max_rows_preview=int(os.environ.get("MAX_ROWS_PREVIEW", "100")),
        max_result_rows=int(os.environ.get("MAX_RESULT_ROWS", "5000")),
        max_distinct_categories=int(os.environ.get("MAX_DISTINCT_CATEGORIES", "50")),
        query_timeout_ms=int(os.environ.get("QUERY_TIMEOUT_MS", "10000")),
        max_concurrent_queries_per_user=int(os.environ.get("MAX_CONCURRENT_QUERIES_PER_USER", "3")),
        clarification_margin=float(os.environ.get("CLARIFICATION_MARGIN", "0.10")),
        row_scan_warn_threshold=int(os.environ.get("ROW_SCAN_WARN_THRESHOLD", "5000000")),
        enable_agent=os.environ.get("ENABLE_AGENT", "true").lower() == "true",
        enable_forecast=os.environ.get("ENABLE_FORECAST", "true").lower() == "true",
        enable_scheduling=os.environ.get("ENABLE_SCHEDULING", "true").lower() == "true",
        enable_signup=os.environ.get("ENABLE_SIGNUP", "true").lower() == "true",
    )


settings = load_settings()
