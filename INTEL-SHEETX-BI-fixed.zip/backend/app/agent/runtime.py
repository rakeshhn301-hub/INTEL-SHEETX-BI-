"""
Stateful 12-Tool Agentic Runtime with Budgets, Confirmation Gates & Provenance Binding (Chapters 22 & 32).
Implements the complete tool belt from Table 22.1, enforces query/time/token caps, refuses
adversarial/SQL-injection goals, gates notable/external/destructive writes behind explicit user
confirmation, and verifies every numeric figure in the final memo against executed EvidenceBundles.
"""
import json
import re
import time
from typing import Any, Dict, List
from ..charts.echarts_builder import format_metric_value
from ..charts.recommender import recommend_charts
from ..config import settings
from ..db import new_id, now_iso
from ..insights.dashboard_gen import generate_dashboard_blueprint
from ..insights.detectors import compute_defensible_forecast, detect_mad_anomalies
from ..nlp.parser import ADVERSARIAL_PATTERNS
from ..nlp.provenance import build_evidence_bundle, verify_narrative_numbers
from ..query.compiler import compile_and_execute
from ..query.spec import ChartSpec, DimensionSlot, FilterClause, MeasureSlot, SortSpec

# Canonical 12-Tool Registry (Table 22.1 & Table 32.1)
TOOL_REGISTRY: Dict[str, Dict[str, Any]] = {
    "inspect_schema": {"action_class": "read_only", "mutates": False, "requires_confirmation": False, "cost": 1},
    "profile_column": {"action_class": "read_only", "mutates": False, "requires_confirmation": False, "cost": 1},
    "run_query": {"action_class": "read_only", "mutates": False, "requires_confirmation": False, "cost": 2},
    "compute_metric": {"action_class": "read_only", "mutates": False, "requires_confirmation": False, "cost": 1},
    "recommend_charts": {"action_class": "read_only", "mutates": False, "requires_confirmation": False, "cost": 1},
    "create_chart": {"action_class": "reversible_write", "mutates": True, "requires_confirmation": False, "cost": 1},
    "detect_anomalies": {"action_class": "read_only", "mutates": False, "requires_confirmation": False, "cost": 2},
    "forecast": {"action_class": "read_only", "mutates": False, "requires_confirmation": False, "cost": 2},
    "build_dashboard": {"action_class": "notable_write", "mutates": True, "requires_confirmation": True, "cost": 2},
    "export": {"action_class": "external_effect", "mutates": False, "requires_confirmation": True, "cost": 1},
    "schedule_digest": {"action_class": "external_effect", "mutates": True, "requires_confirmation": True, "cost": 1},
    "delete_dataset": {"action_class": "destructive", "mutates": True, "requires_confirmation": True, "cost": 1},
}


def run_agent_investigation(
    *,
    goal: str,
    dataset: Dict[str, Any],
    parquet_path: str,
    profile: Dict[str, Any],
    dataset_fields: List[Dict[str, Any]],
    resolved_metrics: List[Dict[str, Any]],
    user_scope: str,
    max_queries: int = None,
    max_seconds: float = 45.0,
) -> Dict[str, Any]:
    t0 = time.perf_counter()
    q_cap = max_queries if max_queries is not None else min(settings.ai_max_calls_per_run, 25)
    queries_used = 0
    steps_log: List[Dict[str, Any]] = []
    evidence_bundles: List[Dict[str, Any]] = []
    pending_confirmations: List[Dict[str, Any]] = []

    goal_clean = (goal or "").strip()
    if ADVERSARIAL_PATTERNS.search(goal_clean):
        return {
            "status": "refused",
            "goal": goal_clean,
            "plan": [],
            "steps": [],
            "evidence_bundles": [],
            "pending_confirmations": [],
            "narrative": "Refused: Agentic runtime forbids raw SQL, cross-tenant data access, and instruction-override prompts.",
            "budgets": {"queries_used": 0, "max_queries": q_cap, "duration_ms": 1, "provider_mode": settings.ai_provider},
        }

    goal_l = goal_clean.lower()

    # Check if user asked for a gated action (delete, schedule digest, export, publish dashboard)
    if re.search(r"\bdelete\b.*\b(dataset|file|data)\b", goal_l):
        pending_confirmations.append({
            "tool": "delete_dataset",
            "action_class": "destructive",
            "artefact_name": dataset["name"],
            "confirmation_type": "typed_name",
            "message": f"Destructive action gated: type '{dataset['name']}' in Dataset Settings to permanently delete this dataset.",
        })
    if re.search(r"\b(schedule|send|email)\b.*\b(digest|report)\b", goal_l):
        pending_confirmations.append({
            "tool": "schedule_digest",
            "action_class": "external_effect",
            "artefact_name": f"Weekly Digest for {dataset['name']}",
            "confirmation_type": "click_confirm",
            "message": "External delivery gated: review recipient list and confirm in Delivery & Digests.",
        })
    if re.search(r"\b(build|generate|publish)\s+(a\s+)?dashboard\b", goal_l):
        bp = generate_dashboard_blueprint(
            dataset_id=dataset["id"],
            dataset_name=dataset["name"],
            dataset_version=dataset["current_version"],
            profile=profile,
            dataset_fields=dataset_fields,
            resolved_metrics=resolved_metrics,
        )
        pending_confirmations.append({
            "tool": "build_dashboard",
            "action_class": "notable_write",
            "artefact_name": bp["title"],
            "confirmation_type": "click_confirm",
            "message": f"Ready to save 6-tile dashboard '{bp['title']}'. Confirm to create dashboard in project.",
        })

    available = [m for m in resolved_metrics if m["available"]]
    if not available:
        return {
            "status": "insufficient_data",
            "goal": goal_clean,
            "plan": ["inspect_schema"],
            "steps": [{"step": 1, "tool": "inspect_schema", "summary": "No executable numeric metrics found in dataset."}],
            "evidence_bundles": [],
            "pending_confirmations": pending_confirmations,
            "narrative": "Insufficient data: this dataset has no summable numeric measures or countable identifiers to investigate.",
            "budgets": {"queries_used": 0, "max_queries": q_cap, "duration_ms": 2, "provider_mode": settings.ai_provider},
        }

    # Build multi-step plan (Chapter 22.3: inspect_schema -> headline metric -> breakdown -> drill worst segment -> anomaly/forecast)
    has_margin = any(m["metric_key"] == "profit_margin" for m in available)
    focus_m = next(
        (m for m in available if m["metric_key"] == ("profit_margin" if ("margin" in goal_l and has_margin) else "total_sales")),
        available[0],
    )
    low_dims = [f for f in dataset_fields if f["role"] == "dimension" and 2 <= f["distinct_count"] <= 30]
    date_fields = [f for f in dataset_fields if f["role"] == "date"]

    planned_tools = ["inspect_schema", "compute_metric"]
    if low_dims:
        planned_tools.append("run_query")
    if len(low_dims) >= 2:
        planned_tools.append("run_query")  # Revise & drill into worst/leading segment!
    if date_fields:
        planned_tools.append("detect_anomalies")
    if "forecast" in goal_l and date_fields:
        planned_tools.append("forecast")
    planned_tools.append("recommend_charts")

    def _over_budget() -> bool:
        return queries_used >= q_cap or (time.perf_counter() - t0) >= max_seconds

    # Step 1: inspect_schema (safe to auto-run, excludes sensitive/PII columns)
    safe_fields = [f["name"] for f in dataset_fields if not f.get("exclude_from_ai")]
    steps_log.append({
        "step": len(steps_log) + 1,
        "tool": "inspect_schema",
        "action_class": TOOL_REGISTRY["inspect_schema"]["action_class"],
        "args": {"dataset_id": dataset["id"]},
        "summary": f"Inspected {len(safe_fields)} AI-permitted columns and {len(available)} available metrics (v{dataset['current_version']}).",
        "query_id": None,
    })

    if _over_budget():
        return _budget_stop(goal_clean, planned_tools, steps_log, evidence_bundles, pending_confirmations, queries_used, q_cap, t0)

    # Step 2: compute_metric (overall headline baseline)
    headline_spec = ChartSpec(
        intent="A9_summary",
        chart_type="kpi",
        dataset_id=dataset["id"],
        measures=[MeasureSlot(metric=focus_m["metric_key"])],
    )
    q_head = compile_and_execute(
        spec=headline_spec,
        parquet_path=parquet_path,
        dataset_version=dataset["current_version"],
        dataset_fields=dataset_fields,
        resolved_metrics=resolved_metrics,
        user_scope=user_scope,
    )
    queries_used += 1
    eb_head = build_evidence_bundle(
        query_result=q_head,
        dataset_name=dataset["name"],
        total_dataset_rows=profile["row_count"],
        quality_warnings=profile.get("quality_warnings", []),
    )
    evidence_bundles.append(eb_head)
    head_val = q_head["rows"][0].get(focus_m["metric_key"]) if q_head["rows"] else None
    steps_log.append({
        "step": len(steps_log) + 1,
        "tool": "compute_metric",
        "action_class": "read_only",
        "args": {"metric": focus_m["metric_key"]},
        "summary": f"Computed group {focus_m['label']} = {format_metric_value(head_val, focus_m['format'])}.",
        "query_id": q_head["query_id"],
    })

    worst_segment_name = None
    worst_segment_val = None
    dim1_name = None
    drill_top_name = None
    drill_top_val = None
    dim2_name = None

    # Step 3: run_query across primary dimension
    if low_dims and not _over_budget():
        dim1_name = low_dims[0]["name"]
        sort_dir = "asc" if focus_m["metric_key"] == "profit_margin" else "desc"
        seg_spec = ChartSpec(
            intent="A1_compare",
            chart_type="bar_h",
            dataset_id=dataset["id"],
            dimensions=[DimensionSlot(field=dim1_name, sort=SortSpec(by="measure", dir=sort_dir))],
            measures=[MeasureSlot(metric=focus_m["metric_key"])],
            limit=10,
        )
        q_seg = compile_and_execute(
            spec=seg_spec,
            parquet_path=parquet_path,
            dataset_version=dataset["current_version"],
            dataset_fields=dataset_fields,
            resolved_metrics=resolved_metrics,
            user_scope=user_scope,
        )
        queries_used += 1
        eb_seg = build_evidence_bundle(
            query_result=q_seg,
            dataset_name=dataset["name"],
            total_dataset_rows=profile["row_count"],
            quality_warnings=profile.get("quality_warnings", []),
        )
        evidence_bundles.append(eb_seg)
        if q_seg["rows"]:
            worst_segment_name = str(q_seg["rows"][0][dim1_name])
            worst_segment_val = q_seg["rows"][0].get(focus_m["metric_key"])
            steps_log.append({
                "step": len(steps_log) + 1,
                "tool": "run_query",
                "action_class": "read_only",
                "args": {"dimension": dim1_name, "metric": focus_m["metric_key"]},
                "summary": (
                    f"Grouped {focus_m['label']} by {dim1_name}; top focus segment is '{worst_segment_name}' "
                    f"at {format_metric_value(worst_segment_val, focus_m['format'])}. Revising plan to drill into '{worst_segment_name}'."
                ),
                "query_id": q_seg["query_id"],
            })

    # Step 4: Plan revision -> drill into focus segment across secondary dimension (e.g. product/division)
    if len(low_dims) >= 2 and worst_segment_name and not _over_budget():
        dim2_name = low_dims[1]["name"]
        drill_spec = ChartSpec(
            intent="A10_explain",
            chart_type="bar_h",
            dataset_id=dataset["id"],
            dimensions=[DimensionSlot(field=dim2_name, sort=SortSpec(by="measure", dir="asc" if focus_m["metric_key"] == "profit_margin" else "desc"))],
            measures=[MeasureSlot(metric=focus_m["metric_key"])],
            filters=[FilterClause(field=dim1_name, op="=", value=worst_segment_name)],
            limit=8,
        )
        q_drill = compile_and_execute(
            spec=drill_spec,
            parquet_path=parquet_path,
            dataset_version=dataset["current_version"],
            dataset_fields=dataset_fields,
            resolved_metrics=resolved_metrics,
            user_scope=user_scope,
        )
        queries_used += 1
        eb_drill = build_evidence_bundle(
            query_result=q_drill,
            dataset_name=dataset["name"],
            total_dataset_rows=profile["row_count"],
            quality_warnings=profile.get("quality_warnings", []),
        )
        evidence_bundles.append(eb_drill)
        if q_drill["rows"]:
            drill_top_name = str(q_drill["rows"][0][dim2_name])
            drill_top_val = q_drill["rows"][0].get(focus_m["metric_key"])
            steps_log.append({
                "step": len(steps_log) + 1,
                "tool": "run_query",
                "action_class": "read_only",
                "args": {"dimension": dim2_name, "filter": f"{dim1_name}={worst_segment_name}", "metric": focus_m["metric_key"]},
                "summary": (
                    f"Drilled into {dim1_name}='{worst_segment_name}' by {dim2_name}: '{drill_top_name}' stands at "
                    f"{format_metric_value(drill_top_val, focus_m['format'])}."
                ),
                "query_id": q_drill["query_id"],
            })

    # Step 5: Time-series anomaly & optional forecast
    anomaly_count = 0
    if date_fields and not _over_budget():
        df0 = date_fields[0]["name"]
        ts_spec = ChartSpec(
            intent="A2_trend",
            chart_type="line",
            dataset_id=dataset["id"],
            dimensions=[DimensionSlot(field=df0, grain="month", sort=SortSpec(by="dimension", dir="asc"))],
            measures=[MeasureSlot(metric=focus_m["metric_key"])],
            limit=60,
        )
        q_ts = compile_and_execute(
            spec=ts_spec,
            parquet_path=parquet_path,
            dataset_version=dataset["current_version"],
            dataset_fields=dataset_fields,
            resolved_metrics=resolved_metrics,
            user_scope=user_scope,
        )
        queries_used += 1
        anoms = detect_mad_anomalies(q_ts["rows"], df0, focus_m["metric_key"])
        anomaly_count = len(anoms)
        eb_ts = build_evidence_bundle(
            query_result=q_ts,
            dataset_name=dataset["name"],
            total_dataset_rows=profile["row_count"],
            quality_warnings=profile.get("quality_warnings", []),
        )
        eb_ts["derived"]["anomaly_count"] = anomaly_count
        evidence_bundles.append(eb_ts)
        steps_log.append({
            "step": len(steps_log) + 1,
            "tool": "detect_anomalies",
            "action_class": "read_only",
            "args": {"measure": focus_m["metric_key"], "date_field": df0},
            "summary": f"Ran median/MAD anomaly scan across {len(q_ts['rows'])} months; flagged {anomaly_count} unusual period(s).",
            "query_id": q_ts["query_id"],
        })

        if "forecast" in goal_l:
            fc = compute_defensible_forecast(q_ts["rows"], df0, focus_m["metric_key"], horizon=3)
            steps_log.append({
                "step": len(steps_log) + 1,
                "tool": "forecast",
                "action_class": "read_only",
                "args": {"measure": focus_m["metric_key"], "horizon": 3},
                "summary": (
                    f"Generated 3-period {fc['method']} estimate (backtest MAPE {fc['backtest_mape_pct']}%) — labelled strictly as projection."
                    if fc.get("supported")
                    else fc.get("reason", "Insufficient history for forecast.")
                ),
                "query_id": q_ts["query_id"],
            })

    # Step 6: recommend_charts
    rec = recommend_charts(
        intent="A1_compare",
        has_date=bool(date_fields),
        distinct_categories=low_dims[0]["distinct_count"] if low_dims else 0,
        has_negative_values=False,
        row_count=profile["row_count"],
    )
    steps_log.append({
        "step": len(steps_log) + 1,
        "tool": "recommend_charts",
        "action_class": "read_only",
        "args": {"intent": "A1_compare"},
        "summary": f"Recommended '{rec['selected']}' ({rec['reason']}).",
        "query_id": None,
    })

    # Compose combined EvidenceBundle and strictly verify every number in the memo!
    combined_bundle = {
        "dataset": {"name": dataset["name"], "version": dataset["current_version"], "rows": profile["row_count"]},
        "queries_executed": queries_used,
        "anomaly_count": anomaly_count,
        "bundles": evidence_bundles,
    }

    memo_parts = [
        f"Scope: {dataset['name']} v{dataset['current_version']} ({profile['row_count']} rows; {queries_used} deterministic queries executed)."
    ]
    if head_val is not None:
        memo_parts.append(f"Observed: Overall {focus_m['label']} is {format_metric_value(head_val, focus_m['format'])}.")
    if worst_segment_name and worst_segment_val is not None:
        memo_parts.append(
            f"Across {dim1_name}, {worst_segment_name} stands at {format_metric_value(worst_segment_val, focus_m['format'])}."
        )
    if drill_top_name and drill_top_val is not None:
        memo_parts.append(
            f"Within {worst_segment_name}, {dim2_name} '{drill_top_name}' records {format_metric_value(drill_top_val, focus_m['format'])}."
        )
    if date_fields:
        memo_parts.append(f"Monthly anomaly scan flagged {anomaly_count} outlier period(s) against the trailing median/MAD baseline.")
    memo_parts.append(
        "This suggests operational review should prioritise the identified segment and sub-segment; observational data indicates association, not causation."
    )
    if profile.get("quality_warnings"):
        w0 = profile["quality_warnings"][0]
        memo_parts.append(f"Caveat: {w0['message']}")

    narrative = " ".join(memo_parts)
    verified_ok, bad_nums = verify_narrative_numbers(narrative, combined_bundle)

    duration_ms = max(1, int((time.perf_counter() - t0) * 1000))
    return {
        "status": "completed",
        "goal": goal_clean,
        "plan": planned_tools,
        "steps": steps_log,
        "evidence_bundles": evidence_bundles,
        "pending_confirmations": pending_confirmations,
        "narrative": narrative,
        "provenance_verified": verified_ok,
        "rejected_figures": bad_nums,
        "budgets": {
            "queries_used": queries_used,
            "max_queries": q_cap,
            "duration_ms": duration_ms,
            "provider_mode": settings.ai_provider if settings.ai_api_key else "deterministic_fallback",
        },
    }


def _budget_stop(goal, plan, steps, bundles, confirmations, queries_used, q_cap, t0) -> Dict[str, Any]:
    return {
        "status": "partial_budget_exhausted",
        "goal": goal,
        "plan": plan,
        "steps": steps,
        "evidence_bundles": bundles,
        "pending_confirmations": confirmations,
        "narrative": f"Budget cap reached cleanly after {queries_used} of {q_cap} permitted queries. Partial verified results are preserved above.",
        "provenance_verified": True,
        "rejected_figures": [],
        "budgets": {
            "queries_used": queries_used,
            "max_queries": q_cap,
            "duration_ms": max(1, int((time.perf_counter() - t0) * 1000)),
            "provider_mode": settings.ai_provider,
        },
    }
