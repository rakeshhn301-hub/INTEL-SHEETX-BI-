"""
INTEL SHEETX BI — FastAPI Backend Server (Chapters 25-34 & Appendix E).
Implements all 13 canonical REST endpoints plus Auth, Projects, Charts, Relationships,
Scheduled Digests, and Full Artifact Deletion.
"""
import csv
import io
import json
import os
import re
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional
import duckdb
from fastapi import Depends, FastAPI, File, Form, HTTPException, Query, Response, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from openpyxl import Workbook
from pydantic import BaseModel, Field

from . import APP_VERSION
from .agent.runtime import TOOL_REGISTRY, run_agent_investigation
from .auth import (
    create_session,
    get_current_user,
    hash_password,
    require_dashboard_access,
    require_dataset_access,
    require_project_access,
    verify_password,
)
from .charts.echarts_builder import build_render_bundle, format_metric_value
from .charts.recommender import recommend_charts
from .config import settings
from .db import get_conn, init_db, log_audit, new_id, now_iso
from .insights.dashboard_gen import generate_dashboard_blueprint
from .insights.detectors import compute_defensible_forecast, execute_insight_plan
from .insights.planner import generate_analysis_brief
from .model.metrics import compile_safe_metric_expression, seed_project_metrics
from .model.relationships import verify_one_side_uniqueness
from .nlp.normaliser import normalise_command
from .nlp.parser import parse_command_slots
from .nlp.provenance import build_evidence_bundle, generate_grounded_explanation
from .nlp.resolver import resolve_to_chart_spec
from .query.compiler import clear_dataset_cache, compile_and_execute
from .query.spec import ChartSpec, FilterClause
from .services import (
    delete_dataset_artifacts,
    load_dataset_context,
    persist_ingested_dataset,
    read_parquet_preview,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title="INTEL SHEETX BI API",
    version=APP_VERSION,
    description="AI-Native Self-Service Business Intelligence Engine",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.app_url.rstrip("/")],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# -------------------- Request Schemas --------------------
class RegisterRequest(BaseModel):
    email: str
    name: str
    password: str = Field(min_length=6)


class LoginRequest(BaseModel):
    email: str
    password: str


class CreateProjectRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = ""


class ShareMemberRequest(BaseModel):
    email: str
    role: str = Field(default="viewer", pattern="^(viewer|editor|owner)$")


class FixtureIngestRequest(BaseModel):
    project_id: str
    fixture_name: str = "enterprise_india_sales_2026.csv"
    sheet_name: Optional[str] = None


class FieldOverrideItem(BaseModel):
    name: str
    role: Optional[str] = None
    semantic_type: Optional[str] = None
    additive: Optional[str] = None
    exclude_from_ai: Optional[bool] = None


class PatchFieldsRequest(BaseModel):
    overrides: List[FieldOverrideItem]


class CustomMetricRequest(BaseModel):
    project_id: str
    dataset_id: str
    metric_key: str
    label: str
    description: str = ""
    expression: str
    unit: str = "number"


class CreateRelationshipRequest(BaseModel):
    project_id: str
    from_dataset_id: str
    from_field: str
    to_dataset_id: str
    to_field: str


class CommandRequest(BaseModel):
    project_id: str
    dataset_id: str
    text: str
    previous_spec: Optional[Dict[str, Any]] = None


class SaveChartRequest(BaseModel):
    project_id: str
    dataset_id: str
    title: str
    spec: ChartSpec


class GenerateDashboardRequest(BaseModel):
    project_id: str
    dataset_id: str


class PatchDashboardRequest(BaseModel):
    title: Optional[str] = None
    definition: Dict[str, Any]
    note: str = "Updated dashboard layout"


class InsightPlanRequest(BaseModel):
    dataset_id: str


class ExportRequest(BaseModel):
    dataset_id: str
    format: str = Field(default="csv", pattern="^(csv|xlsx|report_html)$")
    spec: ChartSpec


class CreateScheduleRequest(BaseModel):
    project_id: str
    dataset_id: str
    kind: str = Field(default="digest", pattern="^(digest|alert|refresh)$")
    name: str
    cadence: str = "weekly"
    channel: str = "email"
    recipient: str
    config: Dict[str, Any] = Field(default_factory=dict)


class AgentRunRequest(BaseModel):
    project_id: str
    dataset_id: str
    goal: str
    max_queries: Optional[int] = None


class DeleteDatasetConfirmRequest(BaseModel):
    confirm_name: str


# -------------------- 1. Health & System Status --------------------
@app.get("/api/health")
def health_check():
    with get_conn() as conn:
        user_cnt = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    return {
        "status": "ok",
        "version": APP_VERSION,
        "database": "connected",
        "duckdb_version": duckdb.__version__,
        "ai_provider_mode": settings.ai_provider if settings.ai_api_key else "deterministic_fallback",
        "registered_users": int(user_cnt),
    }


# -------------------- 2. Authentication --------------------
@app.post("/api/auth/register")
def register_user(req: RegisterRequest, response: Response):
    if not settings.enable_signup:
        raise HTTPException(status_code=403, detail="Account registration is disabled.")
    email_norm = req.email.strip().lower()
    if "@" not in email_norm:
        raise HTTPException(status_code=400, detail="Valid email address required.")
    with get_conn() as conn:
        exists = conn.execute("SELECT id FROM users WHERE email = ?", (email_norm,)).fetchone()
        if exists:
            raise HTTPException(status_code=409, detail="An account with this email already exists. Please sign in.")
        uid = new_id("usr")
        ws_id = new_id("ws")
        ts = now_iso()
        conn.execute(
            "INSERT INTO users (id, email, name, password_hash, created_at) VALUES (?, ?, ?, ?, ?)",
            (uid, email_norm, req.name.strip() or email_norm.split("@")[0], hash_password(req.password), ts),
        )
        conn.execute(
            "INSERT INTO workspaces (id, name, owner_id, created_at) VALUES (?, ?, ?, ?)",
            (ws_id, f"{req.name.strip() or 'Personal'}'s Workspace", uid, ts),
        )
        conn.execute(
            "INSERT INTO workspace_members (workspace_id, user_id, role, created_at) VALUES (?, ?, 'owner', ?)",
            (ws_id, uid, ts),
        )
        token = create_session(conn, uid)
        log_audit(conn, action="user_registered", object_type="user", object_id=uid, user_id=uid, workspace_id=ws_id)

    response.set_cookie("sx_session", token, httponly=True, secure=settings.app_url.startswith("https://"), samesite="lax", max_age=14 * 86400)
    return {
        "token": token,
        "user": {"id": uid, "email": email_norm, "name": req.name.strip()},
    }


@app.post("/api/auth/login")
def login_user(req: LoginRequest, response: Response):
    email_norm = req.email.strip().lower()
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE email = ?", (email_norm,)).fetchone()
        if not row or not verify_password(req.password, row["password_hash"]):
            raise HTTPException(status_code=401, detail="Invalid email or password.")
        token = create_session(conn, row["id"])
    response.set_cookie("sx_session", token, httponly=True, secure=settings.app_url.startswith("https://"), samesite="lax", max_age=14 * 86400)
    return {
        "token": token,
        "user": {"id": row["id"], "email": row["email"], "name": row["name"]},
    }


@app.post("/api/auth/logout")
def logout_user(response: Response, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        conn.execute("DELETE FROM sessions WHERE token_hash = ?", (user["token_hash"],))
    response.delete_cookie("sx_session")
    return {"status": "logged_out"}


@app.get("/api/auth/me")
def get_me(user: dict = Depends(get_current_user)):
    return {"user": {"id": user["id"], "email": user["email"], "name": user["name"]}}


# -------------------- 3. Projects & Workspace Sharing --------------------
@app.get("/api/projects")
def list_projects(user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT p.*, wm.role AS member_role,
                      (SELECT COUNT(*) FROM datasets d WHERE d.project_id = p.id AND d.deleted_at IS NULL) AS dataset_count,
                      (SELECT COUNT(*) FROM dashboards db WHERE db.project_id = p.id) AS dashboard_count
               FROM projects p
               JOIN workspace_members wm ON wm.workspace_id = p.workspace_id
               WHERE wm.user_id = ?
               ORDER BY p.updated_at DESC""",
            (user["id"],),
        ).fetchall()
        return {"projects": [dict(r) for r in rows]}


@app.post("/api/projects")
def create_project(req: CreateProjectRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        ws = conn.execute(
            "SELECT workspace_id FROM workspace_members WHERE user_id = ? AND role IN ('owner', 'editor') ORDER BY created_at ASC LIMIT 1",
            (user["id"],),
        ).fetchone()
        if not ws:
            raise HTTPException(status_code=403, detail="No editable workspace found.")
        pid = new_id("prj")
        ts = now_iso()
        conn.execute(
            "INSERT INTO projects (id, workspace_id, name, description, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (pid, ws["workspace_id"], req.name.strip(), req.description.strip(), user["id"], ts, ts),
        )
        seed_project_metrics(conn, pid)
        log_audit(
            conn,
            action="project_created",
            object_type="project",
            object_id=pid,
            user_id=user["id"],
            workspace_id=ws["workspace_id"],
            project_id=pid,
        )
        proj = require_project_access(conn, user["id"], pid, "viewer")
        return {"project": proj}


@app.get("/api/projects/{project_id}")
def get_project_detail(project_id: str, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        proj = require_project_access(conn, user["id"], project_id, "viewer")
        datasets = conn.execute(
            """SELECT d.*, dv.row_count, dv.column_count, dv.original_filename, dv.sheet_name
               FROM datasets d
               JOIN dataset_versions dv ON dv.dataset_id = d.id AND dv.version = d.current_version
               WHERE d.project_id = ? AND d.deleted_at IS NULL
               ORDER BY d.updated_at DESC""",
            (project_id,),
        ).fetchall()
        dashboards = conn.execute(
            "SELECT id, dataset_id, dataset_version, title, subtitle, current_version, updated_at FROM dashboards WHERE project_id = ? ORDER BY updated_at DESC",
            (project_id,),
        ).fetchall()
        charts = conn.execute(
            "SELECT * FROM charts WHERE project_id = ? ORDER BY updated_at DESC",
            (project_id,),
        ).fetchall()
        members = conn.execute(
            """SELECT u.email, u.name, wm.role
               FROM workspace_members wm JOIN users u ON u.id = wm.user_id
               WHERE wm.workspace_id = ?""",
            (proj["workspace_id"],),
        ).fetchall()
        return {
            "project": proj,
            "datasets": [dict(r) for r in datasets],
            "dashboards": [dict(r) for r in dashboards],
            "charts": [
                {**dict(c), "spec": json.loads(c["spec_json"])}
                for c in charts
            ],
            "members": [dict(m) for m in members],
        }


@app.post("/api/projects/{project_id}/members")
def share_project_workspace(project_id: str, req: ShareMemberRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        proj = require_project_access(conn, user["id"], project_id, "owner")
        target = conn.execute("SELECT id, email, name FROM users WHERE email = ?", (req.email.strip().lower(),)).fetchone()
        if not target:
            raise HTTPException(status_code=404, detail=f"No registered user found with email '{req.email}'.")
        conn.execute(
            """INSERT INTO workspace_members (workspace_id, user_id, role, created_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(workspace_id, user_id) DO UPDATE SET role = excluded.role""",
            (proj["workspace_id"], target["id"], req.role, now_iso()),
        )
        log_audit(
            conn,
            action="member_shared",
            object_type="workspace",
            object_id=proj["workspace_id"],
            user_id=user["id"],
            project_id=project_id,
            details={"shared_with": target["email"], "role": req.role},
        )
        return {"shared_with": target["email"], "role": req.role}


# -------------------- 4. Upload, Parse, Profile & Overrides (Appendix E #1-3) --------------------
@app.post("/api/upload")
async def upload_file(
    project_id: str = Form(...),
    file: UploadFile = File(...),
    dataset_id: Optional[str] = Form(default=None),
    sheet_name: Optional[str] = Form(default=None),
    user: dict = Depends(get_current_user),
):
    raw_bytes = await file.read()
    with get_conn() as conn:
        proj = require_project_access(conn, user["id"], project_id, "editor")
        if dataset_id:
            require_dataset_access(conn, user["id"], dataset_id, "editor")
        return persist_ingested_dataset(
            conn,
            project_id=project_id,
            workspace_id=proj["workspace_id"],
            user_id=user["id"],
            filename=file.filename or "upload.csv",
            raw_bytes=raw_bytes,
            dataset_id=dataset_id,
            sheet_name=sheet_name,
        )


@app.post("/api/upload/fixture")
def ingest_verified_fixture(req: FixtureIngestRequest, user: dict = Depends(get_current_user)):
    """
    Ingests a real CSV/XLSX file from `tests/fixtures/` through the exact same DuckDB/Parquet
    ingestion pipeline (zero mock code paths) so users can test immediately or upload their own file.
    """
    allowed = {
        "enterprise_india_sales_2026.csv",
        "sales_small.csv",
        "sales_multi.xlsx",
        "sales_nulls.csv",
        "sales_ids.csv",
    }
    if req.fixture_name not in allowed:
        raise HTTPException(status_code=400, detail=f"Fixture must be one of: {', '.join(sorted(allowed))}")
    fpath = os.path.join(settings.fixtures_dir, req.fixture_name)
    if not os.path.exists(fpath):
        raise HTTPException(status_code=404, detail="Fixture file not found on disk.")
    with open(fpath, "rb") as f:
        raw_bytes = f.read()

    with get_conn() as conn:
        proj = require_project_access(conn, user["id"], req.project_id, "editor")
        return persist_ingested_dataset(
            conn,
            project_id=req.project_id,
            workspace_id=proj["workspace_id"],
            user_id=user["id"],
            filename=req.fixture_name,
            raw_bytes=raw_bytes,
            sheet_name=req.sheet_name,
        )


@app.get("/api/datasets/{dataset_id}/profile")
def get_dataset_profile(dataset_id: str, version: Optional[int] = None, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        require_dataset_access(conn, user["id"], dataset_id, "viewer")
        ctx = load_dataset_context(conn, dataset_id, version=version)
        return {
            "dataset": ctx["dataset"],
            "version": ctx["version_row"]["version"],
            "parse_report": ctx["parse_report"],
            "profile": ctx["profile"],
            "fields": ctx["fields"],
            "metrics": ctx["resolved_metrics"],
        }


@app.get("/api/datasets/{dataset_id}/preview")
def get_dataset_preview(
    dataset_id: str,
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=50, ge=1, le=200),
    user: dict = Depends(get_current_user),
):
    with get_conn() as conn:
        require_dataset_access(conn, user["id"], dataset_id, "viewer")
        ctx = load_dataset_context(conn, dataset_id)
        return read_parquet_preview(ctx["parquet_path"], offset=offset, limit=min(limit, settings.max_rows_preview))


@app.patch("/api/datasets/{dataset_id}/fields")
def patch_dataset_fields(dataset_id: str, req: PatchFieldsRequest, user: dict = Depends(get_current_user)):
    allowed_roles = {"dimension", "measure", "identifier", "detail", "date"}
    with get_conn() as conn:
        ds = require_dataset_access(conn, user["id"], dataset_id, "editor")
        ver = int(ds["current_version"])
        ts = now_iso()
        updated = []
        for ov in req.overrides:
            frow = conn.execute(
                "SELECT * FROM field_metadata WHERE dataset_id = ? AND version = ? AND LOWER(name) = LOWER(?)",
                (dataset_id, ver, ov.name),
            ).fetchone()
            if not frow:
                raise HTTPException(status_code=400, detail=f"Column '{ov.name}' not found.")
            new_role = ov.role if ov.role else frow["role"]
            if new_role not in allowed_roles:
                raise HTTPException(status_code=400, detail=f"Invalid role '{new_role}'.")
            new_sem = ov.semantic_type if ov.semantic_type else frow["semantic_type"]
            new_add = ov.additive if ov.additive else ("na" if new_role in ("identifier", "dimension", "date", "detail") else frow["additive"])
            new_excl = int(ov.exclude_from_ai) if ov.exclude_from_ai is not None else int(frow["exclude_from_ai"])
            new_reason = f"User override to role='{new_role}', semantic='{new_sem}' (previously: {frow['role']})."

            conn.execute(
                """UPDATE field_metadata
                   SET role = ?, semantic_type = ?, additive = ?, exclude_from_ai = ?,
                       reason = ?, overridden_by = ?, overridden_at = ?
                   WHERE id = ?""",
                (new_role, new_sem, new_add, new_excl, new_reason, user["id"], ts, frow["id"]),
            )
            updated.append({"name": frow["name"], "role": new_role, "semantic_type": new_sem, "exclude_from_ai": bool(new_excl)})

        clear_dataset_cache(dataset_id)
        log_audit(
            conn,
            action="field_roles_overridden",
            object_type="dataset",
            object_id=dataset_id,
            user_id=user["id"],
            workspace_id=ds["workspace_id"],
            project_id=ds["project_id"],
            details={"overrides": updated},
        )
        ctx = load_dataset_context(conn, dataset_id)
        return {"fields": ctx["fields"], "metrics": ctx["resolved_metrics"]}


@app.delete("/api/datasets/{dataset_id}")
def delete_dataset(dataset_id: str, confirm_name: Optional[str] = Query(default=None), user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        ds = require_dataset_access(conn, user["id"], dataset_id, "editor")
        if confirm_name is not None and confirm_name.strip() != ds["name"]:
            raise HTTPException(status_code=400, detail=f"Typed confirmation '{confirm_name}' did not match dataset name '{ds['name']}'.")
        return delete_dataset_artifacts(conn, ds, user["id"])


# -------------------- 5. Metrics & Relationship Fan-Out Gate (Appendix E #4) --------------------
@app.get("/api/metrics")
def list_metrics(dataset_id: str = Query(...), user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        require_dataset_access(conn, user["id"], dataset_id, "viewer")
        ctx = load_dataset_context(conn, dataset_id)
        return {"metrics": ctx["resolved_metrics"]}


@app.post("/api/metrics")
def create_or_version_custom_metric(req: CustomMetricRequest, user: dict = Depends(get_current_user)):
    mkey = re.sub(r"[^a-z0-9_]+", "_", req.metric_key.strip().lower()).strip("_")
    if not mkey:
        raise HTTPException(status_code=400, detail="Valid metric_key required.")
    with get_conn() as conn:
        proj = require_project_access(conn, user["id"], req.project_id, "editor")
        require_dataset_access(conn, user["id"], req.dataset_id, "viewer")
        ctx = load_dataset_context(conn, req.dataset_id)
        try:
            compiled = compile_safe_metric_expression(req.expression, ctx["fields"])
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        spec_obj = {
            "custom_ast_sql": compiled["sql_expr"],
            "referenced_columns": compiled["referenced_columns"],
            "raw_expression": req.expression,
            "synonyms": [req.label.lower(), mkey.replace("_", " ")],
        }
        fmt_obj = {
            "kind": "currency" if req.unit == "currency" else ("percent" if req.unit == "percent" else "number"),
            "currency": "INR",
            "decimals": 2,
        }
        ts = now_iso()
        existing = conn.execute(
            "SELECT * FROM metric_definitions WHERE project_id = ? AND metric_key = ?",
            (req.project_id, mkey),
        ).fetchone()

        if existing:
            new_ver = int(existing["current_version"]) + 1
            conn.execute(
                "UPDATE metric_definitions SET label = ?, description = ?, formula_display = ?, spec_json = ?, format_json = ?, current_version = ? WHERE id = ?",
                (req.label, req.description, req.expression, json.dumps(spec_obj), json.dumps(fmt_obj), new_ver, existing["id"]),
            )
            conn.execute(
                "INSERT INTO metric_versions (id, metric_def_id, version, spec_json, note, changed_by, created_at) VALUES (?, ?, ?, ?, 'Versioned formula update', ?, ?)",
                (new_id("mv"), existing["id"], new_ver, json.dumps(spec_obj), user["id"], ts),
            )
            mid = existing["id"]
        else:
            mid = new_id("met")
            conn.execute(
                """INSERT INTO metric_definitions
                   (id, project_id, metric_key, label, description, kind, formula_display, spec_json,
                    grain, null_policy, format_json, current_version, is_builtin, created_at)
                   VALUES (?, ?, ?, ?, ?, 'derived', ?, ?, 'record', 'ignore', ?, 1, 0, ?)""",
                (mid, req.project_id, mkey, req.label, req.description, req.expression, json.dumps(spec_obj), json.dumps(fmt_obj), ts),
            )
            conn.execute(
                "INSERT INTO metric_versions (id, metric_def_id, version, spec_json, note, changed_by, created_at) VALUES (?, ?, 1, ?, 'Created derived metric', ?, ?)",
                (new_id("mv"), mid, json.dumps(spec_obj), user["id"], ts),
            )
            new_ver = 1

        clear_dataset_cache(req.dataset_id)
        log_audit(conn, action="metric_saved", object_type="metric", object_id=mid, user_id=user["id"], workspace_id=proj["workspace_id"], project_id=req.project_id)
        ctx_after = load_dataset_context(conn, req.dataset_id)
        return {"metric_id": mid, "version": new_ver, "metrics": ctx_after["resolved_metrics"]}


@app.post("/api/relationships")
def create_relationship(req: CreateRelationshipRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        require_project_access(conn, user["id"], req.project_id, "editor")
        require_dataset_access(conn, user["id"], req.from_dataset_id, "viewer")
        require_dataset_access(conn, user["id"], req.to_dataset_id, "viewer")
        to_ctx = load_dataset_context(conn, req.to_dataset_id)
        guard = verify_one_side_uniqueness(to_ctx["parquet_path"], req.to_field)

        rel_id = new_id("rel")
        conn.execute(
            """INSERT INTO relationships
               (id, project_id, from_dataset_id, from_field, to_dataset_id, to_field,
                cardinality, active, verified_unique, guard_message, created_at)
               VALUES (?, ?, ?, ?, ?, ?, 'many_to_one', ?, ?, ?, ?)""",
            (
                rel_id,
                req.project_id,
                req.from_dataset_id,
                req.from_field,
                req.to_dataset_id,
                req.to_field,
                1 if guard["verified_unique"] else 0,
                1 if guard["verified_unique"] else 0,
                guard["message"],
                now_iso(),
            ),
        )
        if not guard["verified_unique"]:
            raise HTTPException(status_code=400, detail=guard["message"])
        return {"relationship_id": rel_id, **guard}


# -------------------- 6. Unified Query Execution & Saved Charts (Appendix E #5) --------------------
@app.post("/api/query")
def execute_query_spec(spec: ChartSpec, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        ds = require_dataset_access(conn, user["id"], spec.dataset_id, "viewer")
        ctx = load_dataset_context(conn, spec.dataset_id)
        qres = compile_and_execute(
            spec=spec,
            parquet_path=ctx["parquet_path"],
            dataset_version=int(ds["current_version"]),
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
            user_scope=ds["workspace_id"],
        )
        has_date = any(f["role"] == "date" for f in ctx["fields"])
        has_target = any("target" in f["name"].lower() for f in ctx["fields"])
        mkey = qres["metrics_used"][0]["metric_key"] if qres["metrics_used"] else None
        has_neg = any((r.get(mkey) or 0) < 0 for r in qres["rows"]) if mkey else False

        rec = recommend_charts(
            intent=spec.intent,
            has_date=has_date,
            distinct_categories=qres["total_groups_before_cap"] if spec.dimensions else 0,
            has_negative_values=has_neg,
            row_count=ctx["profile"]["row_count"],
            measure_count=len(spec.measures),
            has_target=has_target,
            requested_override=spec.chart_type,
        )
        render = build_render_bundle(
            chart_type=rec["selected"],
            spec_dict=spec.model_dump(),
            query_result=qres,
            recommender_info=rec,
        )
        return {
            "spec": spec.model_dump(),
            "query": qres,
            "recommendation": rec,
            "render": render,
        }


@app.post("/api/charts")
def save_chart(req: SaveChartRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        require_project_access(conn, user["id"], req.project_id, "editor")
        ds = require_dataset_access(conn, user["id"], req.dataset_id, "editor")
        cid = new_id("cht")
        ts = now_iso()
        spec_d = req.spec.model_dump()
        spec_d["title"] = req.title
        conn.execute(
            """INSERT INTO charts (id, project_id, dataset_id, dataset_version, title, spec_json, created_by, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (cid, req.project_id, req.dataset_id, int(ds["current_version"]), req.title, json.dumps(spec_d), user["id"], ts, ts),
        )
        return {"chart_id": cid, "title": req.title, "spec": spec_d, "dataset_version": int(ds["current_version"])}


# -------------------- 7. The Natural-Language Command Bar (Appendix E #6) --------------------
@app.post("/api/command")
def run_command(req: CommandRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        require_project_access(conn, user["id"], req.project_id, "editor")
        ds = require_dataset_access(conn, user["id"], req.dataset_id, "editor")
        ctx = load_dataset_context(conn, req.dataset_id)

        norm_info = normalise_command(req.text)
        parsed = parse_command_slots(
            normalised_info=norm_info,
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
            previous_spec=req.previous_spec,
        )
        resolution = resolve_to_chart_spec(
            dataset_id=req.dataset_id,
            row_count=ctx["profile"]["row_count"],
            parsed=parsed,
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
        )

        outcome = resolution["outcome"]
        ts = now_iso()

        if outcome in ("clarified", "refused"):
            conn.execute(
                """INSERT INTO ai_analysis_log
                   (id, project_id, dataset_id, dataset_version, user_id, raw_text, normalised_text, model,
                    intent, slots_json, confidence, ambiguities_json, spec_json, sql_hash, query_id,
                    duration_ms, row_count, narrative, verification_passed, rejected_figures_json, outcome, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '{}', '', '', 1, 0, ?, 1, '[]', ?, ?)""",
                (
                    new_id("ail"),
                    req.project_id,
                    req.dataset_id,
                    int(ds["current_version"]),
                    user["id"],
                    req.text,
                    norm_info["normalised"] or "",
                    parsed.get("parser_source", "rules"),
                    parsed.get("intent", "UNSUPPORTED"),
                    json.dumps(parsed.get("slots", {})),
                    float(parsed.get("confidence", 0.5)),
                    json.dumps(parsed.get("ambiguities", [])),
                    resolution.get("question") or resolution.get("reason", ""),
                    outcome,
                    ts,
                ),
            )
            return {
                "outcome": outcome,
                "normalised_text": norm_info["normalised"],
                "intent": parsed.get("intent"),
                "question": resolution.get("question"),
                "reason": resolution.get("reason"),
                "options": resolution.get("options", []),
                "alternatives": resolution.get("alternatives", []),
            }

        spec: ChartSpec = resolution["spec"]
        qres = compile_and_execute(
            spec=spec,
            parquet_path=ctx["parquet_path"],
            dataset_version=int(ds["current_version"]),
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
            user_scope=ds["workspace_id"],
        )

        has_date = any(f["role"] == "date" for f in ctx["fields"])
        has_target = any("target" in f["name"].lower() for f in ctx["fields"])
        mkey = qres["metrics_used"][0]["metric_key"] if qres["metrics_used"] else None
        has_neg = any((r.get(mkey) or 0) < 0 for r in qres["rows"]) if mkey else False

        rec = recommend_charts(
            intent=spec.intent,
            has_date=has_date,
            distinct_categories=qres["total_groups_before_cap"] if spec.dimensions else 0,
            has_negative_values=has_neg,
            row_count=ctx["profile"]["row_count"],
            measure_count=len(spec.measures),
            has_target=has_target,
            requested_override=resolution.get("chart_override"),
        )
        spec.chart_type = rec["selected"]
        spec_dict = spec.model_dump()

        # Attach seasonal-naive/MA3 forecast points if requested (Benchmark #20)
        forecast_info = None
        if resolution.get("forecast_requested") and spec.dimensions and mkey:
            dcol = spec.dimensions[0].field
            forecast_info = compute_defensible_forecast(qres["rows"], dcol, mkey, horizon=3)
            if forecast_info.get("supported"):
                spec_dict["_forecast_points"] = forecast_info["points"]

        render = build_render_bundle(
            chart_type=rec["selected"],
            spec_dict=spec_dict,
            query_result=qres,
            recommender_info=rec,
        )
        render["guardrail_notes"].extend(resolution.get("guardrail_notes", []))

        bundle = build_evidence_bundle(
            query_result=qres,
            dataset_name=ds["name"],
            total_dataset_rows=ctx["profile"]["row_count"],
            quality_warnings=ctx["profile"].get("quality_warnings", []),
        )
        if forecast_info and forecast_info.get("supported"):
            bundle["forecast"] = forecast_info

        explanation = generate_grounded_explanation(
            question=req.text,
            intent=spec.intent,
            evidence_bundle=bundle,
        )

        conn.execute(
            """INSERT INTO ai_analysis_log
               (id, project_id, dataset_id, dataset_version, user_id, raw_text, normalised_text, model,
                intent, slots_json, confidence, ambiguities_json, spec_json, sql_hash, query_id,
                duration_ms, row_count, narrative, verification_passed, rejected_figures_json, outcome, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'answered', ?)""",
            (
                new_id("ail"),
                req.project_id,
                req.dataset_id,
                int(ds["current_version"]),
                user["id"],
                req.text,
                norm_info["normalised"] or "",
                parsed.get("parser_source", "deterministic_rules"),
                spec.intent,
                json.dumps(parsed.get("slots", {})),
                float(parsed.get("confidence", 0.9)),
                json.dumps(parsed.get("ambiguities", [])),
                json.dumps(spec.model_dump()),
                qres["sql_hash"],
                qres["query_id"],
                qres["duration_ms"],
                qres["row_count"],
                explanation["narrative"],
                1 if explanation["verified"] else 0,
                json.dumps(explanation["rejected_figures"]),
                ts,
            ),
        )

        return {
            "outcome": "answered",
            "normalised_text": norm_info["normalised"],
            "parser_source": parsed.get("parser_source"),
            "spec": spec.model_dump(),
            "query": qres,
            "recommendation": rec,
            "render": render,
            "forecast": forecast_info,
            "evidence_bundle": bundle,
            "explanation": explanation,
        }


@app.get("/api/command/logs")
def list_command_logs(project_id: str = Query(...), user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        require_project_access(conn, user["id"], project_id, "viewer")
        rows = conn.execute(
            "SELECT * FROM ai_analysis_log WHERE project_id = ? ORDER BY created_at DESC LIMIT 50",
            (project_id,),
        ).fetchall()
        return {"logs": [dict(r) for r in rows]}


# -------------------- 8. Analysis Planner & Insights (Appendix E #7-8) --------------------
@app.post("/api/insight/plan")
def plan_insights(req: InsightPlanRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        ds = require_dataset_access(conn, user["id"], req.dataset_id, "viewer")
        ctx = load_dataset_context(conn, req.dataset_id)
        return generate_analysis_brief(
            dataset_id=req.dataset_id,
            dataset_name=ds["name"],
            dataset_version=int(ds["current_version"]),
            profile=ctx["profile"],
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
        )


@app.post("/api/insight/run")
def run_insights(req: InsightPlanRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        ds = require_dataset_access(conn, user["id"], req.dataset_id, "viewer")
        ctx = load_dataset_context(conn, req.dataset_id)
        brief = generate_analysis_brief(
            dataset_id=req.dataset_id,
            dataset_name=ds["name"],
            dataset_version=int(ds["current_version"]),
            profile=ctx["profile"],
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
        )
        cards = execute_insight_plan(
            dataset_id=req.dataset_id,
            parquet_path=ctx["parquet_path"],
            dataset_version=int(ds["current_version"]),
            profile=ctx["profile"],
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
            user_scope=ds["workspace_id"],
        )
        return {"brief": brief, "insights": cards}


# -------------------- 9. Dashboards Generation & Editing (Appendix E #9-10) --------------------
def _hydrate_dashboard_tiles(conn, dashboard_row: Dict[str, Any], active_filters: List[Dict[str, Any]] = None) -> Dict[str, Any]:
    definition = json.loads(dashboard_row["definition_json"]) if isinstance(dashboard_row["definition_json"], str) else dict(dashboard_row["definition_json"])
    ctx = load_dataset_context(conn, dashboard_row["dataset_id"], version=int(dashboard_row["dataset_version"]))
    extra_filters = [FilterClause(**f) for f in (active_filters or definition.get("active_filters", []))]

    hydrated_tiles = []
    for tile in definition.get("tiles", []):
        spec_d = dict(tile["spec"])
        base_filters = [FilterClause(**f) for f in spec_d.get("filters", [])]
        merged_filters = base_filters + extra_filters
        spec_obj = ChartSpec(**{**spec_d, "filters": [f.model_dump() for f in merged_filters]})
        qres = compile_and_execute(
            spec=spec_obj,
            parquet_path=ctx["parquet_path"],
            dataset_version=int(dashboard_row["dataset_version"]),
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
            user_scope=dashboard_row.get("workspace_id", dashboard_row["project_id"]),
        )
        render = build_render_bundle(
            chart_type=spec_obj.chart_type,
            spec_dict=spec_obj.model_dump(),
            query_result=qres,
        )
        hydrated_tiles.append({
            **tile,
            "query": qres,
            "render": render,
        })

    return {
        "id": dashboard_row["id"],
        "project_id": dashboard_row["project_id"],
        "dataset_id": dashboard_row["dataset_id"],
        "dataset_version": int(dashboard_row["dataset_version"]),
        "title": dashboard_row["title"],
        "subtitle": dashboard_row["subtitle"],
        "current_version": int(dashboard_row["current_version"]),
        "updated_at": dashboard_row["updated_at"],
        "definition": definition,
        "hydrated_tiles": hydrated_tiles,
        "available_metrics": [m for m in ctx["resolved_metrics"] if m["available"]],
    }


@app.post("/api/dashboards/generate")
def generate_dashboard(req: GenerateDashboardRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        proj = require_project_access(conn, user["id"], req.project_id, "editor")
        ds = require_dataset_access(conn, user["id"], req.dataset_id, "editor")
        ctx = load_dataset_context(conn, req.dataset_id)

        bp = generate_dashboard_blueprint(
            dataset_id=req.dataset_id,
            dataset_name=ds["name"],
            dataset_version=int(ds["current_version"]),
            profile=ctx["profile"],
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
        )
        db_id = new_id("dash")
        ts = now_iso()
        conn.execute(
            """INSERT INTO dashboards
               (id, project_id, dataset_id, dataset_version, title, subtitle, current_version, definition_json, created_by, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)""",
            (db_id, req.project_id, req.dataset_id, int(ds["current_version"]), bp["title"], bp["subtitle"], json.dumps(bp), user["id"], ts, ts),
        )
        conn.execute(
            """INSERT INTO dashboard_versions (id, dashboard_id, version, definition_json, note, created_by, created_at)
               VALUES (?, ?, 1, ?, 'Auto-generated 6-tile dashboard blueprint', ?, ?)""",
            (new_id("dbv"), db_id, json.dumps(bp), user["id"], ts),
        )
        log_audit(conn, action="dashboard_generated", object_type="dashboard", object_id=db_id, user_id=user["id"], workspace_id=proj["workspace_id"], project_id=req.project_id)
        db_row = require_dashboard_access(conn, user["id"], db_id, "viewer")
        return _hydrate_dashboard_tiles(conn, db_row)


@app.get("/api/dashboards/{dashboard_id}")
def get_dashboard(
    dashboard_id: str,
    filters_json: Optional[str] = Query(default=None),
    user: dict = Depends(get_current_user),
):
    extra_f = json.loads(filters_json) if filters_json else None
    with get_conn() as conn:
        db_row = require_dashboard_access(conn, user["id"], dashboard_id, "viewer")
        versions = conn.execute(
            "SELECT version, note, created_at FROM dashboard_versions WHERE dashboard_id = ? ORDER BY version DESC",
            (dashboard_id,),
        ).fetchall()
        out = _hydrate_dashboard_tiles(conn, db_row, active_filters=extra_f)
        out["versions"] = [dict(v) for v in versions]
        return out


@app.patch("/api/dashboards/{dashboard_id}")
def update_dashboard(dashboard_id: str, req: PatchDashboardRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        db_row = require_dashboard_access(conn, user["id"], dashboard_id, "editor")
        new_ver = int(db_row["current_version"]) + 1
        new_title = req.title.strip() if req.title else db_row["title"]
        def_copy = dict(req.definition)
        def_copy["title"] = new_title
        ts = now_iso()

        conn.execute(
            "UPDATE dashboards SET title = ?, current_version = ?, definition_json = ?, updated_at = ? WHERE id = ?",
            (new_title, new_ver, json.dumps(def_copy), ts, dashboard_id),
        )
        conn.execute(
            "INSERT INTO dashboard_versions (id, dashboard_id, version, definition_json, note, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (new_id("dbv"), dashboard_id, new_ver, json.dumps(def_copy), req.note, user["id"], ts),
        )
        updated_row = require_dashboard_access(conn, user["id"], dashboard_id, "viewer")
        out = _hydrate_dashboard_tiles(conn, updated_row)
        versions = conn.execute(
            "SELECT version, note, created_at FROM dashboard_versions WHERE dashboard_id = ? ORDER BY version DESC",
            (dashboard_id,),
        ).fetchall()
        out["versions"] = [dict(v) for v in versions]
        return out


# -------------------- 10. Export Current Filtered View (Appendix E #11) --------------------
@app.post("/api/export")
def export_filtered_view(req: ExportRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        ds = require_dataset_access(conn, user["id"], req.dataset_id, "viewer")
        ctx = load_dataset_context(conn, req.dataset_id)
        qres = compile_and_execute(
            spec=req.spec,
            parquet_path=ctx["parquet_path"],
            dataset_version=int(ds["current_version"]),
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
            user_scope=ds["workspace_id"],
        )
        ts = now_iso()
        conn.execute(
            """INSERT INTO exports (id, project_id, dataset_id, format, row_count, filters_json, created_by, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (new_id("exp"), ds["project_id"], req.dataset_id, req.format, qres["row_count"], json.dumps(qres["applied_filters"]), user["id"], ts),
        )

    filters_label = "; ".join(qres["applied_filters"]) if qres["applied_filters"] else "None (All records)"
    formulas_label = "; ".join(f"{m['label']} = {m['formula']}" for m in qres["metrics_used"])

    if req.format == "csv":
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["# INTEL SHEETX BI Export", f"Dataset: {ds['name']} (v{ds['current_version']})"])
        writer.writerow(["# Active Filters", filters_label])
        writer.writerow(["# Metric Definitions", formulas_label])
        writer.writerow(["# Generated At", ts, f"Query ID: {qres['query_id']}"])
        writer.writerow(qres["columns"])
        for r in qres["rows"]:
            writer.writerow([r.get(c) for c in qres["columns"]])
        data_bytes = buf.getvalue().encode("utf-8")
        return StreamingResponse(
            io.BytesIO(data_bytes),
            media_type="text/csv",
            headers={
                "Content-Disposition": f'attachment; filename="sheetx_export_{qres["query_id"]}.csv"',
                "X-Export-Row-Count": str(qres["row_count"]),
                "X-Query-Id": qres["query_id"],
            },
        )

    if req.format == "xlsx":
        wb = Workbook()
        ws_data = wb.active
        ws_data.title = "Filtered_Results"
        ws_data.append(qres["columns"])
        for r in qres["rows"]:
            ws_data.append([r.get(c) for c in qres["columns"]])
        ws_meta = wb.create_sheet("Audit_Metadata")
        ws_meta.append(["Property", "Value"])
        ws_meta.append(["Dataset", f"{ds['name']} (v{ds['current_version']})"])
        ws_meta.append(["Active Filters", filters_label])
        ws_meta.append(["Metric Definitions", formulas_label])
        ws_meta.append(["Row Count", qres["row_count"]])
        ws_meta.append(["Query ID", qres["query_id"]])
        ws_meta.append(["Generated At", ts])
        out_io = io.BytesIO()
        wb.save(out_io)
        out_io.seek(0)
        return StreamingResponse(
            out_io,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f'attachment; filename="sheetx_export_{qres["query_id"]}.xlsx"',
                "X-Export-Row-Count": str(qres["row_count"]),
                "X-Query-Id": qres["query_id"],
            },
        )

    # Printable audit report snapshot (HTML for clean browser Print-to-PDF with filters & metric formulas)
    rows_html = "".join(
        "<tr>" + "".join(f"<td>{r.get(c, '')}</td>" for c in qres["columns"]) + "</tr>"
        for r in qres["rows"]
    )
    ths_html = "".join(f"<th>{c}</th>" for c in qres["columns"])
    html = f"""<!doctype html><html><head><meta charset="utf-8"><title>INTEL SHEETX BI Snapshot</title>
    <style>body{{font-family:system-ui,sans-serif;padding:32px;color:#0f172a}}table{{border-collapse:collapse;width:100%;margin-top:16px}}
    th,td{{border:1px solid #cbd5e1;padding:8px 10px;text-align:left;font-size:13px}}th{{background:#f1f5f9}}.meta{{background:#f8fafc;border:1px solid #e2e8f0;padding:12px;border-radius:8px;font-size:13px}}</style></head>
    <body><h1>{req.spec.title or 'INTEL SHEETX BI — Audited View Export'}</h1>
    <div class="meta"><strong>Dataset:</strong> {ds['name']} (v{ds['current_version']}) &nbsp;|&nbsp;
    <strong>Filters:</strong> {filters_label} &nbsp;|&nbsp; <strong>Metrics:</strong> {formulas_label} &nbsp;|&nbsp;
    <strong>Query ID:</strong> {qres['query_id']} &nbsp;|&nbsp; <strong>Generated:</strong> {ts}</div>
    <table><thead><tr>{ths_html}</tr></thead><tbody>{rows_html}</tbody></table></body></html>"""
    return StreamingResponse(
        io.BytesIO(html.encode("utf-8")),
        media_type="text/html",
        headers={
            "Content-Disposition": f'attachment; filename="sheetx_snapshot_{qres["query_id"]}.html"',
            "X-Export-Row-Count": str(qres["row_count"]),
        },
    )


# -------------------- 11. Scheduled Pulse Digests & Idempotent Jobs (Chapter 23 & Phase 9) --------------------
@app.post("/api/schedules")
def create_schedule(req: CreateScheduleRequest, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        require_project_access(conn, user["id"], req.project_id, "editor")
        require_dataset_access(conn, user["id"], req.dataset_id, "viewer")
        sid = new_id("sch")
        conn.execute(
            """INSERT INTO schedules
               (id, project_id, dataset_id, kind, name, cadence, channel, recipient, config_json, active, created_by, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)""",
            (sid, req.project_id, req.dataset_id, req.kind, req.name, req.cadence, req.channel, req.recipient, json.dumps(req.config), user["id"], now_iso()),
        )
        return {"schedule_id": sid, "name": req.name, "kind": req.kind, "cadence": req.cadence, "recipient": req.recipient}


@app.post("/api/schedules/{schedule_id}/run")
def run_schedule_idempotent(
    schedule_id: str,
    period_key: str = Query(default="2026-W43"),
    user: dict = Depends(get_current_user),
):
    """
    Executes a Digest or Threshold Alert job idempotently per `period_key` (Chapter 23.2 & Phase 9 Gate).
    """
    with get_conn() as conn:
        sch = conn.execute("SELECT * FROM schedules WHERE id = ?", (schedule_id,)).fetchone()
        if not sch:
            raise HTTPException(status_code=404, detail="Schedule not found.")
        require_project_access(conn, user["id"], sch["project_id"], "editor")

        existing = conn.execute(
            "SELECT * FROM job_runs WHERE schedule_id = ? AND period_key = ?",
            (schedule_id, period_key),
        ).fetchone()
        if existing:
            return {
                "job_run_id": existing["id"],
                "idempotent_replay": True,
                "period_key": period_key,
                "status": existing["status"],
                "digest": json.loads(existing["output_json"]),
            }

        ds = require_dataset_access(conn, user["id"], sch["dataset_id"], "viewer")
        ctx = load_dataset_context(conn, sch["dataset_id"])
        cards = execute_insight_plan(
            dataset_id=sch["dataset_id"],
            parquet_path=ctx["parquet_path"],
            dataset_version=int(ds["current_version"]),
            profile=ctx["profile"],
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
            user_scope=ds["workspace_id"],
        )

        # Max 3 items per digest rule (Chapter 23.2)
        items = [
            {
                "headline": c["headline_figure"],
                "summary": c["interpretation"],
                "query_id": c["query_id"],
                "formula": c["how_calculated"]["formula"],
            }
            for c in cards[:3]
        ]
        digest_payload = {
            "subject": f"{sch['name']} — {period_key} ({ds['name']})",
            "recipient": sch["recipient"],
            "channel": sch["channel"],
            "items": items,
            "footer": {
                "filters": "All active scope records",
                "dataset_version": int(ds["current_version"]),
                "generated_at": now_iso(),
                "unsubscribe_action": f"/api/schedules/{schedule_id}/stop",
            },
        }
        jid = new_id("job")
        conn.execute(
            """INSERT INTO job_runs (id, schedule_id, project_id, job_type, period_key, status, duration_ms, output_json, created_at)
               VALUES (?, ?, ?, ?, ?, 'succeeded', 12, ?, ?)""",
            (jid, schedule_id, sch["project_id"], sch["kind"], period_key, json.dumps(digest_payload), now_iso()),
        )
        conn.execute("UPDATE schedules SET last_run_period = ? WHERE id = ?", (period_key, schedule_id))
        return {"job_run_id": jid, "idempotent_replay": False, "period_key": period_key, "status": "succeeded", "digest": digest_payload}


@app.get("/api/projects/{project_id}/jobs")
def list_project_jobs(project_id: str, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        require_project_access(conn, user["id"], project_id, "viewer")
        schedules = conn.execute("SELECT * FROM schedules WHERE project_id = ? ORDER BY created_at DESC", (project_id,)).fetchall()
        runs = conn.execute("SELECT * FROM job_runs WHERE project_id = ? ORDER BY created_at DESC LIMIT 30", (project_id,)).fetchall()
        return {
            "schedules": [dict(s) for s in schedules],
            "job_runs": [{**dict(r), "output": json.loads(r["output_json"])} for r in runs],
        }


# -------------------- 12. Agentic Assistant Runtime & Audit Trail (Appendix E #12-13) --------------------
@app.get("/api/agent/tools")
def list_agent_tools(user: dict = Depends(get_current_user)):
    return {"tools": [{"name": k, **v} for k, v in TOOL_REGISTRY.items()]}


@app.post("/api/agent/run")
def start_agent_run(req: AgentRunRequest, user: dict = Depends(get_current_user)):
    if not settings.enable_agent:
        raise HTTPException(status_code=503, detail="Agentic assistant is disabled by server configuration.")
    with get_conn() as conn:
        require_project_access(conn, user["id"], req.project_id, "editor")
        ds = require_dataset_access(conn, user["id"], req.dataset_id, "editor")
        ctx = load_dataset_context(conn, req.dataset_id)

        run_out = run_agent_investigation(
            goal=req.goal,
            dataset=ds,
            parquet_path=ctx["parquet_path"],
            profile=ctx["profile"],
            dataset_fields=ctx["fields"],
            resolved_metrics=ctx["resolved_metrics"],
            user_scope=ds["workspace_id"],
            max_queries=req.max_queries,
        )
        run_id = new_id("agr")
        conn.execute(
            """INSERT INTO agent_runs
               (id, project_id, dataset_id, dataset_version, user_id, goal, status, plan_json, steps_json,
                evidence_bundle_json, narrative, pending_confirmations_json, budgets_json, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                run_id,
                req.project_id,
                req.dataset_id,
                int(ds["current_version"]),
                user["id"],
                req.goal,
                run_out["status"],
                json.dumps(run_out["plan"]),
                json.dumps(run_out["steps"]),
                json.dumps(run_out["evidence_bundles"]),
                run_out["narrative"],
                json.dumps(run_out["pending_confirmations"]),
                json.dumps(run_out["budgets"]),
                now_iso(),
            ),
        )
        return {"run_id": run_id, **run_out}


@app.get("/api/agent/runs/{run_id}")
def get_agent_run_audit(run_id: str, user: dict = Depends(get_current_user)):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM agent_runs WHERE id = ?", (run_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Agent run not found.")
        require_project_access(conn, user["id"], row["project_id"], "viewer")
        return {
            "run_id": row["id"],
            "project_id": row["project_id"],
            "dataset_id": row["dataset_id"],
            "dataset_version": row["dataset_version"],
            "goal": row["goal"],
            "status": row["status"],
            "plan": json.loads(row["plan_json"]),
            "steps": json.loads(row["steps_json"]),
            "evidence_bundles": json.loads(row["evidence_bundle_json"]),
            "narrative": row["narrative"],
            "pending_confirmations": json.loads(row["pending_confirmations_json"]),
            "budgets": json.loads(row["budgets_json"]),
            "created_at": row["created_at"],
        }


# Serve frontend and API at one origin in production; no cross-site cookies or
# GitHub Pages API routing required. Unknown API paths remain real JSON 404s.
_WEB_ROOT = Path(os.environ.get("FRONTEND_DIR", str(Path(__file__).resolve().parents[2] / "frontend" / "dist")))
if (_WEB_ROOT / "assets").is_dir():
    app.mount("/assets", StaticFiles(directory=str(_WEB_ROOT / "assets")), name="frontend-assets")

@app.get("/", include_in_schema=False)
def website():
    index = _WEB_ROOT / "index.html"
    if not index.is_file():
        raise HTTPException(status_code=503, detail="Frontend not built. Run npm ci --legacy-peer-deps && npm run build in frontend/.")
    return FileResponse(index, headers={"Cache-Control": "no-cache"})
