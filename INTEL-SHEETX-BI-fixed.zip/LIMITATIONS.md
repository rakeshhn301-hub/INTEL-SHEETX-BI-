# INTEL SHEETX BI — Honest Limitations & Scope Boundaries (`LIMITATIONS.md`)

Per **Chapters 2.3 and 39.2** of *The Complete Build Handbook*, INTEL SHEETX BI documents its explicit scope boundaries honestly:

1. **Batch File Analytics (Not Sub-Second Streaming CDC)**: Data is ingested via CSV/TSV/XLSX upload into versioned Parquet snapshots rather than live Kafka/CDC streams or warehouse write-back connectors.
2. **Tabular Worksheet Requirement for XLSX**: Multi-sheet Excel workbooks prompt the user to select a worksheet and expect a rectangular header + data table; arbitrarily merged free-form financial modelling layouts or macro-driven `.xlsm` sheets are out of scope.
3. **Single-Grain Primary Fact + Verified Many-to-One Joins**: Relationships enforce strict uniqueness on the `'one'` side (`backend/app/model/relationships.py`) and reject many-to-many join fan-out rather than silently inflating sums.
4. **Statistical Forecasting Horizon**: Built-in forecasting uses transparent Seasonal-Naive (`>=24` buckets) or 3-period Moving Average (`>=6` buckets) with holdout backtest MAPE/MAE intervals labeled **Estimate Only**; multivariate causal ML or exogenous macro forecasting is out of scope.
5. **Governed Chart Types Only**: Visualisations are intentionally restricted to perceptual best-practice forms (`bar_h`, `bar`, `line`, `area`, `donut` `<=5` slices, `pct_bar`, `stacked_bar`, `scatter`, `histogram`, `bullet`, `pareto`, `kpi`, `table`). 3D charts, dual-axis spaghetti charts, and >5-slice pie charts are refused by design and converted to clearer forms.
6. **Optional External LLM Enhancement**: Schema-only LLM slot parsing and prose polishing activate when `LLM_PROVIDER=openai_compatible` and `LLM_API_KEY` are configured; when unconfigured (`LLM_PROVIDER=none`), the deterministic compiler and EvidenceBundle narrator handle all 10 command archetypes offline without hallucination risk.
