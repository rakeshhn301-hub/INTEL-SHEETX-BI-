# INTEL SHEETX BI — Operational Runbook (`RUNBOOK.md`)

## 1. Local & Sandbox Startup

1. **Backend API (`0.0.0.0:8000`)**
   ```bash
   cd /home/user/intel-sheetx-bi
   PYTHONPATH=/home/user/intel-sheetx-bi uvicorn backend.app.main:app --host 0.0.0.0 --port 8000
   ```
2. **Frontend Studio (`0.0.0.0:5173`)**
   ```bash
   cd /home/user/intel-sheetx-bi/frontend
   npx vite --host 0.0.0.0 --port 5173
   ```
   Vite proxies all relative `/api/*` requests to `http://127.0.0.1:8000`.

## 2. Health & Diagnostics

- **Health check**: `GET /api/health` verifies both SQLite relational metadata connectivity (`PRAGMA foreign_keys = ON`) and DuckDB execution (`SELECT 1`).
- **Command & AI Provenance Audit**: `GET /api/command/logs?project_id=<id>` inspects structured command outcomes, latency, and provenance pass/fail status without exposing raw data rows.
- **Agent Execution Trace**: `GET /api/agent/runs/<run_id>` inspects every tool step, input/output summary, query count against budget (`max 12`), and confirmation gate state.

## 3. Storage & Backup Recovery

- **Relational Metadata DB**: `/home/user/intel-sheetx-bi/data/metadata.db` (SQLite WAL mode).
- **Immutable Raw Uploads**: `/home/user/intel-sheetx-bi/data/storage/<sha256>_<filename>`.
- **Versioned Parquet Snapshots**: `/home/user/intel-sheetx-bi/data/parquet/<dataset_id>/v<N>.parquet`.
- If a Parquet file is missing, re-uploading the original raw snapshot re-materialises an identical version and invalidates stale query cache entries (`query_cache.invalidate_dataset(dataset_id)`).

## 4. Incident Playbooks

- **Slow / Heavy Upload**: Maximum upload size is enforced via `MAX_UPLOAD_MB` (default `100 MB`). Binary/corrupt files disguised as `.csv` are rejected at content-signature verification before DuckDB ingestion.
- **LLM Provider Unavailable or Unconfigured**: When `LLM_PROVIDER=none` or the external LLM times out, INTEL SHEETX BI automatically falls back to its deterministic slot parser and EvidenceBundle narrator so core upload, profiling, command charting, dashboards, insights, and multi-step agent investigations continue uninterrupted with `100%` provenance fidelity.
- **Permanent Dataset Deletion Request**: Execute `DELETE /api/datasets/<id>?confirm_name=<exact_name>` (or use the Governance tab). Verify Parquet removal, cache eviction, and tombstone audit entry in `audit_events`.
